################################################################################
Age <- mydata.UDS$NACCAGE[index.whole]

g <- 2
hist(Age[(V==1)&(G==g)], breaks = 60)

N.qq <- length(T.1[(V == 1) & (G == g)])
quantiles_empirical <- quantile(22*T.1[(V == 1) & (G == g)] + 22 ,
                                probs = seq(0, 1, length.out = N.qq))
p.mine <- numeric(length(quantiles_empirical))
for (i in 1:N) {
  if ((V[i] == 1) & (G[i] == g)) { p.mine <- p.mine + p.D.v1.hat[i] * pnorm((quantiles_empirical-22)/22, mean = mu.v1.hat[i, 2],sd = sqrt(psi.1.hat[i])) +(1 - p.D.v1.hat[i]) * pnorm((quantiles_empirical-22)/22, mean = mu.v1.hat[i, 1],sd = sqrt(psi.0.hat[i]))}
}
p.mine <- p.mine / sum((V == 1) & (G == g))

theoretical_quantiles <- approx(p.mine, quantiles_empirical, xout = seq(0, 1, length.out = N.qq))$y

qqplot(theoretical_quantiles, quantiles_empirical, main = "Individual with APOEε4 allele",
       xlab = "Theoretical Quantiles", ylab = "Sample Quantiles",
       col = "black", pch = 16, xlim = c(0, 44), ylim = c(0, 44))
abline(0, 1, col = "red", lwd = 2, lty = 2)


################################################################################
Age <- mydata.UDS$NACCAGE[index.whole]
table(data.frame(Age[V==1], X.state[V==1]))

g <- 1
state.t <- 0

N.qq <- length(T.1[(V == 1) & (G == g) & (X.state == state.t)])
quantiles_empirical <- quantile(22*T.1[(V == 1) & (G == g) & (X.state == state.t)] + 22 ,
                                probs = seq(0, 1, length.out = N.qq))
p.mine <- numeric(length(quantiles_empirical))
for (i in 1:N) {
  if ((V[i] == 1) & (G[i] == g) & (X.state[i] == state.t)) { p.mine <- p.mine + p.D.v1.hat[i] * pnorm((quantiles_empirical-22)/22, mean = mu.v1.hat[i, 2],sd = sqrt(psi.1.hat[i])) +(1 - p.D.v1.hat[i]) * pnorm((quantiles_empirical-22)/22, mean = mu.v1.hat[i, 1],sd = sqrt(psi.0.hat[i]))}
}
p.mine <- p.mine / sum((V == 1) & (G == g) & (X.state == state.t))

theoretical_quantiles <- approx(p.mine, quantiles_empirical, xout = seq(0, 1, length.out = N.qq))$y

qqplot(theoretical_quantiles, quantiles_empirical, main = "DEP- male without APOEε4 allele",
       xlab = "Theoretical Quantiles", ylab = "Sample Quantiles",
       col = "black", pch = 16, xlim = c(0, 44), ylim = c(0, 44))
abline(0, 1, col = "red", lwd = 2, lty = 2)


################################################################################
Age <- mydata.UDS$NACCAGE[index.whole]
table(data.frame(Age[V==1], X.state[V==1]))

g <- 2
state.t <- 2
hist(Age[(V==1)&(G==g)&(X.state==state.t)], breaks = 60)
age <- 70
sum((V==1)&(G==g)&(X.state==state.t)&(Age==age))

N.qq <- length(T.1[(V == 1) & (G == g) & (X.state == state.t) & (Age == age)])
quantiles_empirical <- quantile(22*T.1[(V == 1) & (G == g) & (X.state == state.t) & (Age == age)] + 22 ,
                                probs = seq(0, 1, length.out = N.qq))
p.mine <- numeric(length(quantiles_empirical))
for (i in 1:N) {
  if ((V[i] == 1) & (G[i] == g) & (X.state[i] == state.t) & (Age[i] == age)) { p.mine <- p.mine + p.D.v1.hat[i] * pnorm((quantiles_empirical-22)/22, mean = mu.v1.hat[i, 2],sd = sqrt(psi.1.hat[i])) +(1 - p.D.v1.hat[i]) * pnorm((quantiles_empirical-22)/22, mean = mu.v1.hat[i, 1],sd = sqrt(psi.0.hat[i]))}
}
p.mine <- p.mine / sum((V == 1) & (G == g) & (X.state == state.t) & (Age == age))

theoretical_quantiles <- approx(p.mine, quantiles_empirical, xout = seq(0, 1, length.out = N.qq))$y

qqplot(theoretical_quantiles, quantiles_empirical, main = "70-year-old DEP- female with APOEε4 allele",
       xlab = "Theoretical Quantiles", ylab = "Sample Quantiles",
       col = "black", pch = 16, xlim = c(0, 44), ylim = c(0, 44))
abline(0, 1, col = "red", lwd = 2, lty = 2)

