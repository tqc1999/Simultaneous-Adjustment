library("data.table")
library("magrittr")

########## Basic functions ##########
K <- function(x){ ifelse(abs(x) <= 1, 0.75*(1 - x^2), 0) }
expit <- function(x){ 1/(1+exp(-x)) }
b <- function(x){ (x^2)/2 }
b.dot <- function(x){ x }
b.dot.inverse <- function(x){ x }
b.double.dot <- function(x){ 1 }
c.mine <- function(y, phi){ -1/2*log(2*3.141593*phi)-y^2/(2*phi) }
g <- function(x){ x }
g.dot <- function(x) { 1 }
g.inverse <- function(x){ x }
density.glm <- function(t, theta, psi){ exp((t*theta - b(theta))/psi + c.mine(t, psi)) }
c.mine.partial.psi <- function(y, psi){ -1/(2*psi) + y^2/(2*psi^2)}

########## Read data ##########
mydata.UDS <- fread("UDS.csv")
mydata.PET <- fread("PET.csv")

setDT(mydata.UDS)
setDT(mydata.PET)

amyloid_summary <- mydata.PET[, .(all_positive = all(AMYLOID_STATUS == 1),
                                  all_negative = all(AMYLOID_STATUS == 0),
                                  status_mixed = length(unique(AMYLOID_STATUS)) > 1),
                              by = NACCID]

mydata.UDS <- merge(mydata.UDS, amyloid_summary, by = "NACCID", all.x = TRUE)

mydata.UDS[, verification := ifelse(!is.na(all_positive) & !status_mixed, 1, 0)]

mydata.UDS[, reference := NA_real_]

mydata.UDS[verification == 1, reference := ifelse(all_positive, 1, ifelse(all_negative, 0, NA_real_))]

mydata.UDS[, reference := ifelse(verification == 0, NA_real_, reference)]

age.min <- 40
age.max <- 90
valid.index <- (mydata.UDS$CRAFTVRS >= 0) & (mydata.UDS$CRAFTVRS <= 44) & (mydata.UDS$NACCAGE >= age.min) & (mydata.UDS$NACCAGE <= age.max)
sum((mydata.UDS$NACCVNUM == 1) & (mydata.UDS$NACCNE4S != 9) & valid.index)
sum((mydata.UDS$NACCVNUM == 1) & (mydata.UDS$NACCNE4S != 9) & (mydata.UDS$verification == 1) & valid.index)

index.v1 <- (1:nrow(mydata.UDS)) * ((mydata.UDS$NACCVNUM == 1) & (mydata.UDS$NACCNE4S != 9) & (mydata.UDS$verification == 1) & valid.index)
index.whole <- (1:nrow(mydata.UDS)) * ((mydata.UDS$NACCVNUM == 1) & (mydata.UDS$NACCNE4S != 9) & valid.index)

N <- sum((mydata.UDS$NACCVNUM == 1) & (mydata.UDS$NACCNE4S != 9) & valid.index)
G <- pmin(mydata.UDS$NACCNE4S[index.whole] + 1, 2)
X <- mydata.UDS$NACCAGE[index.whole]
X <- (X - (age.min + age.max)/2)/((age.max - age.min)/2)
Z <- X
V <- mydata.UDS$verification[index.whole]
T.1 <- (44 - mydata.UDS$CRAFTVRS[index.whole] - 22)/22
T.2 <- mydata.UDS$reference[index.whole]
T.2[is.na(T.2)] <- -1
dim_X <- 1

Age <- mydata.UDS$NACCAGE[index.whole]
Age <- (Age - (age.min + age.max)/2)/((age.max - age.min)/2)
GENDER <- mydata.UDS$SEX[index.whole] - 1
DEP <- mydata.UDS$DEP[index.whole]
X.state <- GENDER*1 + DEP*2

bandwidth_selection <- function(fake, N, G, X, Z, V, T.1, T.2, dim_X, Age, GENDER, DEP, X.state){
  
  library("magrittr")
  
  ########## Basic functions ##########
  K <- function(x){ ifelse(abs(x) <= 1, 0.75*(1 - x^2), 0) }
  expit <- function(x){ 1/(1+exp(-x)) }
  b <- function(x){ (x^2)/2 }
  b.dot <- function(x){ x }
  b.dot.inverse <- function(x){ x }
  b.double.dot <- function(x){ 1 }
  c.mine <- function(y, phi){ -1/2*log(2*3.141593*phi)-y^2/(2*phi) }
  g <- function(x){ x }
  g.dot <- function(x) { 1 }
  g.inverse <- function(x){ x }
  density.glm <- function(t, theta, psi){ exp((t*theta - b(theta))/psi + c.mine(t, psi)) }
  c.mine.partial.psi <- function(y, psi){ -1/(2*psi) + y^2/(2*psi^2)}
  
  EM <- function(lambda, train.index, test.index, working.mode){
    
    ########## Transform data ##########
    
    G.test <- G[test.index]
    X.test <- X[test.index]
    Z.test <- Z[test.index]
    V.test <- V[test.index]
    T.1.test <- T.1[test.index]
    T.2.test <- T.2[test.index]
    Age.test <- Age[test.index]
    GENDER.test <- GENDER[test.index]
    DEP.test <- DEP[test.index]
    X.state.test <- X.state[test.index]
    
    N <- length(train.index)
    G <- G[train.index]
    X <- X[train.index]
    Z <- Z[train.index]
    V <- V[train.index]
    T.1 <- T.1[train.index]
    T.2 <- T.2[train.index]
    Age <- Age[train.index]
    GENDER <- GENDER[train.index]
    DEP <- DEP[train.index]
    X.state <- X.state[train.index]
    
    ########## Initial values ##########
    
    stage.1.estimation <- function(G, T.1, T.2){
      
      p1.hat <- 0.4
      p2.hat <- 0.6
      mu.0.hat <- -0.2
      mu.1.hat <- 0.2
      psi.0.hat <- 1
      psi.1.hat <- 1
      sens.2.hat <- 0.6
      spec.2.hat <- 0.6
      
      old.params <- c(p1.hat, p2.hat, mu.0.hat, mu.1.hat, psi.0.hat, psi.1.hat, sens.2.hat, spec.2.hat)
      new.params <- numeric(length(old.params))
      while (sum(abs(old.params - new.params))>1e-3) {
        old.params <- c(p1.hat, p2.hat, mu.0.hat, mu.1.hat, psi.0.hat, psi.1.hat, sens.2.hat, spec.2.hat)
        
        l1 <- ((G==1)*p1.hat + (G==2)*p2.hat)*(dnorm(T.1, mean = mu.1.hat, sd = sqrt(psi.1.hat)))*(sens.2.hat*T.2 + (1 - sens.2.hat)*(1 - T.2))
        l0 <- (1 - ((G==1)*p1.hat + (G==2)*p2.hat))*(dnorm(T.1, mean = mu.0.hat, sd = sqrt(psi.0.hat)))*((1 - spec.2.hat)*T.2 + spec.2.hat*(1 - T.2))
        r <- l1/(l1 + l0)
        
        r[is.nan(r)] <- mean(r[!is.nan(r)])
        
        p1.hat <- sum((G==1)*r)/sum(G==1)
        p2.hat <- sum((G==2)*r)/sum(G==2)
        mu.0.hat <- sum((1 - r)*T.1)/sum(1 - r)
        mu.1.hat <- sum(r*T.1)/sum(r)
        psi.0.hat <- sum((1 - r)*((T.1 - mu.0.hat)^2))/sum(1 - r)
        psi.1.hat <- sum(r*((T.1 - mu.1.hat)^2))/sum(r)
        sens.2.hat <- sum(T.2*r)/sum(r)
        spec.2.hat <- sum((1 - T.2)*(1 - r))/sum(1 - r)
        
        new.params <- c(p1.hat, p2.hat, mu.0.hat, mu.1.hat, psi.0.hat, psi.1.hat, sens.2.hat, spec.2.hat)
        
      }
      
      return(new.params)
      
    }
    
    stage.1.result <- stage.1.estimation(G = G[V==1], T.1 = T.1[V==1], T.2 = T.2[V==1])
    
    ########## The first step ##########
    
    p.D.v1.hat <- numeric(N)
    p.D.v1.hat[G==1] <- stage.1.result[1]
    p.D.v1.hat[G==2] <- stage.1.result[2]
    
    mu.v1.hat <- matrix(0, ncol = 2, nrow = N)
    mu.v1.hat[, 1] <- stage.1.result[3]
    mu.v1.hat[, 2] <- stage.1.result[4]
    
    theta.v1.hat <- matrix(0, ncol = 2, nrow = N)
    theta.v1.hat[, 1] <- b.dot.inverse(mu.v1.hat[, 1])
    theta.v1.hat[, 2] <- b.dot.inverse(mu.v1.hat[, 2])
    
    psi.0.hat <- rep(stage.1.result[5], N)
    psi.1.hat <- rep(stage.1.result[6], N)
    
    p.T.2.hat <- matrix(0, ncol = 2, nrow = N)
    p.T.2.hat[, 1] <- 1 - stage.1.result[8]
    p.T.2.hat[, 2] <- stage.1.result[7]
    
    old.params <- c(p.D.v1.hat, as.numeric(mu.v1.hat), psi.0.hat, psi.1.hat, as.numeric(p.T.2.hat))
    new.params <- numeric(length(old.params))
    record <- 0
    
    K_matrix <- outer(X[V==1], X[V==1], Vectorize(function(x, y) K((x - y) / lambda)))
    
    ########## EM ##########
    
    while ((max(abs(old.params - new.params)) > 1e-3)&&(record <= 100)) {
      
      old.params <- c(p.D.v1.hat, as.numeric(mu.v1.hat), psi.0.hat, psi.1.hat, as.numeric(p.T.2.hat))
      
      l1 <- p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], psi.1.hat)*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))
      l0 <- (1 - p.D.v1.hat)*density.glm(T.1, theta.v1.hat[, 1], psi.0.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1]))
      r <- l1/(l1 + l0)
      r[(is.nan(r))&(V==1)] <- mean(r[(!is.nan(r))&(V==1)])
      
      for (state.temp in sort(unique(X.state))) {
        temp <- ((K_matrix%*%as.matrix((G[V==1]==1)*(X.state[V==1]==state.temp)*r[V==1]))/(K_matrix%*%as.matrix((G[V==1]==1)*(X.state[V==1]==state.temp)))) %>% as.numeric()
        p.D.v1.hat[(G==1)&(V==1)&(X.state==state.temp)] <- temp[(G[V==1]==1)&(X.state[V==1]==state.temp)]
        temp <- ((K_matrix%*%as.matrix((G[V==1]==2)*(X.state[V==1]==state.temp)*r[V==1]))/(K_matrix%*%as.matrix((G[V==1]==2)*(X.state[V==1]==state.temp)))) %>% as.numeric()
        p.D.v1.hat[(G==2)&(V==1)&(X.state==state.temp)] <- temp[(G[V==1]==2)&(X.state[V==1]==state.temp)]
      }
      
      for (state.temp in sort(unique(X.state))) {
        temp <- ((K_matrix%*%as.matrix((1 - r[V==1])*(X.state[V==1]==state.temp)*T.1[V==1]))/(K_matrix%*%as.matrix((1 - r[V==1])*(X.state[V==1]==state.temp)))) %>% as.numeric()
        mu.v1.hat[(V==1)&(X.state==state.temp), 1] <- temp[X.state[V==1]==state.temp]
        temp <- ((K_matrix%*%as.matrix(r[V==1]*(X.state[V==1]==state.temp)*T.1[V==1]))/(K_matrix%*%as.matrix(r[V==1]*(X.state[V==1]==state.temp)))) %>% as.numeric()
        mu.v1.hat[(V==1)&(X.state==state.temp), 2] <- temp[X.state[V==1]==state.temp]
      }
      mu.v1.hat[(V==1)&is.nan(mu.v1.hat[, 1]), 1] <- mean(mu.v1.hat[(V==1)&(!is.nan(mu.v1.hat[, 1])), 1])
      mu.v1.hat[(V==1)&is.nan(mu.v1.hat[, 2]), 2] <- mean(mu.v1.hat[(V==1)&(!is.nan(mu.v1.hat[, 2])), 2])
      
      psi.0.hat[V==1] <- ((K_matrix%*%as.matrix((1 - r[V==1])*((T.1[V==1] - mu.v1.hat[V==1, 1])^2)))/(K_matrix%*%as.matrix((1 - r[V==1])))) %>% as.numeric()
      psi.1.hat[V==1] <- ((K_matrix%*%as.matrix(r[V==1]*((T.1[V==1] - mu.v1.hat[V==1, 2])^2)))/(K_matrix%*%as.matrix(r[V==1]))) %>% as.numeric()
      psi.0.hat[is.nan(psi.0.hat)] <- mean(psi.0.hat[!is.nan(psi.0.hat)])
      psi.1.hat[is.nan(psi.1.hat)] <- mean(psi.1.hat[!is.nan(psi.1.hat)])
      
      for (state.temp in sort(unique(X.state))) {
        temp <- ((K_matrix%*%as.matrix((1 - r[V==1])*(X.state[V==1]==state.temp)*(1 - T.2[V==1])))/(K_matrix%*%as.matrix((1 - r[V==1])*(X.state[V==1]==state.temp)))) %>% as.numeric()
        p.T.2.hat[(V==1)&(X.state==state.temp), 1] <- 1 - temp[X.state[V==1]==state.temp]
        temp <- ((K_matrix%*%as.matrix(r[V==1]*(X.state[V==1]==state.temp)*T.2[V==1]))/(K_matrix%*%as.matrix(r[V==1]*(X.state[V==1]==state.temp)))) %>% as.numeric()
        p.T.2.hat[(V==1)&(X.state==state.temp), 2] <- temp[X.state[V==1]==state.temp]
      }
      p.T.2.hat[(V==1)&is.nan(p.T.2.hat[, 1]), 1] <- mean(p.T.2.hat[(V==1)&(!is.nan(p.T.2.hat[, 1])), 1])
      p.T.2.hat[(V==1)&is.nan(p.T.2.hat[, 2]), 2] <- mean(p.T.2.hat[(V==1)&(!is.nan(p.T.2.hat[, 2])), 2])
      
      new.params <- c(p.D.v1.hat, as.numeric(mu.v1.hat), psi.0.hat, psi.1.hat, as.numeric(p.T.2.hat))
      record = record + 1
      
    }
    
    p.D.v1.hat <- lapply(1:N, FUN = function(i) V[i]*p.D.v1.hat[i] + (1 - V[i])*((p.D.v1.hat[(G==G[i])&(V==1)&(X.state==X.state[i])])[which.min(abs(X[(G==G[i])&(V==1)&(X.state==X.state[i])] - X[i]))])) %>% as.numeric()
    p.D.v1.hat[is.na(p.D.v1.hat)] <- mean(p.D.v1.hat[!is.na(p.D.v1.hat)])
    mu.v1.hat[, 1] <- lapply(1:N, FUN = function(i) V[i]*mu.v1.hat[i, 1] + (1 - V[i])*((mu.v1.hat[(V==1)&(X.state==X.state[i]), 1])[which.min(abs(X[(V==1)&(X.state==X.state[i])] - X[i]))])) %>% as.numeric()
    mu.v1.hat[, 2] <- lapply(1:N, FUN = function(i) V[i]*mu.v1.hat[i, 2] + (1 - V[i])*((mu.v1.hat[(V==1)&(X.state==X.state[i]), 2])[which.min(abs(X[(V==1)&(X.state==X.state[i])] - X[i]))])) %>% as.numeric()
    mu.v1.hat[is.na(mu.v1.hat[, 1]), 1] <- mean(mu.v1.hat[!is.na(mu.v1.hat[, 1]), 1])
    mu.v1.hat[is.na(mu.v1.hat[, 2]), 2] <- mean(mu.v1.hat[!is.na(mu.v1.hat[, 2]), 2])
    psi.0.hat <- lapply(1:N, FUN = function(i) V[i]*psi.0.hat[i] + (1 - V[i])*((psi.0.hat[V==1])[which.min(abs(X[V==1] - X[i]))])) %>% as.numeric()
    psi.1.hat <- lapply(1:N, FUN = function(i) V[i]*psi.1.hat[i] + (1 - V[i])*((psi.1.hat[V==1])[which.min(abs(X[V==1] - X[i]))])) %>% as.numeric()
    psi.0.hat[is.na(psi.0.hat)] <- mean(psi.0.hat[!is.na(psi.0.hat)])
    psi.1.hat[is.na(psi.1.hat)] <- mean(psi.1.hat[!is.na(psi.1.hat)])
    psi.0.hat[which(psi.0.hat <= 1e-3)] <- psi.0.hat[which(psi.0.hat >= 1e-3)] %>% min()
    psi.1.hat[which(psi.1.hat <= 1e-3)] <- psi.1.hat[which(psi.1.hat >= 1e-3)] %>% min()
    p.T.2.hat[, 1] <- lapply(1:N, FUN = function(i) V[i]*p.T.2.hat[i, 1] + (1 - V[i])*((p.T.2.hat[(V==1)&(X.state==X.state[i]), 1])[which.min(abs(X[(V==1)&(X.state==X.state[i])] - X[i]))])) %>% as.numeric()
    p.T.2.hat[, 2] <- lapply(1:N, FUN = function(i) V[i]*p.T.2.hat[i, 2] + (1 - V[i])*((p.T.2.hat[(V==1)&(X.state==X.state[i]), 2])[which.min(abs(X[(V==1)&(X.state==X.state[i])] - X[i]))])) %>% as.numeric()
    p.T.2.hat[is.na(p.T.2.hat[, 1]), 1] <- mean(p.T.2.hat[!is.na(p.T.2.hat[, 1]), 1])
    p.T.2.hat[is.na(p.T.2.hat[, 2]), 2] <- mean(p.T.2.hat[!is.na(p.T.2.hat[, 2]), 2])
    
    ########## The second step ##########
    
    theta.v1.hat <- matrix(0, ncol = 2, nrow = N)
    theta.v1.hat[, 1] <- b.dot.inverse(mu.v1.hat[, 1])
    theta.v1.hat[, 2] <- b.dot.inverse(mu.v1.hat[, 2])
    
    X <- matrix(c(Age, GENDER, DEP), ncol = 3)
    dim_X <- 3
    
    alpha.0.hat <- 0
    alpha.1.hat <- 0
    alpha.X.hat <- numeric(length = dim_X)
    alpha.TX.hat <- numeric(length = dim_X)
    beta.0.hat <- 0
    beta.1.hat <- 0
    beta.X.hat <- numeric(length = dim_X)
    beta.TX.hat <- numeric(length = dim_X)
    
    f3 <- function(params){
      
      alpha.0 <- params[1]
      alpha.1 <- params[2]
      alpha.X <- params[3:(2+dim_X)]
      alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
      beta.0 <- params[3+2*dim_X]
      beta.1 <- params[4+2*dim_X]
      beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
      beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
      
      theta.v0 <- matrix(0, ncol = 2, nrow = N)
      theta.v0[, 1] <- theta.v1.hat[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0.hat
      theta.v0[, 2] <- theta.v1.hat[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1.hat
      
      temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat)/((1 - p.D.v1.hat)*exp((b(theta.v0[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat))
      p.D.v0 <- temp1/(1+temp1)
      p.D.v0[is.nan(p.D.v0)] <- 1
      
      temp2 <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
        ((1 - p.D.v1.hat)*exp((b(theta.v0[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat) + 
           exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat))
      p.V <- 1/(1 + temp2)
      
      likelihood <- (
        (1 - V)*((
          (1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], psi.0.hat) +
            p.D.v0*density.glm(T.1, theta.v0[, 2], psi.1.hat)
        ) %>% log()) +
          (1 - V)*((1 - p.V) %>% log()) + V*(p.V %>% log())
      ) %>% sum()
      
      return(-likelihood)
    }
    
    temp <- optim(par = c(alpha.0.hat, alpha.1.hat, alpha.X.hat, alpha.TX.hat, beta.0.hat, beta.1.hat, beta.X.hat, beta.TX.hat), fn = f3, method = "BFGS")$par
    alpha.0.hat <- temp[1]
    alpha.1.hat <- temp[2]
    alpha.X.hat <- temp[3:(2+dim_X)]
    alpha.TX.hat <- temp[(3+dim_X):(2+2*dim_X)]
    beta.0.hat <- temp[3+2*dim_X]
    beta.1.hat <- temp[4+2*dim_X]
    beta.X.hat <- temp[(5+2*dim_X):(4+3*dim_X)]
    beta.TX.hat <- temp[(5+3*dim_X):(4+4*dim_X)]
    
    theta.v0.hat <- matrix(0, ncol = 2, nrow = N)
    theta.v0.hat[, 1] <- theta.v1.hat[ ,1] - (beta.1.hat + X%*%as.matrix(beta.TX.hat))*psi.0.hat
    theta.v0.hat[, 2] <- theta.v1.hat[ ,2] - (beta.1.hat + X%*%as.matrix(beta.TX.hat) + alpha.1.hat + X%*%as.matrix(alpha.TX.hat))*psi.1.hat
    
    mu.v0.hat <- matrix(0, ncol = 2, nrow = N)
    mu.v0.hat[, 1] <- b.dot(theta.v0.hat[, 1])
    mu.v0.hat[, 2] <- b.dot(theta.v0.hat[, 2])
    
    temp1 <- exp((-alpha.0.hat - X%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0.hat[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat)/((1 - p.D.v1.hat)*exp((b(theta.v0.hat[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat))
    p.D.v0.hat <- temp1/(1+temp1)
    p.D.v0.hat[is.nan(p.D.v0.hat)] <- 1
    
    temp2 <- exp(-beta.0.hat - X%*%as.matrix(beta.X.hat) %>% as.numeric()) * 
      ((1 - p.D.v1.hat)*exp((b(theta.v0.hat[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat) + 
         exp((-alpha.0.hat - X%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0.hat[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat))
    p.V.hat <- 1/(1 + temp2)
    
    
    if(working.mode == "CV"){
      
      X <- Age
      
      ##### calculate outcome ######
      M <- length(test.index)
      
      p.D.v1.hat.test <- numeric(M)
      p.D.v1.hat.test <- lapply(1:M, FUN = function(i) (p.D.v1.hat[(G==G.test[i])&(X.state==X.state.test[i])])[which.min(abs(X[(G==G.test[i])&(X.state==X.state.test[i])] - X.test[i]))]) %>% as.numeric()
      p.D.v1.hat.test[is.na(p.D.v1.hat.test)] <- mean(p.D.v1.hat.test[!is.na(p.D.v1.hat.test)])
      
      mu.v1.hat.test <- matrix(0, ncol = 2, nrow = M)
      mu.v1.hat.test[, 1] <- lapply(1:M, FUN = function(i) (mu.v1.hat[(X.state==X.state.test[i]), 1])[which.min(abs(X[(X.state==X.state.test[i])] - X.test[i]))]) %>% as.numeric()
      mu.v1.hat.test[, 2] <- lapply(1:M, FUN = function(i) (mu.v1.hat[(X.state==X.state.test[i]), 2])[which.min(abs(X[(X.state==X.state.test[i])] - X.test[i]))]) %>% as.numeric()
      mu.v1.hat.test[is.na(mu.v1.hat.test[, 1]), 1] <- mean(mu.v1.hat.test[!is.na(mu.v1.hat.test[, 1]), 1])
      mu.v1.hat.test[is.na(mu.v1.hat.test[, 2]), 2] <- mean(mu.v1.hat.test[!is.na(mu.v1.hat.test[, 2]), 2])
      
      theta.v1.hat.test <- matrix(0, ncol = 2, nrow = M)
      theta.v1.hat.test[, 1] <- b.dot.inverse(mu.v1.hat.test[, 1])
      theta.v1.hat.test[, 2] <- b.dot.inverse(mu.v1.hat.test[, 2])
      
      psi.0.hat.test <- numeric(M)
      psi.1.hat.test <- numeric(M)
      psi.0.hat.test <- lapply(1:M, FUN = function(i) (psi.0.hat)[which.min(abs(X - X.test[i]))]) %>% as.numeric()
      psi.1.hat.test <- lapply(1:M, FUN = function(i) (psi.1.hat)[which.min(abs(X - X.test[i]))]) %>% as.numeric()
      psi.0.hat.test[is.na(psi.0.hat.test)] <- mean(psi.0.hat.test[!is.na(psi.0.hat.test)])
      psi.1.hat.test[is.na(psi.1.hat.test)] <- mean(psi.1.hat.test[!is.na(psi.1.hat.test)])
      psi.0.hat.test[which(psi.0.hat.test <= 1e-3)] <- psi.0.hat.test[which(psi.0.hat.test >= 1e-3)] %>% min()
      psi.1.hat.test[which(psi.1.hat.test <= 1e-3)] <- psi.1.hat.test[which(psi.1.hat.test >= 1e-3)] %>% min()
      
      p.T.2.hat.test <- matrix(0, ncol = 2, nrow = M)
      p.T.2.hat.test[, 1] <- lapply(1:M, FUN = function(i) (p.T.2.hat[(X.state==X.state.test[i]), 1])[which.min(abs(X[(X.state==X.state.test[i])] - X.test[i]))]) %>% as.numeric()
      p.T.2.hat.test[, 2] <- lapply(1:M, FUN = function(i) (p.T.2.hat[(X.state==X.state.test[i]), 2])[which.min(abs(X[(X.state==X.state.test[i])] - X.test[i]))]) %>% as.numeric()
      p.T.2.hat.test[is.na(p.T.2.hat.test[, 1]), 1] <- mean(p.T.2.hat.test[!is.na(p.T.2.hat.test[, 1]), 1])
      p.T.2.hat.test[is.na(p.T.2.hat.test[, 2]), 2] <- mean(p.T.2.hat.test[!is.na(p.T.2.hat.test[, 2]), 2])
      p.T.2.hat.test[(p.T.2.hat.test[, 1] == 0), 1] <- p.T.2.hat.test[(p.T.2.hat.test[, 1] != 0), 1] %>% min()
      p.T.2.hat.test[(p.T.2.hat.test[, 1] == 1), 1] <- p.T.2.hat.test[(p.T.2.hat.test[, 1] != 1), 1] %>% max()
      p.T.2.hat.test[(p.T.2.hat.test[, 2] == 1), 2] <- p.T.2.hat.test[(p.T.2.hat.test[, 2] != 1), 2] %>% max()
      p.T.2.hat.test[(p.T.2.hat.test[, 2] == 0), 2] <- p.T.2.hat.test[(p.T.2.hat.test[, 2] != 0), 2] %>% min()
      
      X.test <- matrix(c(Age.test, GENDER.test, DEP.test), ncol = 3)
      dim_X <- 3
      
      theta.v0.hat.test <- matrix(0, ncol = 2, nrow = length(test.index))
      theta.v0.hat.test[, 1] <- theta.v1.hat.test[ ,1] - (beta.1.hat + X.test%*%as.matrix(beta.TX.hat))*psi.0.hat.test
      theta.v0.hat.test[, 2] <- theta.v1.hat.test[ ,2] - (beta.1.hat + X.test%*%as.matrix(beta.TX.hat) + alpha.1.hat + X.test%*%as.matrix(alpha.TX.hat))*psi.1.hat.test
      
      temp <- exp((-alpha.0.hat - X.test%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat.test*exp((b(theta.v0.hat.test[, 2]) - b(theta.v1.hat.test[, 2]))/psi.1.hat.test)/((1 - p.D.v1.hat.test)*exp((b(theta.v0.hat.test[, 1]) - b(theta.v1.hat.test[, 1]))/psi.0.hat.test))
      p.D.v0.hat.test <- temp/(1+temp)
      p.D.v0.hat.test[is.nan(p.D.v0.hat.test)] <- 1
      
      temp <- exp(-beta.0.hat - X.test%*%as.matrix(beta.X.hat) %>% as.numeric()) * 
        ((1 - p.D.v1.hat.test)*exp((b(theta.v0.hat.test[, 1]) - b(theta.v1.hat.test[, 1]))/psi.0.hat.test) + 
           exp((-alpha.0.hat - X.test%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat.test*exp((b(theta.v0.hat.test[, 2]) - b(theta.v1.hat.test[, 2]))/psi.1.hat.test))
      p.V.hat.test <- 1/(1 + temp)
      
      T.2.test[which(T.2.test < 0)] <- 0
      
      likelihood <- (V.test*((
        (1 - p.D.v1.hat.test)*density.glm(T.1.test, theta.v1.hat.test[, 1], psi.0.hat.test)*(T.2.test*(p.T.2.hat.test[, 1]) + (1 - T.2.test)*(1 - p.T.2.hat.test[, 1])) +
          p.D.v1.hat.test*density.glm(T.1.test, theta.v1.hat.test[, 2], psi.1.hat.test)*(T.2.test*(p.T.2.hat.test[, 2]) + (1 - T.2.test)*(1 - p.T.2.hat.test[, 2]))
      ) %>% log())) %>% sum() + (
        (1 - V.test)*((
          (1 - p.D.v0.hat.test)*density.glm(T.1.test, theta.v0.hat.test[, 1], psi.0.hat.test) +
            p.D.v0.hat.test*density.glm(T.1.test, theta.v0.hat.test[, 2], psi.1.hat.test)
        ) %>% log()) +
          (1 - V.test)*((1 - p.V.hat.test) %>% log()) + V.test*(p.V.hat.test %>% log())
      ) %>% sum()

      return(likelihood)
    }else{
      
      return("FALSE")
      
    }
    
  }
  
  #####
  number.of.folds <- 5
  bandwidths <- c(1.9, 1.95, 1.9, 1.85, 1.8, 1.75, 1.7, 1.65, 1.6, 1.55, 1.5, 1.45, 1.4, 1.35, 1.3, 1.25, 1.2, 1.15, 1.1, 1.05, 1.0)
  cv.likelihood <- array(0, dim = c(length(bandwidths) , number.of.folds))
  
  folds <- createFolds(T.1, k = number.of.folds)
  
  tryCatch({
    for (lambda in seq_along(bandwidths)) {
      for (j in seq_along(folds)) {
        test.index <- folds[[j]]
        train.index <- setdiff(seq_len(N), test.index)
        cv.likelihood[lambda, j] <- EM(lambda = bandwidths[lambda], train.index = train.index, test.index = test.index, working.mode = "CV")
      }
    }
    
    return(cv.likelihood)
    
  }, error = function(e){
    return("FALSE")
  })
  
}

library(parallel)

num_simulations <- 30
cl <- makeCluster(num_simulations)
clusterExport(cl, c("bandwidth_selection", "N", "G", "X", "Z", "V", "T.1", "T.2", "dim_X", "Age", "GENDER", "DEP", "X.state"))
num_repetitions <- 1

results <- list()
for (fake_value in 1:num_repetitions) {
  print(fake_value)
  fake_values <- rep(fake_value, num_simulations)
  simulation_results <- parLapply(cl, fake_values, function(fake, N, G, X, Z, V, T.1, T.2, dim_X, Age, GENDER, DEP, X.state){
    bandwidth_selection(fake, N, G, X, Z, V, T.1, T.2, dim_X, Age, GENDER, DEP, X.state)
  }, N, G, X, Z, V, T.1, T.2, dim_X, Age, GENDER, DEP, X.state)
  results[[fake_value]] <- simulation_results
}
stopCluster(cl)

unfold <- list()
for (i in 1:num_repetitions) {
  unfold <- c(unfold, results[[i]])
}

cv.likelihood <- array(0, dim = c(length(unfold), dim(unfold[[1]])[1] , dim(unfold[[1]])[2]))
for (i in 1:length(unfold)) {
  cv.likelihood[i, , ] <- unfold[[i]]
}

save(file = "Bandwidth.Rdata", cv.likelihood)

if(length(which(cv.likelihood[, 1, 1] == "FALSE")) > 0) {cv.likelihood <- cv.likelihood[-which(cv.likelihood[, 1, 1] == "FALSE"), , ]}
lapply(1:dim(cv.likelihood)[2], FUN = function(i) mean(as.numeric(cv.likelihood[, i, ]))) %>% as.numeric()


