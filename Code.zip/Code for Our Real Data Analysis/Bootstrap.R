########## Read data ##########
library("data.table")
library("magrittr")

########## Basic functions ##########
K <- function(x){ ifelse(abs(x) <= 1, 0.75*(1 - x^2), 0) }
expit <- function(x){ 1/(1+exp(-x)) }
b <- function(x){ (x^2)/2 }
b.dot <- function(x){ x }
b.dot.inverse <- function(x){ x }
b.double.dot <- function(x){ 1 }
c.mine <- function(y, phi){ -1/2*log(2*3.141593*phi)-y^2/(2*phi) }
g <- function(x){ x }
g.dot <- function(x) { 1 }
g.inverse <- function(x){ x }
density.glm <- function(t, theta, psi){ exp((t*theta - b(theta))/psi + c.mine(t, psi)) }
c.mine.partial.psi <- function(y, psi){ -1/(2*psi) + y^2/(2*psi^2)}

########## Read data ##########
mydata.UDS <- fread("UDS.csv")
mydata.PET <- fread("PET.csv")

setDT(mydata.UDS)
setDT(mydata.PET)

amyloid_summary <- mydata.PET[, .(all_positive = all(AMYLOID_STATUS == 1),
                                  all_negative = all(AMYLOID_STATUS == 0),
                                  status_mixed = length(unique(AMYLOID_STATUS)) > 1),
                              by = NACCID]

mydata.UDS <- merge(mydata.UDS, amyloid_summary, by = "NACCID", all.x = TRUE)

mydata.UDS[, verification := ifelse(!is.na(all_positive) & !status_mixed, 1, 0)]

mydata.UDS[, reference := NA_real_]

mydata.UDS[verification == 1, reference := ifelse(all_positive, 1, ifelse(all_negative, 0, NA_real_))]

mydata.UDS[, reference := ifelse(verification == 0, NA_real_, reference)]

age.min <- 40
age.max <- 90
valid.index <- (mydata.UDS$CRAFTVRS >= 0) & (mydata.UDS$CRAFTVRS <= 44) & (mydata.UDS$NACCAGE >= age.min) & (mydata.UDS$NACCAGE <= age.max)
sum((mydata.UDS$NACCVNUM == 1) & (mydata.UDS$NACCNE4S != 9) & valid.index)
sum((mydata.UDS$NACCVNUM == 1) & (mydata.UDS$NACCNE4S != 9) & (mydata.UDS$verification == 1) & valid.index)

index.v1 <- (1:nrow(mydata.UDS)) * ((mydata.UDS$NACCVNUM == 1) & (mydata.UDS$NACCNE4S != 9) & (mydata.UDS$verification == 1) & valid.index)
index.whole <- (1:nrow(mydata.UDS)) * ((mydata.UDS$NACCVNUM == 1) & (mydata.UDS$NACCNE4S != 9) & valid.index)

N <- sum((mydata.UDS$NACCVNUM == 1) & (mydata.UDS$NACCNE4S != 9) & valid.index)
G <- pmin(mydata.UDS$NACCNE4S[index.whole] + 1, 2)
X <- mydata.UDS$NACCAGE[index.whole]
X <- (X - (age.min + age.max)/2)/((age.max - age.min)/2)
Z <- X
V <- mydata.UDS$verification[index.whole]
T.1 <- (44 - mydata.UDS$CRAFTVRS[index.whole] - 22)/22
T.2 <- mydata.UDS$reference[index.whole]
T.2[is.na(T.2)] <- -1
dim_X <- 1

Age <- mydata.UDS$NACCAGE[index.whole]
Age <- (Age - (age.min + age.max)/2)/((age.max - age.min)/2)
GENDER <- mydata.UDS$SEX[index.whole] - 1
DEP <- mydata.UDS$DEP[index.whole]
X.state <- GENDER*1 + DEP*2

simulation <- function(fake, N, G, X, Z, V, T.1, T.2, dim_X, Age, GENDER, DEP, X.state){
  
  library("magrittr")
  
  lambda.cv <- 0.47
  
  K <- function(x){ ifelse(abs(x) <= 1, 0.75*(1 - x^2), 0) }
  expit <- function(x){ 1/(1+exp(-x)) }
  b <- function(x){ (x^2)/2 }
  b.dot <- function(x){ x }
  b.dot.inverse <- function(x){ x }
  b.double.dot <- function(x){ 1 }
  c.mine <- function(y, phi){ -1/2*log(2*3.141593*phi)-y^2/(2*phi) }
  g <- function(x){ x }
  g.dot <- function(x) { 1 }
  g.inverse <- function(x){ x }
  density.glm <- function(t, theta, psi){ exp((t*theta - b(theta))/psi + c.mine(t, psi)) }
  c.mine.partial.psi <- function(y, psi){ -1/(2*psi) + y^2/(2*psi^2)}
  
  EM <- function(lambda, train.index, test.index, working.mode){
    
    G.test <- G[test.index]
    X.test <- X[test.index]
    Z.test <- Z[test.index]
    V.test <- V[test.index]
    T.1.test <- T.1[test.index]
    T.2.test <- T.2[test.index]
    Age.test <- Age[test.index]
    GENDER.test <- GENDER[test.index]
    DEP.test <- DEP[test.index]
    X.state.test <- X.state[test.index]
    
    N <- length(train.index)
    G <- G[train.index]
    X <- X[train.index]
    Z <- Z[train.index]
    V <- V[train.index]
    T.1 <- T.1[train.index]
    T.2 <- T.2[train.index]
    Age <- Age[train.index]
    GENDER <- GENDER[train.index]
    DEP <- DEP[train.index]
    X.state <- X.state[train.index]
    
    stage.1.estimation <- function(G, T.1, T.2){
      
      p1.hat <- 0.4
      p2.hat <- 0.6
      mu.0.hat <- -0.2
      mu.1.hat <- 0.2
      psi.0.hat <- 1
      psi.1.hat <- 1
      sens.2.hat <- 0.6
      spec.2.hat <- 0.6
      
      old.params <- c(p1.hat, p2.hat, mu.0.hat, mu.1.hat, psi.0.hat, psi.1.hat, sens.2.hat, spec.2.hat)
      new.params <- numeric(length(old.params))
      while (sum(abs(old.params - new.params))>1e-3) {
        old.params <- c(p1.hat, p2.hat, mu.0.hat, mu.1.hat, psi.0.hat, psi.1.hat, sens.2.hat, spec.2.hat)
        
        l1 <- ((G==1)*p1.hat + (G==2)*p2.hat)*(dnorm(T.1, mean = mu.1.hat, sd = sqrt(psi.1.hat)))*(sens.2.hat*T.2 + (1 - sens.2.hat)*(1 - T.2))
        l0 <- (1 - ((G==1)*p1.hat + (G==2)*p2.hat))*(dnorm(T.1, mean = mu.0.hat, sd = sqrt(psi.0.hat)))*((1 - spec.2.hat)*T.2 + spec.2.hat*(1 - T.2))
        r <- l1/(l1 + l0)
        
        r[is.nan(r)] <- mean(r[!is.nan(r)])
        
        p1.hat <- sum((G==1)*r)/sum(G==1)
        p2.hat <- sum((G==2)*r)/sum(G==2)
        mu.0.hat <- sum((1 - r)*T.1)/sum(1 - r)
        mu.1.hat <- sum(r*T.1)/sum(r)
        psi.0.hat <- sum((1 - r)*((T.1 - mu.0.hat)^2))/sum(1 - r)
        psi.1.hat <- sum(r*((T.1 - mu.1.hat)^2))/sum(r)
        sens.2.hat <- sum(T.2*r)/sum(r)
        spec.2.hat <- sum((1 - T.2)*(1 - r))/sum(1 - r)
        
        new.params <- c(p1.hat, p2.hat, mu.0.hat, mu.1.hat, psi.0.hat, psi.1.hat, sens.2.hat, spec.2.hat)
        
      }
      
      return(new.params)
      
    }
    
    stage.1.result <- stage.1.estimation(G = G[V==1], T.1 = T.1[V==1], T.2 = T.2[V==1])
    
    p.D.v1.hat <- numeric(N)
    p.D.v1.hat[G==1] <- stage.1.result[1]
    p.D.v1.hat[G==2] <- stage.1.result[2]
    
    mu.v1.hat <- matrix(0, ncol = 2, nrow = N)
    mu.v1.hat[, 1] <- stage.1.result[3]
    mu.v1.hat[, 2] <- stage.1.result[4]
    
    theta.v1.hat <- matrix(0, ncol = 2, nrow = N)
    theta.v1.hat[, 1] <- b.dot.inverse(mu.v1.hat[, 1])
    theta.v1.hat[, 2] <- b.dot.inverse(mu.v1.hat[, 2])
    
    psi.0.hat <- rep(stage.1.result[5], N)
    psi.1.hat <- rep(stage.1.result[6], N)
    
    p.T.2.hat <- matrix(0, ncol = 2, nrow = N)
    p.T.2.hat[, 1] <- 1 - stage.1.result[8]
    p.T.2.hat[, 2] <- stage.1.result[7]
    
    old.params <- c(p.D.v1.hat, as.numeric(mu.v1.hat), psi.0.hat, psi.1.hat, as.numeric(p.T.2.hat))
    new.params <- numeric(length(old.params))
    record <- 0
    
    K_matrix <- outer(X[V==1], X[V==1], Vectorize(function(x, y) K((x - y) / lambda)))
    
    while ((max(abs(old.params - new.params)) > 1e-3)&&(record <= 100)) {
      
      old.params <- c(p.D.v1.hat, as.numeric(mu.v1.hat), psi.0.hat, psi.1.hat, as.numeric(p.T.2.hat))
      
      l1 <- p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], psi.1.hat)*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))
      l0 <- (1 - p.D.v1.hat)*density.glm(T.1, theta.v1.hat[, 1], psi.0.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1]))
      r <- l1/(l1 + l0)
      r[(is.nan(r))&(V==1)] <- mean(r[(!is.nan(r))&(V==1)])
      
      for (state.temp in sort(unique(X.state))) {
        temp <- ((K_matrix%*%as.matrix((G[V==1]==1)*(X.state[V==1]==state.temp)*r[V==1]))/(K_matrix%*%as.matrix((G[V==1]==1)*(X.state[V==1]==state.temp)))) %>% as.numeric()
        p.D.v1.hat[(G==1)&(V==1)&(X.state==state.temp)] <- temp[(G[V==1]==1)&(X.state[V==1]==state.temp)]
        temp <- ((K_matrix%*%as.matrix((G[V==1]==2)*(X.state[V==1]==state.temp)*r[V==1]))/(K_matrix%*%as.matrix((G[V==1]==2)*(X.state[V==1]==state.temp)))) %>% as.numeric()
        p.D.v1.hat[(G==2)&(V==1)&(X.state==state.temp)] <- temp[(G[V==1]==2)&(X.state[V==1]==state.temp)]
      }
      
      for (state.temp in sort(unique(X.state))) {
        temp <- ((K_matrix%*%as.matrix((1 - r[V==1])*(X.state[V==1]==state.temp)*T.1[V==1]))/(K_matrix%*%as.matrix((1 - r[V==1])*(X.state[V==1]==state.temp)))) %>% as.numeric()
        mu.v1.hat[(V==1)&(X.state==state.temp), 1] <- temp[X.state[V==1]==state.temp]
        temp <- ((K_matrix%*%as.matrix(r[V==1]*(X.state[V==1]==state.temp)*T.1[V==1]))/(K_matrix%*%as.matrix(r[V==1]*(X.state[V==1]==state.temp)))) %>% as.numeric()
        mu.v1.hat[(V==1)&(X.state==state.temp), 2] <- temp[X.state[V==1]==state.temp]
      }
      mu.v1.hat[(V==1)&is.nan(mu.v1.hat[, 1]), 1] <- mean(mu.v1.hat[(V==1)&(!is.nan(mu.v1.hat[, 1])), 1])
      mu.v1.hat[(V==1)&is.nan(mu.v1.hat[, 2]), 2] <- mean(mu.v1.hat[(V==1)&(!is.nan(mu.v1.hat[, 2])), 2])
      
      psi.0.hat[V==1] <- ((K_matrix%*%as.matrix((1 - r[V==1])*((T.1[V==1] - mu.v1.hat[V==1, 1])^2)))/(K_matrix%*%as.matrix((1 - r[V==1])))) %>% as.numeric()
      psi.1.hat[V==1] <- ((K_matrix%*%as.matrix(r[V==1]*((T.1[V==1] - mu.v1.hat[V==1, 2])^2)))/(K_matrix%*%as.matrix(r[V==1]))) %>% as.numeric()
      psi.0.hat[is.nan(psi.0.hat)] <- mean(psi.0.hat[!is.nan(psi.0.hat)])
      psi.1.hat[is.nan(psi.1.hat)] <- mean(psi.1.hat[!is.nan(psi.1.hat)])
      
      for (state.temp in sort(unique(X.state))) {
        temp <- ((K_matrix%*%as.matrix((1 - r[V==1])*(X.state[V==1]==state.temp)*(1 - T.2[V==1])))/(K_matrix%*%as.matrix((1 - r[V==1])*(X.state[V==1]==state.temp)))) %>% as.numeric()
        p.T.2.hat[(V==1)&(X.state==state.temp), 1] <- 1 - temp[X.state[V==1]==state.temp]
        temp <- ((K_matrix%*%as.matrix(r[V==1]*(X.state[V==1]==state.temp)*T.2[V==1]))/(K_matrix%*%as.matrix(r[V==1]*(X.state[V==1]==state.temp)))) %>% as.numeric()
        p.T.2.hat[(V==1)&(X.state==state.temp), 2] <- temp[X.state[V==1]==state.temp]
      }
      p.T.2.hat[(V==1)&is.nan(p.T.2.hat[, 1]), 1] <- mean(p.T.2.hat[(V==1)&(!is.nan(p.T.2.hat[, 1])), 1])
      p.T.2.hat[(V==1)&is.nan(p.T.2.hat[, 2]), 2] <- mean(p.T.2.hat[(V==1)&(!is.nan(p.T.2.hat[, 2])), 2])
      
      new.params <- c(p.D.v1.hat, as.numeric(mu.v1.hat), psi.0.hat, psi.1.hat, as.numeric(p.T.2.hat))
      record = record + 1
      
    }
    
    p.D.v1.hat <- lapply(1:N, FUN = function(i) V[i]*p.D.v1.hat[i] + (1 - V[i])*((p.D.v1.hat[(G==G[i])&(V==1)&(X.state==X.state[i])])[which.min(abs(X[(G==G[i])&(V==1)&(X.state==X.state[i])] - X[i]))])) %>% as.numeric()
    p.D.v1.hat[is.na(p.D.v1.hat)] <- mean(p.D.v1.hat[!is.na(p.D.v1.hat)])
    mu.v1.hat[, 1] <- lapply(1:N, FUN = function(i) V[i]*mu.v1.hat[i, 1] + (1 - V[i])*((mu.v1.hat[(V==1)&(X.state==X.state[i]), 1])[which.min(abs(X[(V==1)&(X.state==X.state[i])] - X[i]))])) %>% as.numeric()
    mu.v1.hat[, 2] <- lapply(1:N, FUN = function(i) V[i]*mu.v1.hat[i, 2] + (1 - V[i])*((mu.v1.hat[(V==1)&(X.state==X.state[i]), 2])[which.min(abs(X[(V==1)&(X.state==X.state[i])] - X[i]))])) %>% as.numeric()
    mu.v1.hat[is.na(mu.v1.hat[, 1]), 1] <- mean(mu.v1.hat[!is.na(mu.v1.hat[, 1]), 1])
    mu.v1.hat[is.na(mu.v1.hat[, 2]), 2] <- mean(mu.v1.hat[!is.na(mu.v1.hat[, 2]), 2])
    psi.0.hat <- lapply(1:N, FUN = function(i) V[i]*psi.0.hat[i] + (1 - V[i])*((psi.0.hat[V==1])[which.min(abs(X[V==1] - X[i]))])) %>% as.numeric()
    psi.1.hat <- lapply(1:N, FUN = function(i) V[i]*psi.1.hat[i] + (1 - V[i])*((psi.1.hat[V==1])[which.min(abs(X[V==1] - X[i]))])) %>% as.numeric()
    psi.0.hat[is.na(psi.0.hat)] <- mean(psi.0.hat[!is.na(psi.0.hat)])
    psi.1.hat[is.na(psi.1.hat)] <- mean(psi.1.hat[!is.na(psi.1.hat)])
    psi.0.hat[which(psi.0.hat <= 1e-3)] <- psi.0.hat[which(psi.0.hat >= 1e-3)] %>% min()
    psi.1.hat[which(psi.1.hat <= 1e-3)] <- psi.1.hat[which(psi.1.hat >= 1e-3)] %>% min()
    p.T.2.hat[, 1] <- lapply(1:N, FUN = function(i) V[i]*p.T.2.hat[i, 1] + (1 - V[i])*((p.T.2.hat[(V==1)&(X.state==X.state[i]), 1])[which.min(abs(X[(V==1)&(X.state==X.state[i])] - X[i]))])) %>% as.numeric()
    p.T.2.hat[, 2] <- lapply(1:N, FUN = function(i) V[i]*p.T.2.hat[i, 2] + (1 - V[i])*((p.T.2.hat[(V==1)&(X.state==X.state[i]), 2])[which.min(abs(X[(V==1)&(X.state==X.state[i])] - X[i]))])) %>% as.numeric()
    p.T.2.hat[is.na(p.T.2.hat[, 1]), 1] <- mean(p.T.2.hat[!is.na(p.T.2.hat[, 1]), 1])
    p.T.2.hat[is.na(p.T.2.hat[, 2]), 2] <- mean(p.T.2.hat[!is.na(p.T.2.hat[, 2]), 2])
    
    ##### Estimation Step 2 #####
    
    theta.v1.hat <- matrix(0, ncol = 2, nrow = N)
    theta.v1.hat[, 1] <- b.dot.inverse(mu.v1.hat[, 1])
    theta.v1.hat[, 2] <- b.dot.inverse(mu.v1.hat[, 2])
    
    X <- matrix(c(Age, GENDER, DEP), ncol = 3)
    dim_X <- 3
    
    alpha.0.hat <- 0
    alpha.1.hat <- 0
    alpha.X.hat <- numeric(length = dim_X)
    alpha.TX.hat <- numeric(length = dim_X)
    beta.0.hat <- 0
    beta.1.hat <- 0
    beta.X.hat <- numeric(length = dim_X)
    beta.TX.hat <- numeric(length = dim_X)
    
    f3 <- function(params){
      
      alpha.0 <- params[1]
      alpha.1 <- params[2]
      alpha.X <- params[3:(2+dim_X)]
      alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
      beta.0 <- params[3+2*dim_X]
      beta.1 <- params[4+2*dim_X]
      beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
      beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
      
      theta.v0 <- matrix(0, ncol = 2, nrow = N)
      theta.v0[, 1] <- theta.v1.hat[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0.hat
      theta.v0[, 2] <- theta.v1.hat[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1.hat
      
      temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat)/((1 - p.D.v1.hat)*exp((b(theta.v0[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat))
      p.D.v0 <- temp1/(1+temp1)
      p.D.v0[is.nan(p.D.v0)] <- 1
      
      temp2 <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
        ((1 - p.D.v1.hat)*exp((b(theta.v0[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat) + 
           exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat))
      p.V <- 1/(1 + temp2)
      
      likelihood <- (
        (1 - V)*((
          (1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], psi.0.hat) +
            p.D.v0*density.glm(T.1, theta.v0[, 2], psi.1.hat)
        ) %>% log()) +
          (1 - V)*((1 - p.V) %>% log()) + V*(p.V %>% log())
      ) %>% sum()
      
      return(-likelihood)
    }
    
    temp <- optim(par = c(alpha.0.hat, alpha.1.hat, alpha.X.hat, alpha.TX.hat, beta.0.hat, beta.1.hat, beta.X.hat, beta.TX.hat), fn = f3, method = "BFGS")$par
    alpha.0.hat <- temp[1]
    alpha.1.hat <- temp[2]
    alpha.X.hat <- temp[3:(2+dim_X)]
    alpha.TX.hat <- temp[(3+dim_X):(2+2*dim_X)]
    beta.0.hat <- temp[3+2*dim_X]
    beta.1.hat <- temp[4+2*dim_X]
    beta.X.hat <- temp[(5+2*dim_X):(4+3*dim_X)]
    beta.TX.hat <- temp[(5+3*dim_X):(4+4*dim_X)]
    
    theta.v0.hat <- matrix(0, ncol = 2, nrow = N)
    theta.v0.hat[, 1] <- theta.v1.hat[ ,1] - (beta.1.hat + X%*%as.matrix(beta.TX.hat))*psi.0.hat
    theta.v0.hat[, 2] <- theta.v1.hat[ ,2] - (beta.1.hat + X%*%as.matrix(beta.TX.hat) + alpha.1.hat + X%*%as.matrix(alpha.TX.hat))*psi.1.hat
    
    mu.v0.hat <- matrix(0, ncol = 2, nrow = N)
    mu.v0.hat[, 1] <- b.dot(theta.v0.hat[, 1])
    mu.v0.hat[, 2] <- b.dot(theta.v0.hat[, 2])
    
    temp1 <- exp((-alpha.0.hat - X%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0.hat[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat)/((1 - p.D.v1.hat)*exp((b(theta.v0.hat[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat))
    p.D.v0.hat <- temp1/(1+temp1)
    p.D.v0.hat[is.nan(p.D.v0.hat)] <- 1
    
    temp2 <- exp(-beta.0.hat - X%*%as.matrix(beta.X.hat) %>% as.numeric()) * 
      ((1 - p.D.v1.hat)*exp((b(theta.v0.hat[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat) + 
         exp((-alpha.0.hat - X%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0.hat[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat))
    p.V.hat <- 1/(1 + temp2)
    
    p.D.individual.hat <- (p.V.hat*p.D.v1.hat + (1 - p.V.hat)*p.D.v0.hat)
    p.D.G1.mean.hat <- p.D.individual.hat[G==1] %>% mean()
    p.D.G2.mean.hat <- p.D.individual.hat[G==2] %>% mean()
    
    plot.axis <- seq(from = -1, to = 1, by = 0.02)
    p.D.G1.hat <- matrix(0, ncol = length(plot.axis), nrow = 8)
    p.D.G2.hat <- matrix(0, ncol = length(plot.axis), nrow = 8)
    for (temp in 0:3) {
      state.t <- temp + 1
      p.D.G1.hat[state.t, ] <- lapply(1:length(plot.axis), FUN = function(i) sum(p.D.individual.hat*(G==1)*(X.state==state.t)*K((plot.axis[i] - Z)/lambda))/sum((G==1)*(X.state==state.t)*K((plot.axis[i] - Z)/lambda))) %>% as.numeric()
      p.D.G2.hat[state.t, ] <- lapply(1:length(plot.axis), FUN = function(i) sum(p.D.individual.hat*(G==2)*(X.state==state.t)*K((plot.axis[i] - Z)/lambda))/sum((G==2)*(X.state==state.t)*K((plot.axis[i] - Z)/lambda))) %>% as.numeric()
      p.D.G1.hat[state.t, is.nan(p.D.G1.hat[state.t, ])] <- mean(p.D.G1.hat[state.t, !(is.nan(p.D.G1.hat[state.t, ]))])
      p.D.G2.hat[state.t, is.nan(p.D.G2.hat[state.t, ])] <- mean(p.D.G2.hat[state.t, !(is.nan(p.D.G2.hat[state.t, ]))])
    }
    
    
    if(working.mode == "CV"){
      
      X <- Age

      M <- length(test.index)
      
      p.D.v1.hat.test <- numeric(M)
      p.D.v1.hat.test <- lapply(1:M, FUN = function(i) (p.D.v1.hat[(G==G.test[i])&(X.state==X.state.test[i])])[which.min(abs(X[(G==G.test[i])&(X.state==X.state.test[i])] - X.test[i]))]) %>% as.numeric()
      p.D.v1.hat.test[is.na(p.D.v1.hat.test)] <- mean(p.D.v1.hat.test[!is.na(p.D.v1.hat.test)])
      
      mu.v1.hat.test <- matrix(0, ncol = 2, nrow = M)
      mu.v1.hat.test[, 1] <- lapply(1:M, FUN = function(i) (mu.v1.hat[(X.state==X.state.test[i]), 1])[which.min(abs(X[(X.state==X.state.test[i])] - X.test[i]))]) %>% as.numeric()
      mu.v1.hat.test[, 2] <- lapply(1:M, FUN = function(i) (mu.v1.hat[(X.state==X.state.test[i]), 2])[which.min(abs(X[(X.state==X.state.test[i])] - X.test[i]))]) %>% as.numeric()
      mu.v1.hat.test[is.na(mu.v1.hat.test[, 1]), 1] <- mean(mu.v1.hat.test[!is.na(mu.v1.hat.test[, 1]), 1])
      mu.v1.hat.test[is.na(mu.v1.hat.test[, 2]), 2] <- mean(mu.v1.hat.test[!is.na(mu.v1.hat.test[, 2]), 2])
      
      theta.v1.hat.test <- matrix(0, ncol = 2, nrow = M)
      theta.v1.hat.test[, 1] <- b.dot.inverse(mu.v1.hat.test[, 1])
      theta.v1.hat.test[, 2] <- b.dot.inverse(mu.v1.hat.test[, 2])
      
      psi.0.hat.test <- numeric(M)
      psi.1.hat.test <- numeric(M)
      psi.0.hat.test <- lapply(1:M, FUN = function(i) (psi.0.hat)[which.min(abs(X - X.test[i]))]) %>% as.numeric()
      psi.1.hat.test <- lapply(1:M, FUN = function(i) (psi.1.hat)[which.min(abs(X - X.test[i]))]) %>% as.numeric()
      psi.0.hat.test[is.na(psi.0.hat.test)] <- mean(psi.0.hat.test[!is.na(psi.0.hat.test)])
      psi.1.hat.test[is.na(psi.1.hat.test)] <- mean(psi.1.hat.test[!is.na(psi.1.hat.test)])
      psi.0.hat.test[which(psi.0.hat.test <= 1e-3)] <- psi.0.hat.test[which(psi.0.hat.test >= 1e-3)] %>% min()
      psi.1.hat.test[which(psi.1.hat.test <= 1e-3)] <- psi.1.hat.test[which(psi.1.hat.test >= 1e-3)] %>% min()
      
      p.T.2.hat.test <- matrix(0, ncol = 2, nrow = M)
      p.T.2.hat.test[, 1] <- lapply(1:M, FUN = function(i) (p.T.2.hat[(X.state==X.state.test[i]), 1])[which.min(abs(X[(X.state==X.state.test[i])] - X.test[i]))]) %>% as.numeric()
      p.T.2.hat.test[, 2] <- lapply(1:M, FUN = function(i) (p.T.2.hat[(X.state==X.state.test[i]), 2])[which.min(abs(X[(X.state==X.state.test[i])] - X.test[i]))]) %>% as.numeric()
      p.T.2.hat.test[is.na(p.T.2.hat.test[, 1]), 1] <- mean(p.T.2.hat.test[!is.na(p.T.2.hat.test[, 1]), 1])
      p.T.2.hat.test[is.na(p.T.2.hat.test[, 2]), 2] <- mean(p.T.2.hat.test[!is.na(p.T.2.hat.test[, 2]), 2])
      p.T.2.hat.test[(p.T.2.hat.test[, 1] == 0), 1] <- p.T.2.hat.test[(p.T.2.hat.test[, 1] != 0), 1] %>% min()
      p.T.2.hat.test[(p.T.2.hat.test[, 1] == 1), 1] <- p.T.2.hat.test[(p.T.2.hat.test[, 1] != 1), 1] %>% max()
      p.T.2.hat.test[(p.T.2.hat.test[, 2] == 1), 2] <- p.T.2.hat.test[(p.T.2.hat.test[, 2] != 1), 2] %>% max()
      p.T.2.hat.test[(p.T.2.hat.test[, 2] == 0), 2] <- p.T.2.hat.test[(p.T.2.hat.test[, 2] != 0), 2] %>% min()
      
      X.test <- matrix(c(Age.test, GENDER.test, DEP.test), ncol = 3)
      dim_X <- 3
      
      theta.v0.hat.test <- matrix(0, ncol = 2, nrow = length(test.index))
      theta.v0.hat.test[, 1] <- theta.v1.hat.test[ ,1] - (beta.1.hat + X.test%*%as.matrix(beta.TX.hat))*psi.0.hat.test
      theta.v0.hat.test[, 2] <- theta.v1.hat.test[ ,2] - (beta.1.hat + X.test%*%as.matrix(beta.TX.hat) + alpha.1.hat + X.test%*%as.matrix(alpha.TX.hat))*psi.1.hat.test
      
      temp <- exp((-alpha.0.hat - X.test%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat.test*exp((b(theta.v0.hat.test[, 2]) - b(theta.v1.hat.test[, 2]))/psi.1.hat.test)/((1 - p.D.v1.hat.test)*exp((b(theta.v0.hat.test[, 1]) - b(theta.v1.hat.test[, 1]))/psi.0.hat.test))
      p.D.v0.hat.test <- temp/(1+temp)
      p.D.v0.hat.test[is.nan(p.D.v0.hat.test)] <- 1
      
      temp <- exp(-beta.0.hat - X.test%*%as.matrix(beta.X.hat) %>% as.numeric()) * 
        ((1 - p.D.v1.hat.test)*exp((b(theta.v0.hat.test[, 1]) - b(theta.v1.hat.test[, 1]))/psi.0.hat.test) + 
           exp((-alpha.0.hat - X.test%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat.test*exp((b(theta.v0.hat.test[, 2]) - b(theta.v1.hat.test[, 2]))/psi.1.hat.test))
      p.V.hat.test <- 1/(1 + temp)
      
      T.2.test[which(T.2.test < 0)] <- 0
      
      likelihood <- (V.test*((
        (1 - p.D.v1.hat.test)*density.glm(T.1.test, theta.v1.hat.test[, 1], psi.0.hat.test)*(T.2.test*(p.T.2.hat.test[, 1]) + (1 - T.2.test)*(1 - p.T.2.hat.test[, 1])) +
          p.D.v1.hat.test*density.glm(T.1.test, theta.v1.hat.test[, 2], psi.1.hat.test)*(T.2.test*(p.T.2.hat.test[, 2]) + (1 - T.2.test)*(1 - p.T.2.hat.test[, 2]))
      ) %>% log())) %>% sum() + (
        (1 - V.test)*((
          (1 - p.D.v0.hat.test)*density.glm(T.1.test, theta.v0.hat.test[, 1], psi.0.hat.test) +
            p.D.v0.hat.test*density.glm(T.1.test, theta.v0.hat.test[, 2], psi.1.hat.test)
        ) %>% log()) +
          (1 - V.test)*((1 - p.V.hat.test) %>% log()) + V.test*(p.V.hat.test %>% log())
      ) %>% sum()
      
      return(likelihood)
    }else{
      
      temp <- matrix(0, nrow = N, ncol = N)
      temp[lower.tri(temp)] <- 1
      diag(temp) <- 1/2
      
      I <- temp[rank(T.1), rank(T.1)]
      
      q.hat <- alpha.0.hat + alpha.1.hat*T.1 + (X%*%(alpha.X.hat %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(alpha.TX.hat %>% as.matrix()) %>% as.numeric())
      
      rho.1.hat <- numeric(N)
      rho.0.hat <- numeric(N)
      rho.V.hat <- numeric(N)
      rho.1.hat <- (p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], psi.1.hat))/(p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], psi.1.hat) + (1 - p.D.v1.hat)*density.glm(T.1, theta.v1.hat[, 1], psi.0.hat))
      rho.0.hat <- rho.1.hat*(exp(-q.hat))/(rho.1.hat*exp(-q.hat) + (1 - rho.1.hat))
      rho.V.hat <- V*rho.1.hat + (1 - V)*rho.0.hat
      
      TPR.FI.hat <- function(s){
        sum(as.numeric(T.1 >= s)*rho.V.hat)/sum(rho.V.hat)
      }
      FPR.FI.hat <- function(s){
        sum(as.numeric(T.1 >= s)*(1 - rho.V.hat))/sum(1 - rho.V.hat)
      }
      temp <- (rho.V.hat) %o% (1 - rho.V.hat)
      diag(temp) <- 0
      v.FI.hat <- sum(temp*I)/(sum(rho.V.hat)*sum(1 - rho.V.hat) - sum(rho.V.hat*(1 - rho.V.hat)))
      
      tau.hat <- numeric(N)
      D.MSI.hat <- numeric(N)
      tau.hat <- (rho.1.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])))/(rho.1.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - rho.1.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
      D.MSI.hat <- V*tau.hat + (1 - V)*rho.0.hat
      
      TPR.MSI.hat <- function(s){
        sum(as.numeric(T.1 >= s)*D.MSI.hat)/sum(D.MSI.hat)
      }
      FPR.MSI.hat <- function(s){
        sum(as.numeric(T.1 >= s)*(1 - D.MSI.hat))/sum(1 - D.MSI.hat)
      }
      temp <- (D.MSI.hat) %o% (1 - D.MSI.hat)
      diag(temp) <- 0
      v.MSI.hat <- sum(temp*I)/(sum(D.MSI.hat)*sum(1 - D.MSI.hat) - sum(D.MSI.hat*(1 - D.MSI.hat)))
      
      h.hat <- numeric(N)
      xi.hat <- numeric(N)
      phi.hat <- numeric(N)
      pi.star.hat <- numeric(N)
      h.hat <- beta.0.hat + beta.1.hat*T.1 + (X%*%(beta.X.hat %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(beta.TX.hat %>% as.matrix()) %>% as.numeric())
      xi.hat <- rho.1.hat*(1 + exp(- h.hat - q.hat))/(rho.1.hat*(1 + exp(- h.hat - q.hat)) + (1 - rho.1.hat)*(1 + exp(- h.hat)))
      phi.hat <- xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))/(xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
      pi.star.hat <- (xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))*((h.hat + q.hat) %>% expit()) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1]))*(h.hat %>% expit())) /
        (xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
      
      TPR.IPW.hat <- function(s){
        sum(as.numeric(T.1 >= s)*V*phi.hat/pi.star.hat)/sum(V*phi.hat/pi.star.hat)
      }
      FPR.IPW.hat <- function(s){
        sum(as.numeric(T.1 >= s)*V*(1 - phi.hat)/pi.star.hat)/sum(V*(1 - phi.hat)/pi.star.hat)
      }
      temp <- (V*phi.hat/pi.star.hat) %o% (V*(1 - phi.hat)/pi.star.hat)
      diag(temp) <- 0
      v.IPW.hat <- sum(temp*I)/(sum(V*phi.hat/pi.star.hat)*sum(V*(1 - phi.hat)/pi.star.hat) - sum(V*phi.hat/pi.star.hat*(V*(1 - phi.hat)/pi.star.hat)))
      
      
      D.PDR.hat <- numeric(N)
      D.PDR.hat <- V*phi.hat/pi.star.hat + (1 - V/pi.star.hat)*rho.0.hat
      
      TPR.PDR.hat <- function(s){
        sum(as.numeric(T.1 >= s)*D.PDR.hat)/sum(D.PDR.hat)
      }
      FPR.PDR.hat <- function(s){
        sum(as.numeric(T.1 >= s)*(1 - D.PDR.hat))/sum(1 - D.PDR.hat)
      }
      temp <- (D.PDR.hat) %o% (1 - D.PDR.hat)
      diag(temp) <- 0
      v.PDR.hat <- sum(temp*I)/(sum(D.PDR.hat)*sum(1 - D.PDR.hat) - sum(D.PDR.hat*(1 - D.PDR.hat)))
      
      s_values <- seq(-1, 1, length.out = 1000)
      plot.axis.s <- seq(0, 1, length.out = 1000)
      
      FPR_values.FI <- sapply(s_values, FPR.FI.hat)
      TPR_values.FI <- sapply(s_values, TPR.FI.hat)
      unique_indices.FI <- !duplicated(FPR_values.FI)
      FPR_values_unique.FI <- FPR_values.FI[unique_indices.FI]
      TPR_values_unique.FI <- TPR_values.FI[unique_indices.FI]
      ROC.hat.FI <- approx(FPR_values_unique.FI, TPR_values_unique.FI, xout = plot.axis.s)$y
      
      FPR_values.MSI <- sapply(s_values, FPR.MSI.hat)
      TPR_values.MSI <- sapply(s_values, TPR.MSI.hat)
      unique_indices.MSI <- !duplicated(FPR_values.MSI)
      FPR_values_unique.MSI <- FPR_values.MSI[unique_indices.MSI]
      TPR_values_unique.MSI <- TPR_values.MSI[unique_indices.MSI]
      ROC.hat.MSI <- approx(FPR_values_unique.MSI, TPR_values_unique.MSI, xout = plot.axis.s)$y
      
      FPR_values.IPW <- sapply(s_values, FPR.IPW.hat)
      TPR_values.IPW <- sapply(s_values, TPR.IPW.hat)
      unique_indices.IPW <- !duplicated(FPR_values.IPW)
      FPR_values_unique.IPW <- FPR_values.IPW[unique_indices.IPW]
      TPR_values_unique.IPW <- TPR_values.IPW[unique_indices.IPW]
      ROC.hat.IPW <- approx(FPR_values_unique.IPW, TPR_values_unique.IPW, xout = plot.axis.s)$y
      
      FPR_values.PDR <- sapply(s_values, FPR.PDR.hat)
      TPR_values.PDR <- sapply(s_values, TPR.PDR.hat)
      unique_indices.PDR <- !duplicated(FPR_values.PDR)
      FPR_values_unique.PDR <- FPR_values.PDR[unique_indices.PDR]
      TPR_values_unique.PDR <- TPR_values.PDR[unique_indices.PDR]
      ROC.hat.PDR <- approx(FPR_values_unique.PDR, TPR_values_unique.PDR, xout = plot.axis.s)$y
      
      sens_of_S.hat <- sum(V*tau.hat*T.2)/sum(V*tau.hat)
      spec_of_S.hat <- sum(V*(1 - tau.hat)*(1 - T.2))/sum(V*(1 - tau.hat))
    
      return(list( alpha.0.hat = alpha.0.hat,
                   alpha.1.hat = alpha.1.hat,
                   alpha.X.hat = alpha.X.hat,
                   alpha.TX.hat = alpha.TX.hat,
                   beta.0.hat = beta.0.hat,
                   beta.1.hat = beta.1.hat,
                   beta.X.hat = beta.X.hat,
                   beta.TX.hat = beta.TX.hat,
                   v.FI.hat = v.FI.hat,
                   v.MSI.hat = v.MSI.hat,
                   v.IPW.hat = v.IPW.hat,
                   v.PDR.hat = v.PDR.hat,
                   ROC.hat.FI = ROC.hat.FI,
                   ROC.hat.MSI = ROC.hat.MSI,
                   ROC.hat.IPW = ROC.hat.IPW,
                   ROC.hat.PDR = ROC.hat.PDR,
                   sens_of_S.hat = sens_of_S.hat,
                   spec_of_S.hat = spec_of_S.hat,
                   p.D.G1.mean.hat = p.D.G1.mean.hat,
                   p.D.G2.mean.hat = p.D.G2.mean.hat,
                   p.D.G1.hat = p.D.G1.hat,
                   p.D.G2.hat = p.D.G2.hat,
                   FPR_values.FI = FPR_values.FI,
                   FPR_values.MSI = FPR_values.MSI,
                   FPR_values.IPW = FPR_values.IPW,
                   FPR_values.PDR = FPR_values.PDR,
                   TPR_values.FI = TPR_values.FI,
                   TPR_values.MSI = TPR_values.MSI,
                   TPR_values.IPW = TPR_values.IPW,
                   TPR_values.PDR = TPR_values.PDR,
      ))
      
    }
    
  }
  
  tryCatch({
    train.index <- sample(1:N, N, replace = TRUE)
    bootstrap.result <- EM(lambda = lambda.cv, train.index = train.index, test.index = 1, working.mode = "Bootstrap")
    
    return(list(train.index = train.index, bootstrap.result = bootstrap.result))
    
  }, error = function(e){
    return("FALSE")
  })
  
  
  
}

library(parallel)

num_simulations <- 50
cl <- makeCluster(num_simulations)
clusterExport(cl, c("simulation", "N", "G", "X", "Z", "V", "T.1", "T.2", "dim_X", "Age", "GENDER", "DEP", "X.state"))
num_repetitions <- 20

results <- list()
for (fake_value in 1:num_repetitions) {
  print(fake_value)
  fake_values <- rep(fake_value, num_simulations)
  simulation_results <- parLapply(cl, fake_values, function(fake, N, G, X, Z, V, T.1, T.2, dim_X, Age, GENDER, DEP, X.state){
    simulation(fake, N, G, X, Z, V, T.1, T.2, dim_X, Age, GENDER, DEP, X.state)
  }, N, G, X, Z, V, T.1, T.2, dim_X, Age, GENDER, DEP, X.state)
  results[[fake_value]] <- simulation_results
}
stopCluster(cl)





