library("magrittr")

########## Basic functions ##########
K <- function(x){ ifelse(abs(x) <= 1, 0.75*(1 - x^2), 0) }
expit <- function(x){ 1/(1+exp(-x)) }
b <- function(x){ log(1 + exp(x)) }
b.dot <- function(x){ (exp(x))/(1 + exp(x)) }
b.dot.inverse <- function(x){ log(x/(1 - x)) }
b.double.dot <- function(x){ (exp(x))/((1 + exp(x))^2) }
c.mine <- function(y, phi){ 1 }
g <- function(x){ log(x/(1 - x)) }
g.dot <- function(x) { 1/(x*(1 - x)) }
g.inverse <- function(x){ (exp(x))/(1 + exp(x)) }
density.glm <- function(t, theta, psi){ exp((t*theta - b(theta))/psi + c.mine(t, psi)) }
c.mine.partial.psi <- function(y, psi){ 0 }

simulation <- function(fake){

  library("magrittr")

  ########## Basic Functions ##########
  K <- function(x){ ifelse(abs(x) <= 1, 0.75*(1 - x^2), 0) }
  expit <- function(x){ 1/(1+exp(-x)) }
  b <- function(x){ log(1 + exp(x)) }
  b.dot <- function(x){ (exp(x))/(1 + exp(x)) }
  b.dot.inverse <- function(x){ log(x/(1 - x)) }
  b.double.dot <- function(x){ (exp(x))/((1 + exp(x))^2) }
  c.mine <- function(y, phi){ 1 }
  g <- function(x){ log(x/(1 - x)) }
  g.dot <- function(x) { 1/(x*(1 - x)) }
  g.inverse <- function(x){ (exp(x))/(1 + exp(x)) }
  density.glm <- function(t, theta, psi){ exp((t*theta - b(theta))/psi + c.mine(t, psi)) }
  c.mine.partial.psi <- function(y, psi){ 0 }
  
  # Set bandwidth
  lambda.cv <- 1.56
  
    EM <- function(lambda, train.index, test.index, working.mode){
      
      K <- function(x){
        ifelse(abs(x) <= 1, 0.75*(1 - x^2), 0)
      }
      
      ########## transform data ##########
      
      G.test <- G[test.index]
      Z.test <- Z[test.index]
      X.test <- X[test.index]
      V.test <- V[test.index]
      T.1.test <- T.1[test.index]
      T.2.test <- T.2[test.index]
      
      N <- length(train.index)
      G <- G[train.index]
      Z <- Z[train.index]
      X <- X[train.index]
      V <- V[train.index] 
      T.1 <- T.1[train.index]
      T.2 <- T.2[train.index]
      
      ########## Estimation ##########
      
      ########## Initial Value ##########
      stage.1.estimation <- function(G, T.1, T.2){
        
        p1.hat <- 0.4
        p2.hat <- 0.6
        sens.1.hat <- 0.55
        spec.1.hat <- 0.55
        sens.2.hat <- 0.6
        spec.2.hat <- 0.6
        
        old.params <- c(p1.hat, p2.hat, sens.1.hat, spec.1.hat, sens.2.hat, spec.2.hat)
        new.params <- rep(0, 6)
        while (sum(abs(old.params - new.params))>1e-3) {
          old.params <- c(p1.hat, p2.hat, sens.1.hat, spec.1.hat, sens.2.hat, spec.2.hat)
          
          l1 <- ((G==1)*p1.hat + (G==2)*p2.hat)*(sens.1.hat*T.1 + (1 - sens.1.hat)*(1 - T.1))*(sens.2.hat*T.2 + (1 - sens.2.hat)*(1 - T.2))
          l0 <- (1 - ((G==1)*p1.hat + (G==2)*p2.hat))*((1 - spec.1.hat)*T.1 + spec.1.hat*(1 - T.1))*((1 - spec.2.hat)*T.2 + spec.2.hat*(1 - T.2))
          r <- l1/(l1 + l0)
          
          p1.hat <- sum((G==1)*r)/sum(G==1)
          p2.hat <- sum((G==2)*r)/sum(G==2)
          sens.1.hat <- sum(T.1*r)/sum(r)
          sens.2.hat <- sum(T.2*r)/sum(r)
          spec.1.hat <- sum((1 - T.1)*(1 - r))/sum(1 - r)
          spec.2.hat <- sum((1 - T.2)*(1 - r))/sum(1 - r)
          
          new.params <- c(p1.hat, p2.hat, sens.1.hat, spec.1.hat, sens.2.hat, spec.2.hat)
          
        }
        
        return(new.params)
        
      }
      
      stage.1.result <- stage.1.estimation(G = G[V==1], T.1 = T.1[V==1], T.2 = T.2[V==1])
      
      alpha.0.hat <- 0
      alpha.1.hat <- 0
      alpha.X.hat <- 0
      alpha.TX.hat <- 0
      beta.0.hat <- 0
      beta.1.hat <- 0
      beta.X.hat <- 0
      beta.TX.hat <- 0
      
      psi.0 <- psi.0.hat <- 1
      psi.1 <- psi.1.hat <- 1
      
      p.D.v1.hat <- numeric(N)
      p.D.v1.hat[G==1] <- stage.1.result[1]
      p.D.v1.hat[G==2] <- stage.1.result[2]
      sens.1.v1.hat <- rep(stage.1.result[3], N)
      spec.1.v1.hat <- rep(stage.1.result[4], N)
      sens.2.hat <-rep(stage.1.result[5], N)
      spec.2.hat <- rep(stage.1.result[6], N)
      
      old.params <- c(p.D.v1.hat, sens.1.v1.hat, spec.1.v1.hat, sens.2.hat, spec.2.hat)
      new.params <- numeric(length(old.params))
      
      K_matrix <- outer(X, X, Vectorize(function(x, y) K((x - y) / lambda)))
      
      ########## EM ##########
      
      record <- 0
      while ((max(abs(old.params - new.params)) > 1e-3)&&(record <= 30)) {
        
        old.params <- c(p.D.v1.hat, sens.1.v1.hat, spec.1.v1.hat, sens.2.hat, spec.2.hat)
        
        l1 <- p.D.v1.hat*(sens.1.v1.hat*T.1 + (1 - sens.1.v1.hat)*(1 - T.1))*(sens.2.hat*T.2 + (1 - sens.2.hat)*(1 - T.2))
        l0 <- (1 - p.D.v1.hat)*((1 - spec.1.v1.hat)*T.1 + spec.1.v1.hat*(1 - T.1))*((1 - spec.2.hat)*T.2 + spec.2.hat*(1 - T.2))
        r <- l1/(l1 + l0)
        
        temp <- ((K_matrix%*%as.matrix((G==1)*(V==1)*r))/(K_matrix%*%as.matrix((G==1)*(V==1)))) %>% as.numeric()
        p.D.v1.hat[G==1] <- temp[G==1]
        temp <- ((K_matrix%*%as.matrix((G==2)*(V==1)*r))/(K_matrix%*%as.matrix((G==2)*(V==1)))) %>% as.numeric()
        p.D.v1.hat[G==2] <- temp[G==2]
        
        sens.1.v1.hat <- ((K_matrix%*%as.matrix(T.1*r*(V==1)))/(K_matrix%*%as.matrix(r*(V==1)))) %>% as.numeric()
        sens.2.hat <- ((K_matrix%*%as.matrix(T.2*r*(V==1)))/(K_matrix%*%as.matrix(r*(V==1)))) %>% as.numeric()
        spec.1.v1.hat <- ((K_matrix%*%as.matrix((1 - T.1)*(1 - r)*(V==1)))/(K_matrix%*%as.matrix((1 - r)*(V==1)))) %>% as.numeric()
        spec.2.hat <- ((K_matrix%*%as.matrix((1 - T.2)*(1 - r)*(V==1)))/(K_matrix%*%as.matrix((1 - r)*(V==1)))) %>% as.numeric()
        
        new.params <- c(p.D.v1.hat, sens.1.v1.hat, spec.1.v1.hat, sens.2.hat, spec.2.hat)
        
        mu.v1.hat <- matrix(0, ncol = 2, nrow = N)
        mu.v1.hat[, 1] <- 1 - spec.1.v1.hat
        mu.v1.hat[, 2] <- sens.1.v1.hat
        
        theta.v1.hat <- matrix(0, ncol = 2, nrow = N)
        theta.v1.hat[, 1] <- b.dot.inverse(mu.v1.hat[, 1])
        theta.v1.hat[, 2] <- b.dot.inverse(mu.v1.hat[, 2])
        
        f3 <- function(params){
          
          alpha.0 <- params[1]
          alpha.1 <- params[2]
          alpha.X <- params[3:(2+dim_X)]
          alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
          beta.0 <- params[3+2*dim_X]
          beta.1 <- params[4+2*dim_X]
          beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
          beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
          
          theta.v0 <- matrix(0, ncol = 2, nrow = N)
          theta.v0[, 1] <- theta.v1.hat[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0.hat
          theta.v0[, 2] <- theta.v1.hat[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1.hat
          
          temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat)/((1 - p.D.v1.hat)*exp((b(theta.v0[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat))
          p.D.v0 <- temp1/(1+temp1)
          p.D.v0[is.nan(p.D.v0)] <- 1
          
          temp2 <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
            ((1 - p.D.v1.hat)*exp((b(theta.v0[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat) + 
               exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat))
          p.V <- 1/(1 + temp2)
          
          likelihood <- (
            (1 - V)*((
              (1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0.hat, times = N)) +
                p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1.hat, times = N))
            ) %>% log()) +
              (1 - V)*((1 - p.V) %>% log()) + V*(p.V %>% log())
          ) %>% sum()
          
          return(-likelihood)
        }
        
        
        temp <- optim(par = c(alpha.0.hat, alpha.1.hat, alpha.X.hat, alpha.TX.hat, beta.0.hat, beta.1.hat, beta.X.hat, beta.TX.hat), fn = f3, method = "BFGS")$par
        
        alpha.0.hat <- temp[1]
        alpha.1.hat <- temp[2]
        alpha.X.hat <- temp[3:(2+dim_X)]
        alpha.TX.hat <- temp[(3+dim_X):(2+2*dim_X)]
        beta.0.hat <- temp[3+2*dim_X]
        beta.1.hat <- temp[4+2*dim_X]
        beta.X.hat <- temp[(5+2*dim_X):(4+3*dim_X)]
        beta.TX.hat <- temp[(5+3*dim_X):(4+4*dim_X)]
        
        record = record + 1
        
      }
      
            
      if(working.mode == "CV"){
        
        ##### calculate outcome ######
        p.D.v1.hat.test <- numeric(length(test.index))
        temp <- lapply(1:length(test.index), FUN = function(i) sum(V*(G==1)*r*K((Z.test[i] - Z)/lambda))/sum(V*(G==1)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        p.D.v1.hat.test[G.test==1] <- temp[G.test==1]
        temp <- lapply(1:length(test.index), FUN = function(i) sum(V*(G==2)*r*K((Z.test[i] - Z)/lambda))/sum(V*(G==2)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        p.D.v1.hat.test[G.test==2] <- temp[G.test==2]
        
        mu.v1.hat.test <- matrix(0, ncol = 2, nrow = length(test.index))
        mu.v1.hat.test[, 1] <- lapply(1:length(test.index), FUN = function(i) sum((1 - r)*(V==1)*T.1*K((Z.test[i] - Z)/lambda))/sum((1 - r)*(V==1)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        mu.v1.hat.test[, 2] <- lapply(1:length(test.index), FUN = function(i) sum(r*(V==1)*T.1*K((Z.test[i] - Z)/lambda))/sum(r*(V==1)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        
        psi.0.hat.test <- rep(1, length(test.index))
        
        psi.1.hat.test <- rep(1, length(test.index))
        
        p.T.2.hat.test <- matrix(0, ncol = 2, nrow = length(test.index))
        p.T.2.hat.test[, 1] <- 1 - lapply(1:length(test.index), FUN = function(i) sum((1 - T.2)*(1 - r)*(V==1)*K((Z.test[i] - Z)/lambda))/sum((1 - r)*(V==1)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        p.T.2.hat.test[, 2] <- lapply(1:length(test.index), FUN = function(i) sum(T.2*r*(V==1)*K((Z.test[i] - Z)/lambda))/sum(r*(V==1)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        
        theta.v1.hat.test <- matrix(0, ncol = 2, nrow = length(test.index))
        theta.v1.hat.test[, 1] <- b.dot.inverse(mu.v1.hat.test[, 1])
        theta.v1.hat.test[, 2] <- b.dot.inverse(mu.v1.hat.test[, 2])
        
        theta.v0.hat.test <- matrix(0, ncol = 2, nrow = length(test.index))
        theta.v0.hat.test[, 1] <- theta.v1.hat.test[ ,1] - (beta.1.hat + X.test%*%as.matrix(beta.TX.hat))*psi.0.hat.test
        theta.v0.hat.test[, 2] <- theta.v1.hat.test[ ,2] - (beta.1.hat + X.test%*%as.matrix(beta.TX.hat) + alpha.1.hat + X.test%*%as.matrix(alpha.TX.hat))*psi.1.hat.test
        
        temp <- exp((-alpha.0.hat - X.test%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat.test*exp((b(theta.v0.hat.test[, 2]) - b(theta.v1.hat.test[, 2]))/psi.1.hat.test)/((1 - p.D.v1.hat.test)*exp((b(theta.v0.hat.test[, 1]) - b(theta.v1.hat.test[, 1]))/psi.0.hat.test))
        p.D.v0.hat.test <- temp/(1+temp)
        p.D.v0.hat.test[is.nan(p.D.v0.hat.test)] <- 1
        
        temp <- exp(-beta.0.hat - X.test%*%as.matrix(beta.X.hat) %>% as.numeric()) * 
          ((1 - p.D.v1.hat.test)*exp((b(theta.v0.hat.test[, 1]) - b(theta.v1.hat.test[, 1]))/psi.0.hat.test) + 
             exp((-alpha.0.hat - X.test%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat.test*exp((b(theta.v0.hat.test[, 2]) - b(theta.v1.hat.test[, 2]))/psi.1.hat.test))
        p.V.hat.test <- 1/(1 + temp)
        
        likelihood <- (V.test*((
          (1 - p.D.v1.hat.test)*density.glm(T.1.test, theta.v1.hat.test[, 1], psi.0.hat.test)*(T.2.test*(p.T.2.hat.test[, 1]) + (1 - T.2.test)*(1 - p.T.2.hat.test[, 1])) +
            p.D.v1.hat.test*density.glm(T.1.test, theta.v1.hat.test[, 2], psi.1.hat.test)*(T.2.test*(p.T.2.hat.test[, 2]) + (1 - T.2.test)*(1 - p.T.2.hat.test[, 2]))
        ) %>% log())) %>% sum() + (
          (1 - V.test)*((
            (1 - p.D.v0.hat.test)*density.glm(T.1.test, theta.v0.hat.test[, 1], psi.0.hat.test) +
              p.D.v0.hat.test*density.glm(T.1.test, theta.v0.hat.test[, 2], psi.1.hat.test)
          ) %>% log()) +
            (1 - V.test)*((1 - p.V.hat.test) %>% log()) + V.test*(p.V.hat.test %>% log())
        ) %>% sum()
        
        return(likelihood)
        
      }else{
        
        ########## Preparation ##########
        
        p.T.2.hat <- matrix(0, ncol = 2, nrow = N)
        p.T.2.hat[, 1] <- 1 - spec.2.hat
        p.T.2.hat[, 2] <- sens.2.hat
        
        mu.v1.hat <- matrix(0, ncol = 2, nrow = N)
        mu.v1.hat[, 1] <- 1 - spec.1.v1.hat
        mu.v1.hat[, 2] <- sens.1.v1.hat
        
        theta.v1.hat <- matrix(0, ncol = 2, nrow = N)
        theta.v1.hat[, 1] <- b.dot.inverse(mu.v1.hat[, 1])
        theta.v1.hat[, 2] <- b.dot.inverse(mu.v1.hat[, 2])
        
        theta.v0.hat <- matrix(0, ncol = 2, nrow = N)
        theta.v0.hat[, 1] <- theta.v1.hat[ ,1] - (beta.1.hat + X%*%as.matrix(beta.TX.hat))*psi.0.hat
        theta.v0.hat[, 2] <- theta.v1.hat[ ,2] - (beta.1.hat + X%*%as.matrix(beta.TX.hat) + alpha.1.hat + X%*%as.matrix(alpha.TX.hat))*psi.1.hat
        
        temp1 <- exp((-alpha.0.hat - X%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0.hat[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat)/((1 - p.D.v1.hat)*exp((b(theta.v0.hat[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat))
        p.D.v0.hat <- temp1/(1+temp1)
        
        temp2 <- exp(-beta.0.hat - X%*%as.matrix(beta.X.hat) %>% as.numeric()) * 
          ((1 - p.D.v1.hat)*exp((b(theta.v0.hat[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat) + 
             exp((-alpha.0.hat - X%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0.hat[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat))
        p.V.hat <- 1/(1 + temp2)
        
        plot.axis <- seq(from = -1, to = 1, by = 0.05)
        p.D.hat <- (p.V.hat*p.D.v1.hat + (1 - p.V.hat)*p.D.v0.hat) %>% mean()
        p.D.individual.hat <- p.V.hat*p.D.v1.hat + (1 - p.V.hat)*p.D.v0.hat
        
        p.D.G1.hat <- lapply(1:length(plot.axis), FUN = function(i) sum(p.D.individual.hat*(G==1)*K((plot.axis[i] - Z)/lambda))/sum((G==1)*K((plot.axis[i] - Z)/lambda))) %>% as.numeric()
        p.D.G2.hat <- lapply(1:length(plot.axis), FUN = function(i) sum(p.D.individual.hat*(G==2)*K((plot.axis[i] - Z)/lambda))/sum((G==2)*K((plot.axis[i] - Z)/lambda))) %>% as.numeric()
        p.D.G1.hat[is.nan(p.D.G1.hat)] <- mean(p.D.G1.hat[!(is.nan(p.D.G1.hat))])
        p.D.G2.hat[is.nan(p.D.G2.hat)] <- mean(p.D.G2.hat[!(is.nan(p.D.G2.hat))])
        
        p.D.G1.mean.hat <- p.D.individual.hat[G==1] %>% mean()
        p.D.G2.mean.hat <- p.D.individual.hat[G==2] %>% mean()
        
        ##### I matrix #####
        temp <- matrix(0, nrow = N, ncol = N)
        temp[lower.tri(temp)] <- 1
        diag(temp) <- 1/2
        
        I <- temp[rank(T.1), rank(T.1)]
        
        ##### AUC #####
        q.hat <- alpha.0.hat + alpha.1.hat*T.1 + (X%*%(alpha.X.hat %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(alpha.TX.hat %>% as.matrix()) %>% as.numeric())
        
        rho.1.hat <- numeric(N)
        rho.0.hat <- numeric(N)
        rho.V.hat <- numeric(N)
        rho.1.hat <- (p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], rep(psi.1.hat, times = N)))/(p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], rep(psi.1.hat, times = N)) + (1 - p.D.v1.hat)*density.glm(T.1, theta.v1.hat[, 1], rep(psi.0.hat, times = N)))
        rho.0.hat <- rho.1.hat*(exp(-q.hat))/(rho.1.hat*exp(-q.hat) + (1 - rho.1.hat))
        rho.V.hat <- V*rho.1.hat + (1 - V)*rho.0.hat
        
        TPR.FI.hat <- function(s){
          sum(as.numeric(T.1 >= s)*rho.V.hat)/sum(rho.V.hat)
        }
        FPR.FI.hat <- function(s){
          sum(as.numeric(T.1 >= s)*(1 - rho.V.hat))/sum(1 - rho.V.hat)
        }
        temp <- (rho.V.hat) %o% (1 - rho.V.hat)
        diag(temp) <- 0
        v.FI.hat <- sum(temp*I)/(sum(rho.V.hat)*sum(1 - rho.V.hat) - sum(rho.V.hat*(1 - rho.V.hat)))
        sens.FI.hat <- TPR.FI.hat(0.5)
        spec.FI.hat <- 1 - FPR.FI.hat(0.5)
        
        tau.hat <- numeric(N)
        D.MSI.hat <- numeric(N)
        tau.hat <- (rho.1.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])))/(rho.1.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - rho.1.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
        D.MSI.hat <- V*tau.hat + (1 - V)*rho.0.hat
        
        TPR.MSI.hat <- function(s){
          sum(as.numeric(T.1 >= s)*D.MSI.hat)/sum(D.MSI.hat)
        }
        FPR.MSI.hat <- function(s){
          sum(as.numeric(T.1 >= s)*(1 - D.MSI.hat))/sum(1 - D.MSI.hat)
        }
        temp <- (D.MSI.hat) %o% (1 - D.MSI.hat)
        diag(temp) <- 0
        v.MSI.hat <- sum(temp*I)/(sum(D.MSI.hat)*sum(1 - D.MSI.hat) - sum(D.MSI.hat*(1 - D.MSI.hat)))
        sens.MSI.hat <- TPR.MSI.hat(0.5)
        spec.MSI.hat <- 1 - FPR.MSI.hat(0.5)
        
        h.hat <- numeric(N)
        xi.hat <- numeric(N)
        phi.hat <- numeric(N)
        pi.star.hat <- numeric(N)
        h.hat <- beta.0.hat + beta.1.hat*T.1 + (X%*%(beta.X.hat %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(beta.TX.hat %>% as.matrix()) %>% as.numeric())
        xi.hat <- rho.1.hat*(1 + exp(- h.hat - q.hat))/(rho.1.hat*(1 + exp(- h.hat - q.hat)) + (1 - rho.1.hat)*(1 + exp(- h.hat)))
        phi.hat <- xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))/(xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
        pi.star.hat <- (xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))*((h.hat + q.hat) %>% expit()) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1]))*(h.hat %>% expit())) /
          (xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
        
        TPR.IPW.hat <- function(s){
          sum(as.numeric(T.1 >= s)*V*phi.hat/pi.star.hat)/sum(V*phi.hat/pi.star.hat)
        }
        FPR.IPW.hat <- function(s){
          sum(as.numeric(T.1 >= s)*V*(1 - phi.hat)/pi.star.hat)/sum(V*(1 - phi.hat)/pi.star.hat)
        }
        temp <- (V*phi.hat/pi.star.hat) %o% (V*(1 - phi.hat)/pi.star.hat)
        diag(temp) <- 0
        v.IPW.hat <- sum(temp*I)/(sum(V*phi.hat/pi.star.hat)*sum(V*(1 - phi.hat)/pi.star.hat) - sum(V*phi.hat/pi.star.hat*(V*(1 - phi.hat)/pi.star.hat)))
        sens.IPW.hat <- TPR.IPW.hat(0.5)
        spec.IPW.hat <- 1 - FPR.IPW.hat(0.5)
        
        D.PDR.hat <- numeric(N)
        D.PDR.hat <- V*phi.hat/pi.star.hat + (1 - V/pi.star.hat)*rho.0.hat
        
        TPR.PDR.hat <- function(s){
          sum(as.numeric(T.1 >= s)*D.PDR.hat)/sum(D.PDR.hat)
        }
        FPR.PDR.hat <- function(s){
          sum(as.numeric(T.1 >= s)*(1 - D.PDR.hat))/sum(1 - D.PDR.hat)
        }
        temp <- (D.PDR.hat) %o% (1 - D.PDR.hat)
        diag(temp) <- 0
        v.PDR.hat <- sum(temp*I)/(sum(D.PDR.hat)*sum(1 - D.PDR.hat) - sum(D.PDR.hat*(1 - D.PDR.hat)))
        sens.PDR.hat <- TPR.PDR.hat(0.5)
        spec.PDR.hat <- 1 - FPR.PDR.hat(0.5)
        
        if(working.mode == "Estimation"){
          return(list(alpha.0.hat = alpha.0.hat,
                      alpha.1.hat = alpha.1.hat,
                      alpha.X.hat = alpha.X.hat,
                      alpha.TX.hat = alpha.TX.hat,
                      beta.0.hat = beta.0.hat,
                      beta.1.hat = beta.1.hat,
                      beta.X.hat = beta.X.hat,
                      beta.TX.hat = beta.TX.hat,
                      p.D.hat = p.D.hat,
                      p.D.G1.mean.hat = p.D.G1.mean.hat,
                      p.D.G2.mean.hat = p.D.G2.mean.hat,
                      p.D.G1.hat = p.D.G1.hat,
                      p.D.G2.hat = p.D.G2.hat,
                      sens.FI.hat = sens.FI.hat,
                      spec.FI.hat = spec.FI.hat,
                      sens.MSI.hat = sens.MSI.hat,
                      spec.MSI.hat = spec.MSI.hat,
                      sens.IPW.hat = sens.IPW.hat,
                      spec.IPW.hat = spec.IPW.hat,
                      sens.PDR.hat = sens.PDR.hat,
                      spec.PDR.hat = spec.PDR.hat,
                      v.FI.hat = v.FI.hat,
                      v.MSI.hat = v.MSI.hat,
                      v.IPW.hat = v.IPW.hat,
                      v.PDR.hat = v.PDR.hat
          ))
        }else if(working.mode == "Boostrap"){
          return(list(alpha.0.hat = alpha.0.hat,
                      alpha.1.hat = alpha.1.hat,
                      alpha.X.hat = alpha.X.hat,
                      alpha.TX.hat = alpha.TX.hat,
                      beta.0.hat = beta.0.hat,
                      beta.1.hat = beta.1.hat,
                      beta.X.hat = beta.X.hat,
                      beta.TX.hat = beta.TX.hat,
                      p.D.hat = p.D.hat,
                      p.D.G1.mean.hat = p.D.G1.mean.hat,
                      p.D.G2.mean.hat = p.D.G2.mean.hat,
                      p.D.G1.hat = p.D.G1.hat,
                      p.D.G2.hat = p.D.G2.hat,
                      sens.FI.hat = sens.FI.hat,
                      spec.FI.hat = spec.FI.hat,
                      sens.MSI.hat = sens.MSI.hat,
                      spec.MSI.hat = spec.MSI.hat,
                      sens.IPW.hat = sens.IPW.hat,
                      spec.IPW.hat = spec.IPW.hat,
                      sens.PDR.hat = sens.PDR.hat,
                      spec.PDR.hat = spec.PDR.hat,
                      v.FI.hat = v.FI.hat,
                      v.MSI.hat = v.MSI.hat,
                      v.IPW.hat = v.IPW.hat,
                      v.PDR.hat = v.PDR.hat
          ))
        }
      } 
    }
  
  
  tryCatch({
    
    ##### Generation of Random variables #####
    N <- 1000
    dim_X <- 1
    
    omega.v1.g1 <- function(x){ 0.3 + 0.1*(x^3) }
    omega.v1.g2 <- function(x){ 0.5 + 0.1*(x^3) }
    sens.1.v1 <- function(x){ expit(1.2 + 0.2*x) }
    spec.1.v1 <- function(x){ expit(1.2 - 0.3*x) }
    sens.2 <- function(x){ expit(2 + 0.2*x) }
    spec.2 <- function(x){ expit(1.2 - 0.2*x) }
    
    alpha.0 <- 0.4
    alpha.1 <- 0.2
    alpha.X <- 0.2
    alpha.TX <- 0.1
    
    beta.0 <- -0.8
    beta.1 <- 0.4
    beta.X <- 0.3
    beta.TX <- 0.2
    
    psi.0 <- psi.1 <- 1
    
    X <- runif(N, min = -1, max = 1)
    Z <- X
    G <- rbinom(N, size = 1, prob = 1/2) + 1
    
    p.D.v1 <- numeric(N)
    p.D.v1[G==1] <- omega.v1.g1(X[G==1])
    p.D.v1[G==2] <- omega.v1.g2(X[G==2])
    
    mu.v1 <- matrix(0, ncol = 2, nrow = N)
    mu.v1[, 1] <- 1 - spec.1.v1(X)
    mu.v1[, 2] <- sens.1.v1(X)
    
    theta.v1 <- matrix(0, ncol = 2, nrow = N)
    theta.v1[, 1] <- b.dot.inverse(mu.v1[, 1])
    theta.v1[, 2] <- b.dot.inverse(mu.v1[, 2])
    
    theta.v0 <- matrix(0, ncol = 2, nrow = N)
    theta.v0[, 1] <- theta.v1[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0
    theta.v0[, 2] <- theta.v1[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1
    
    temp <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
      ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0) + 
         exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1))
    p.V <- 1/(1 + temp)
    V <- rbinom(N, size = 1, prob = p.V)
    
    temp <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0))
    p.D.v0 <- temp/(1+temp)
    
    D <- rbinom(N, size = 1, prob = (V==1)*p.D.v1 + (V==0)*p.D.v0)
    temp <- lapply(1:N, FUN = function(i) V[i]*theta.v1[i, D[i]+1] + (1 - V[i])*theta.v0[i, D[i]+1]) %>% as.numeric() %>% b.dot()
    T.1 <- rbinom(N, size = 1, prob = temp)
    T.2 <- rbinom(N, size = 1, prob = D*sens.2(X) + (1 - D)*(1 - spec.2(X)))
    
    result <- EM(lambda = lambda.cv, train.index = 1:N, test.index = 1, working.mode = "Estimation")
    
    boostrap.times <- 500
    boostrap.result <- vector(mode = "list", length = boostrap.times)
    for (boostrap.i in 1:boostrap.times) {
      train.index <- sample(1:N, N, replace = TRUE)
      boostrap.result[[boostrap.i]] <- EM(lambda = lambda.cv, train.index = train.index, test.index = 1, working.mode = "Boostrap")
    }
    
    return(list(result = result,
                boostrap.result = boostrap.result))

  }, error = function(e) {
    return("FALSE")
  })
  
  
  
}


library(parallel)


num_simulations <- 50
cl <- makeCluster(num_simulations)
clusterExport(cl, "simulation")
num_repetitions <- 40


results <- list()
for (fake_value in 1:num_repetitions) {
  print(fake_value)
  start.time <- Sys.time()
  fake_values <- rep(fake_value, num_simulations)
  simulation_results <- parLapply(cl, fake_values, function(fake){
    simulation(fake)
  })
  results[[fake_value]] <- simulation_results
  end.time <- Sys.time()
  print(end.time - start.time)
}
stopCluster(cl)
