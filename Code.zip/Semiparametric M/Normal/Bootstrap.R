library("magrittr")

########## Basic functions ##########
K <- function(x){ ifelse(abs(x) <= 1, 0.75*(1 - x^2), 0) }
expit <- function(x){ 1/(1+exp(-x)) }
b <- function(x){ (x^2)/2 }
b.dot <- function(x){ x }
b.dot.inverse <- function(x){ x }
b.double.dot <- function(x){ 1 }
c.mine <- function(y, phi){ -1/2*log(2*3.141593*phi)-y^2/(2*phi) }
g <- function(x){ x }
g.dot <- function(x) { 1 }
g.inverse <- function(x){ x }
density.glm <- function(t, theta, psi){ exp((t*theta - b(theta))/psi + c.mine(t, psi)) }
c.mine.partial.psi <- function(y, psi){ -1/(2*psi) + y^2/(2*psi^2)}

simulation <- function(fake){

  library("magrittr")
  
  ########## Basic functions ##########
  K <- function(x){ ifelse(abs(x) <= 1, 0.75*(1 - x^2), 0) }
  expit <- function(x){ 1/(1+exp(-x)) }
  b <- function(x){ (x^2)/2 }
  b.dot <- function(x){ x }
  b.dot.inverse <- function(x){ x }
  b.double.dot <- function(x){ 1 }
  c.mine <- function(y, phi){ -1/2*log(2*3.141593*phi)-y^2/(2*phi) }
  g <- function(x){ x }
  g.dot <- function(x) { 1 }
  g.inverse <- function(x){ x }
  density.glm <- function(t, theta, psi){ exp((t*theta - b(theta))/psi + c.mine(t, psi)) }
  c.mine.partial.psi <- function(y, psi){ -1/(2*psi) + y^2/(2*psi^2)}
  
  # Set bandwidth
  lambda.cv <- 0.56
  
  EM <- function(lambda, train.index, test.index, working.mode){
    
    K <- function(x){
      ifelse(abs(x) <= 1, 0.75*(1 - x^2), 0)
    }
    
    ########## transform data ##########
    
    G.test <- G[test.index]
    Z.test <- Z[test.index]
    X.test <- X[test.index]
    V.test <- V[test.index]
    T.1.test <- T.1[test.index]
    T.2.test <- T.2[test.index]
    X.m.test <- X.m[test.index, ]
    
    N <- length(train.index)
    G <- G[train.index]
    Z <- Z[train.index]
    X <- X[train.index]
    V <- V[train.index] 
    T.1 <- T.1[train.index]
    T.2 <- T.2[train.index]
    X.m <- as.matrix(X.m[train.index, ], ncol = dim.multi)
    
    ########## Estimation ##########
    
    ########## Initial Value ##########
    stage.1.estimation <- function(G, T.1, T.2){
      
      p1.hat <- 0.4
      p2.hat <- 0.6
      mu.0.hat <- -0.2
      mu.1.hat <- 0.2
      psi.0.hat <- 1
      psi.1.hat <- 1
      sens.2.hat <- 0.6
      spec.2.hat <- 0.6
      
      old.params <- c(p1.hat, p2.hat, mu.0.hat, mu.1.hat, psi.0.hat, psi.1.hat, sens.2.hat, spec.2.hat)
      new.params <- numeric(length(old.params))
      while (sum(abs(old.params - new.params))>1e-3) {
        old.params <- c(p1.hat, p2.hat, mu.0.hat, mu.1.hat, psi.0.hat, psi.1.hat, sens.2.hat, spec.2.hat)
        
        l1 <- ((G==1)*p1.hat + (G==2)*p2.hat)*(dnorm(T.1, mean = mu.1.hat, sd = sqrt(psi.1.hat)))*(sens.2.hat*T.2 + (1 - sens.2.hat)*(1 - T.2))
        l0 <- (1 - ((G==1)*p1.hat + (G==2)*p2.hat))*(dnorm(T.1, mean = mu.0.hat, sd = sqrt(psi.0.hat)))*((1 - spec.2.hat)*T.2 + spec.2.hat*(1 - T.2))
        r <- l1/(l1 + l0)
        
        p1.hat <- sum((G==1)*r)/sum(G==1)
        p2.hat <- sum((G==2)*r)/sum(G==2)
        mu.0.hat <- sum((1 - r)*T.1)/sum(1 - r)
        mu.1.hat <- sum(r*T.1)/sum(r)
        psi.0.hat <- sum((1 - r)*((T.1 - mu.0.hat)^2))/sum(1 - r)
        psi.1.hat <- sum(r*((T.1 - mu.1.hat)^2))/sum(r)
        sens.2.hat <- sum(T.2*r)/sum(r)
        spec.2.hat <- sum((1 - T.2)*(1 - r))/sum(1 - r)
        
        new.params <- c(p1.hat, p2.hat, mu.0.hat, mu.1.hat, psi.0.hat, psi.1.hat, sens.2.hat, spec.2.hat)
        
      }
      
      return(new.params)
      
    }
    
    stage.1.result <- stage.1.estimation(G = G[V==1], T.1 = T.1[V==1], T.2 = T.2[V==1])
    
    ########## Step 1 of Estimation ##########
    
    alpha.0.hat <- 0
    alpha.1.hat <- 0
    alpha.X.hat <- 0
    alpha.TX.hat <- 0
    alpha.X.multi.hat <- 0
    alpha.TX.multi.hat <- 0
    beta.0.hat <- 0
    beta.1.hat <- 0
    beta.X.hat <- 0
    beta.TX.hat <- 0
    beta.X.multi.hat <- 0
    beta.TX.multi.hat <- 0
    
    p.D.v1.hat <- numeric(N)
    p.D.v1.hat[G==1] <- stage.1.result[1]
    p.D.v1.hat[G==2] <- stage.1.result[2]
    
    mu.v1.hat <- matrix(0, ncol = 2, nrow = N)
    mu.v1.hat[, 1] <- (stage.1.result[3] - 0.5)/2
    mu.v1.hat[, 2] <- (stage.1.result[4] + 0.5)/2
    
    theta.v1.hat <- matrix(0, ncol = 2, nrow = N)
    theta.v1.hat[, 1] <- b.dot.inverse(mu.v1.hat[, 1])
    theta.v1.hat[, 2] <- b.dot.inverse(mu.v1.hat[, 2])
    
    psi.0.hat <- rep(stage.1.result[5], N)
    psi.1.hat <- rep(stage.1.result[6], N)
    
    p.T.2.hat <- matrix(0, ncol = 2, nrow = N)
    p.T.2.hat[, 1] <- 1 - stage.1.result[8]
    p.T.2.hat[, 2] <- stage.1.result[7]
    
    old.params <- c(p.D.v1.hat, as.numeric(mu.v1.hat), psi.0.hat, psi.1.hat, as.numeric(p.T.2.hat))
    new.params <- numeric(length(old.params))
    record <- 0
    
    K_matrix <- outer(X, X, Vectorize(function(x, y) K((x - y) / lambda)))
    
    while ((max(abs(old.params - new.params)) > 1e-3)&&(record <= 100)) {
      
      old.params <- c(p.D.v1.hat, as.numeric(mu.v1.hat), psi.0.hat, psi.1.hat, as.numeric(p.T.2.hat))
      
      l1 <- p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], psi.1.hat)*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))
      l0 <- (1 - p.D.v1.hat)*density.glm(T.1, theta.v1.hat[, 1], psi.0.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1]))
      r <- l1/(l1 + l0)
      
      for (i in 1:dim.multi) for(j in 0:1) {
        temp <- ((K_matrix%*%as.matrix((G==1)*(X.m[, i]==j)*(V==1)*r))/(K_matrix%*%as.matrix((G==1)*(X.m[, i]==j)*(V==1)))) %>% as.numeric()
        p.D.v1.hat[(G==1)&(X.m[, i]==j)] <- temp[(G==1)&(X.m[, i]==j)]
        temp <- ((K_matrix%*%as.matrix((G==2)*(X.m[, i]==j)*(V==1)*r))/(K_matrix%*%as.matrix((G==2)*(X.m[, i]==j)*(V==1)))) %>% as.numeric()
        p.D.v1.hat[(G==2)&(X.m[, i]==j)] <- temp[(G==2)&(X.m[, i]==j)]
        
        temp <- ((K_matrix%*%as.matrix((1 - r)*(X.m[, i]==j)*(V==1)*T.1))/(K_matrix%*%as.matrix((1 - r)*(X.m[, i]==j)*(V==1)))) %>% as.numeric()
        mu.v1.hat[(1:N)[(X.m[, i]==j)], 1] <- temp[(1:N)[(X.m[, i]==j)]]
        temp <- ((K_matrix%*%as.matrix(r*(X.m[, i]==j)*(V==1)*T.1))/(K_matrix%*%as.matrix(r*(X.m[, i]==j)*(V==1)))) %>% as.numeric()
        mu.v1.hat[(1:N)[(X.m[, i]==j)], 2] <- temp[(1:N)[(X.m[, i]==j)]]
        
        temp <- ((K_matrix%*%as.matrix((1 - r)*(X.m[, i]==j)*(V==1)*((T.1 - mu.v1.hat[, 1])^2)))/(K_matrix%*%as.matrix((1 - r)*(X.m[, i]==j)*(V==1)))) %>% as.numeric()
        psi.0.hat[X.m[, i]==j] <- temp[X.m[, i]==j]
        temp <- ((K_matrix%*%as.matrix(r*(X.m[, i]==j)*(V==1)*((T.1 - mu.v1.hat[, 2])^2)))/(K_matrix%*%as.matrix(r*(X.m[, i]==j)*(V==1)))) %>% as.numeric()
        psi.1.hat[X.m[, i]==j] <- temp[X.m[, i]==j]
        
        temp <- 1 - ((K_matrix%*%as.matrix((1 - T.2)*(1 - r)*(X.m[, i]==j)*(V==1)))/(K_matrix%*%as.matrix((1 - r)*(X.m[, i]==j)*(V==1)))) %>% as.numeric()
        p.T.2.hat[(1:N)[(X.m[, i]==j)], 1] <- temp[(1:N)[(X.m[, i]==j)]]
        temp <- ((K_matrix%*%as.matrix(T.2*r*(X.m[, i]==j)*(V==1)))/(K_matrix%*%as.matrix(r*(X.m[, i]==j)*(V==1)))) %>% as.numeric()
        p.T.2.hat[(1:N)[(X.m[, i]==j)], 2] <- temp[(1:N)[(X.m[, i]==j)]]
        
      }
      
      new.params <- c(p.D.v1.hat, as.numeric(mu.v1.hat), psi.0.hat, psi.1.hat, as.numeric(p.T.2.hat))
      record = record + 1
      
    }
    
    ########## Step 2 of Estimation ##########
    
    theta.v1.hat <- matrix(0, ncol = 2, nrow = N)
    theta.v1.hat[, 1] <- b.dot.inverse(mu.v1.hat[, 1])
    theta.v1.hat[, 2] <- b.dot.inverse(mu.v1.hat[, 2])
    
    f3 <- function(params){
      
      alpha.0 <- params[1]
      alpha.1 <- params[2]
      alpha.X <- params[3:(2+dim_X)]
      alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
      beta.0 <- params[3+2*dim_X]
      beta.1 <- params[4+2*dim_X]
      beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
      beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
      alpha.X.multi <- params[(5+4*dim_X):(4+4*dim_X+dim.multi)]
      alpha.TX.multi <- params[(5+4*dim_X+dim.multi):(4+4*dim_X+2*dim.multi)]
      beta.X.multi <- params[(5+4*dim_X+2*dim.multi):(4+4*dim_X+3*dim.multi)]
      beta.TX.multi <- params[(5+4*dim_X+3*dim.multi):(4+4*dim_X+4*dim.multi)]
      
      theta.v0 <- matrix(0, ncol = 2, nrow = N)
      theta.v0[, 1] <- theta.v1.hat[ ,1] - (beta.1 + X%*%as.matrix(beta.TX) + X.m%*%as.matrix(beta.TX.multi))*psi.0.hat
      theta.v0[, 2] <- theta.v1.hat[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + X.m%*%as.matrix(beta.TX.multi) + alpha.1 + X%*%as.matrix(alpha.TX) + X.m%*%as.matrix(alpha.TX.multi))*psi.1.hat
      
      temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X) - X.m%*%as.matrix(alpha.X.multi)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat)/((1 - p.D.v1.hat)*exp((b(theta.v0[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat))
      p.D.v0 <- temp1/(1+temp1)
      p.D.v0[is.nan(p.D.v0)] <- 1
      
      temp2 <- exp(-beta.0 - (X%*%as.matrix(beta.X) + X.m%*%as.matrix(beta.X.multi)) %>% as.numeric()) *
        ((1 - p.D.v1.hat)*exp((b(theta.v0[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat) +
           exp((-alpha.0 - X%*%as.matrix(alpha.X) - X.m%*%as.matrix(alpha.X.multi)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat))
      p.V <- 1/(1 + temp2)
      
      likelihood <- (
        (1 - V)*((
          (1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], psi.0.hat) +
            p.D.v0*density.glm(T.1, theta.v0[, 2], psi.1.hat)
        ) %>% log()) +
          (1 - V)*((1 - p.V) %>% log()) + V*(p.V %>% log())
      ) %>% sum()
      
      return(-likelihood)
    }
    
    
    temp <- optim(par = c(alpha.0.hat, alpha.1.hat, alpha.X.hat, alpha.TX.hat, beta.0.hat, beta.1.hat, beta.X.hat, beta.TX.hat, alpha.X.multi.hat, alpha.TX.multi.hat, beta.X.multi.hat, beta.TX.multi.hat), fn = f3, method = "BFGS")$par
    alpha.0.hat <- temp[1]
    alpha.1.hat <- temp[2]
    alpha.X.hat <- temp[3:(2+dim_X)]
    alpha.TX.hat <- temp[(3+dim_X):(2+2*dim_X)]
    beta.0.hat <- temp[3+2*dim_X]
    beta.1.hat <- temp[4+2*dim_X]
    beta.X.hat <- temp[(5+2*dim_X):(4+3*dim_X)]
    beta.TX.hat <- temp[(5+3*dim_X):(4+4*dim_X)]
    alpha.X.multi.hat <- temp[(5+4*dim_X):(4+4*dim_X+dim.multi)]
    alpha.TX.multi.hat <- temp[(5+4*dim_X+dim.multi):(4+4*dim_X+2*dim.multi)]
    beta.X.multi.hat <- temp[(5+4*dim_X+2*dim.multi):(4+4*dim_X+3*dim.multi)]
    beta.TX.multi.hat <- temp[(5+4*dim_X+3*dim.multi):(4+4*dim_X+4*dim.multi)]
    
    
    if(working.mode == "CV"){
      
      ########## Calculate likelihood ###########
      p.D.v1.hat.test <- numeric(length(test.index))
      for (x.m in 0:1) {
        temp <- lapply(1:length(test.index), FUN = function(i) sum(V*(G==1)*(X.m==x.m)*r*K((Z.test[i] - Z)/lambda))/sum(V*(G==1)*(X.m==x.m)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        p.D.v1.hat.test[(G.test==1)&(X.m.test==x.m)] <- temp[(G.test==1)&(X.m.test==x.m)]
        temp <- lapply(1:length(test.index), FUN = function(i) sum(V*(G==2)*(X.m==x.m)*r*K((Z.test[i] - Z)/lambda))/sum(V*(G==2)*(X.m==x.m)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        p.D.v1.hat.test[(G.test==2)&(X.m.test==x.m)] <- temp[(G.test==2)&(X.m.test==x.m)]
      }
      
      mu.v1.hat.test <- matrix(0, ncol = 2, nrow = length(test.index))
      for (x.m in 0:1) {
        temp <- lapply(1:length(test.index), FUN = function(i) sum((1 - r)*(V==1)*(X.m==x.m)*T.1*K((Z.test[i] - Z)/lambda))/sum((1 - r)*(V==1)*(X.m==x.m)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        mu.v1.hat.test[X.m.test==x.m, 1] <- temp[X.m.test==x.m]
        temp <- lapply(1:length(test.index), FUN = function(i) sum(r*(V==1)*(X.m==x.m)*T.1*K((Z.test[i] - Z)/lambda))/sum(r*(V==1)*(X.m==x.m)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        mu.v1.hat.test[X.m.test==x.m, 2] <- temp[X.m.test==x.m]
      }
      
      mu.v1.hat[(V==1)&is.nan(mu.v1.hat[, 1]), 1] <- mean(mu.v1.hat[(V==1)&(!is.nan(mu.v1.hat[, 1])), 1])
      mu.v1.hat[(V==1)&is.nan(mu.v1.hat[, 2]), 2] <- mean(mu.v1.hat[(V==1)&(!is.nan(mu.v1.hat[, 2])), 2])
      
      psi.0.hat.test <- numeric(length(test.index))
      psi.1.hat.test <- numeric(length(test.index))
      for (x.m in 0:1) {
        temp <- lapply(1:length(test.index), FUN = function(i) sum((1 - r)*(V==1)*(X.m==x.m)*((T.1 - mu.v1.hat[, 1])^2)*K((Z.test[i] - Z)/lambda))/sum((1 - r)*(V==1)*(X.m==x.m)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        psi.0.hat.test[X.m.test==x.m] <- temp[X.m.test==x.m]
        psi.1.hat.test <- lapply(1:length(test.index), FUN = function(i) sum(r*(V==1)*(X.m==x.m)*((T.1 - mu.v1.hat[, 2])^2)*K((Z.test[i] - Z)/lambda))/sum(r*(V==1)*(X.m==x.m)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        psi.1.hat.test[X.m.test==x.m] <- temp[X.m.test==x.m]
      }
      
      psi.0.hat[is.nan(psi.0.hat)] <- mean(psi.0.hat[!is.nan(psi.0.hat)])
      psi.1.hat[is.nan(psi.1.hat)] <- mean(psi.1.hat[!is.nan(psi.1.hat)])
      
      p.T.2.hat.test <- matrix(0, ncol = 2, nrow = length(test.index))
      for (x.m in 0:1) {
        temp <- 1 - lapply(1:length(test.index), FUN = function(i) sum((1 - T.2)*(1 - r)*(V==1)*(X.m==x.m)*K((Z.test[i] - Z)/lambda))/sum((1 - r)*(V==1)*(X.m==x.m)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        p.T.2.hat.test[X.m.test==x.m, 1] <- temp[X.m.test==x.m]
        temp <- lapply(1:length(test.index), FUN = function(i) sum(T.2*r*(V==1)*(X.m==x.m)*K((Z.test[i] - Z)/lambda))/sum(r*(V==1)*(X.m==x.m)*K((Z.test[i] - Z)/lambda))) %>% as.numeric()
        p.T.2.hat.test[X.m.test==x.m, 2] <- temp[X.m.test==x.m]
      }
      
      p.T.2.hat[(V==1)&is.nan(p.T.2.hat[, 1]), 1] <- mean(p.T.2.hat[(V==1)&(!is.nan(p.T.2.hat[, 1])), 1])
      p.T.2.hat[(V==1)&is.nan(p.T.2.hat[, 2]), 2] <- mean(p.T.2.hat[(V==1)&(!is.nan(p.T.2.hat[, 2])), 2])
      
      theta.v1.hat.test <- matrix(0, ncol = 2, nrow = length(test.index))
      theta.v1.hat.test[, 1] <- b.dot.inverse(mu.v1.hat.test[, 1])
      theta.v1.hat.test[, 2] <- b.dot.inverse(mu.v1.hat.test[, 2])
      
      theta.v0.hat.test <- matrix(0, ncol = 2, nrow = length(test.index))
      theta.v0.hat.test[, 1] <- theta.v1.hat.test[ ,1] - (beta.1.hat + X.test%*%as.matrix(beta.TX.hat) + X.m.test%*%as.matrix(beta.TX.multi.hat))*psi.0.hat.test
      theta.v0.hat.test[, 2] <- theta.v1.hat.test[ ,2] - (beta.1.hat + X.test%*%as.matrix(beta.TX.hat) + X.m.test%*%as.matrix(beta.TX.multi.hat) + alpha.1.hat + X.test%*%as.matrix(alpha.TX.hat) + X.m.test%*%as.matrix(alpha.TX.multi.hat))*psi.1.hat.test
      
      temp <- exp((-alpha.0.hat - X.test%*%as.matrix(alpha.X.hat) -X.m.test%*%as.matrix(alpha.X.multi.hat)) %>% as.numeric())*p.D.v1.hat.test*exp((b(theta.v0.hat.test[, 2]) - b(theta.v1.hat.test[, 2]))/psi.1.hat.test)/((1 - p.D.v1.hat.test)*exp((b(theta.v0.hat.test[, 1]) - b(theta.v1.hat.test[, 1]))/psi.0.hat.test))
      p.D.v0.hat.test <- temp/(1+temp)
      p.D.v0.hat.test[is.nan(p.D.v0.hat.test)] <- 1
      
      temp <- exp(-beta.0.hat - (X.test%*%as.matrix(beta.X.hat) %>% as.numeric()) - X.m.test%*%as.matrix(beta.X.multi.hat) %>% as.numeric()) * 
        ((1 - p.D.v1.hat.test)*exp((b(theta.v0.hat.test[, 1]) - b(theta.v1.hat.test[, 1]))/psi.0.hat.test) + 
           exp((-alpha.0.hat - X.test%*%as.matrix(alpha.X.hat) - X.m.test%*%as.matrix(alpha.X.multi.hat)) %>% as.numeric())*p.D.v1.hat.test*exp((b(theta.v0.hat.test[, 2]) - b(theta.v1.hat.test[, 2]))/psi.1.hat.test))
      p.V.hat.test <- 1/(1 + temp)
      
      likelihood <- (V.test*((
        (1 - p.D.v1.hat.test)*density.glm(T.1.test, theta.v1.hat.test[, 1], psi.0.hat.test)*(T.2.test*(p.T.2.hat.test[, 1]) + (1 - T.2.test)*(1 - p.T.2.hat.test[, 1])) +
          p.D.v1.hat.test*density.glm(T.1.test, theta.v1.hat.test[, 2], psi.1.hat.test)*(T.2.test*(p.T.2.hat.test[, 2]) + (1 - T.2.test)*(1 - p.T.2.hat.test[, 2]))
      ) %>% log())) %>% sum() + (
        (1 - V.test)*((
          (1 - p.D.v0.hat.test)*density.glm(T.1.test, theta.v0.hat.test[, 1], psi.0.hat.test) +
            p.D.v0.hat.test*density.glm(T.1.test, theta.v0.hat.test[, 2], psi.1.hat.test)
        ) %>% log()) +
          (1 - V.test)*((1 - p.V.hat.test) %>% log()) + V.test*(p.V.hat.test %>% log())
      ) %>% sum()
      
      return(likelihood)
      
    }else{
      
      theta.v0.hat <- matrix(0, ncol = 2, nrow = N)
      theta.v0.hat[, 1] <- theta.v1.hat[ ,1] - (beta.1.hat + X%*%as.matrix(beta.TX.hat) + X.m%*%as.matrix(beta.TX.multi.hat))*psi.0.hat
      theta.v0.hat[, 2] <- theta.v1.hat[ ,2] - (beta.1.hat + X%*%as.matrix(beta.TX.hat) + X.m%*%as.matrix(beta.TX.multi.hat) + alpha.1.hat + X%*%as.matrix(alpha.TX.hat) + X.m%*%as.matrix(alpha.TX.multi.hat))*psi.1.hat
      
      temp1 <- exp((-alpha.0.hat - X%*%as.matrix(alpha.X.hat) - X.m%*%as.matrix(alpha.X.multi.hat)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0.hat[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat)/((1 - p.D.v1.hat)*exp((b(theta.v0.hat[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat))
      p.D.v0.hat <- temp1/(1+temp1)
      
      temp2 <- exp(-beta.0.hat - (X%*%as.matrix(beta.X.hat) + X.m%*%as.matrix(beta.X.multi.hat)) %>% as.numeric()) * 
        ((1 - p.D.v1.hat)*exp((b(theta.v0.hat[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat) + 
           exp((-alpha.0.hat - X%*%as.matrix(alpha.X.hat) - X.m%*%as.matrix(alpha.X.multi.hat)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0.hat[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat))
      p.V.hat <- 1/(1 + temp2)
      
      ########## I matrix ##########
      temp <- matrix(0, nrow = N, ncol = N)
      temp[lower.tri(temp)] <- 1
      diag(temp) <- 1/2
      
      I <- temp[rank(T.1), rank(T.1)]
      
      ########## AUC ##########
      q.hat <- alpha.0.hat + alpha.1.hat*T.1 + (X%*%(alpha.X.hat %>% as.matrix()) %>% as.numeric()) + (X.m%*%(alpha.X.multi.hat %>% as.matrix()) %>% as.numeric()) + T.1 *((X%*%(alpha.TX.hat %>% as.matrix()) %>% as.numeric()) + (X.m%*%(alpha.TX.multi.hat %>% as.matrix()) %>% as.numeric()))
      
      rho.1.hat <- numeric(N)
      rho.0.hat <- numeric(N)
      rho.V.hat <- numeric(N)
      rho.1.hat <- (p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], psi.1.hat))/(p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], psi.1.hat) + (1 - p.D.v1.hat)*density.glm(T.1, theta.v1.hat[, 1], psi.0.hat))
      rho.0.hat <- rho.1.hat*(exp(-q.hat))/(rho.1.hat*exp(-q.hat) + (1 - rho.1.hat))
      rho.V.hat <- V*rho.1.hat + (1 - V)*rho.0.hat
      
      TPR.FI.hat <- function(s){
        sum(as.numeric(T.1 >= s)*rho.V.hat)/sum(rho.V.hat)
      }
      FPR.FI.hat <- function(s){
        sum(as.numeric(T.1 >= s)*(1 - rho.V.hat))/sum(1 - rho.V.hat)
      }
      temp <- (rho.V.hat) %o% (1 - rho.V.hat)
      diag(temp) <- 0
      v.FI.hat <- sum(temp*I)/(sum(rho.V.hat)*sum(1 - rho.V.hat) - sum(rho.V.hat*(1 - rho.V.hat)))
      
      tau.hat <- numeric(N)
      D.MSI.hat <- numeric(N)
      tau.hat <- (rho.1.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])))/(rho.1.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - rho.1.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
      D.MSI.hat <- V*tau.hat + (1 - V)*rho.0.hat
      
      TPR.MSI.hat <- function(s){
        sum(as.numeric(T.1 >= s)*D.MSI.hat)/sum(D.MSI.hat)
      }
      FPR.MSI.hat <- function(s){
        sum(as.numeric(T.1 >= s)*(1 - D.MSI.hat))/sum(1 - D.MSI.hat)
      }
      temp <- (D.MSI.hat) %o% (1 - D.MSI.hat)
      diag(temp) <- 0
      v.MSI.hat <- sum(temp*I)/(sum(D.MSI.hat)*sum(1 - D.MSI.hat) - sum(D.MSI.hat*(1 - D.MSI.hat)))
      
      h.hat <- numeric(N)
      xi.hat <- numeric(N)
      phi.hat <- numeric(N)
      pi.star.hat <- numeric(N)
      h.hat <- beta.0.hat + beta.1.hat*T.1 + (X%*%(beta.X.hat %>% as.matrix()) %>% as.numeric()) + (X.m%*%(beta.X.multi.hat %>% as.matrix()) %>% as.numeric()) + T.1 *((X%*%(beta.TX.hat %>% as.matrix()) %>% as.numeric()) + (X.m%*%(beta.TX.multi.hat %>% as.matrix()) %>% as.numeric()))
      xi.hat <- rho.1.hat*(1 + exp(- h.hat - q.hat))/(rho.1.hat*(1 + exp(- h.hat - q.hat)) + (1 - rho.1.hat)*(1 + exp(- h.hat)))
      phi.hat <- xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))/(xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
      pi.star.hat <- (xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))*((h.hat + q.hat) %>% expit()) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1]))*(h.hat %>% expit())) /
        (xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
      
      TPR.IPW.hat <- function(s){
        sum(as.numeric(T.1 >= s)*V*phi.hat/pi.star.hat)/sum(V*phi.hat/pi.star.hat)
      }
      FPR.IPW.hat <- function(s){
        sum(as.numeric(T.1 >= s)*V*(1 - phi.hat)/pi.star.hat)/sum(V*(1 - phi.hat)/pi.star.hat)
      }
      temp <- (V*phi.hat/pi.star.hat) %o% (V*(1 - phi.hat)/pi.star.hat)
      diag(temp) <- 0
      v.IPW.hat <- sum(temp*I)/(sum(V*phi.hat/pi.star.hat)*sum(V*(1 - phi.hat)/pi.star.hat) - sum(V*phi.hat/pi.star.hat*(V*(1 - phi.hat)/pi.star.hat)))
      
      
      D.PDR.hat <- numeric(N)
      D.PDR.hat <- V*phi.hat/pi.star.hat + (1 - V/pi.star.hat)*rho.0.hat
      
      TPR.PDR.hat <- function(s){
        sum(as.numeric(T.1 >= s)*D.PDR.hat)/sum(D.PDR.hat)
      }
      FPR.PDR.hat <- function(s){
        sum(as.numeric(T.1 >= s)*(1 - D.PDR.hat))/sum(1 - D.PDR.hat)
      }
      temp <- (D.PDR.hat) %o% (1 - D.PDR.hat)
      diag(temp) <- 0
      v.PDR.hat <- sum(temp*I)/(sum(D.PDR.hat)*sum(1 - D.PDR.hat) - sum(D.PDR.hat*(1 - D.PDR.hat)))
      
      ########## ROC ##########
      s_values <- seq(min(T.1), max(T.1), length.out = 100)
      plot.axis.s <- seq(0, 1, length.out = 100)
      
      FPR_values.FI <- sapply(s_values, FPR.FI.hat)
      TPR_values.FI <- sapply(s_values, TPR.FI.hat)
      unique_indices.FI <- !duplicated(FPR_values.FI)
      FPR_values_unique.FI <- FPR_values.FI[unique_indices.FI]
      TPR_values_unique.FI <- TPR_values.FI[unique_indices.FI]
      ROC.hat.FI <- approx(FPR_values_unique.FI, TPR_values_unique.FI, xout = plot.axis.s)$y
      
      FPR_values.MSI <- sapply(s_values, FPR.MSI.hat)
      TPR_values.MSI <- sapply(s_values, TPR.MSI.hat)
      unique_indices.MSI <- !duplicated(FPR_values.MSI)
      FPR_values_unique.MSI <- FPR_values.MSI[unique_indices.MSI]
      TPR_values_unique.MSI <- TPR_values.MSI[unique_indices.MSI]
      ROC.hat.MSI <- approx(FPR_values_unique.MSI, TPR_values_unique.MSI, xout = plot.axis.s)$y
      
      FPR_values.IPW <- sapply(s_values, FPR.IPW.hat)
      TPR_values.IPW <- sapply(s_values, TPR.IPW.hat)
      unique_indices.IPW <- !duplicated(FPR_values.IPW)
      FPR_values_unique.IPW <- FPR_values.IPW[unique_indices.IPW]
      TPR_values_unique.IPW <- TPR_values.IPW[unique_indices.IPW]
      ROC.hat.IPW <- approx(FPR_values_unique.IPW, TPR_values_unique.IPW, xout = plot.axis.s)$y
      
      FPR_values.PDR <- sapply(s_values, FPR.PDR.hat)
      TPR_values.PDR <- sapply(s_values, TPR.PDR.hat)
      unique_indices.PDR <- !duplicated(FPR_values.PDR)
      FPR_values_unique.PDR <- FPR_values.PDR[unique_indices.PDR]
      TPR_values_unique.PDR <- TPR_values.PDR[unique_indices.PDR]
      ROC.hat.PDR <- approx(FPR_values_unique.PDR, TPR_values_unique.PDR, xout = plot.axis.s)$y
      
      
      ########## The senssitivity and specificity of the reference standard ##########
      sens_of_S.hat <- sum(V*tau.hat*T.2)/sum(V*tau.hat)
      spec_of_S.hat <- sum(V*(1 - tau.hat)*(1 - T.2))/sum(V*(1 - tau.hat))
      
      if(working.mode == "Estimation"){
        return(list(alpha.0.hat = alpha.0.hat,
                    alpha.1.hat = alpha.1.hat,
                    alpha.X.hat = alpha.X.hat,
                    alpha.TX.hat = alpha.TX.hat,
                    alpha.X.multi.hat = alpha.X.multi.hat,
                    alpha.TX.multi.hat = alpha.TX.multi.hat,
                    beta.0.hat = beta.0.hat,
                    beta.1.hat = beta.1.hat,
                    beta.X.hat = beta.X.hat,
                    beta.TX.hat = beta.TX.hat,
                    beta.X.multi.hat = beta.X.multi.hat,
                    beta.TX.multi.hat = beta.TX.multi.hat,
                    v.FI.hat = v.FI.hat,
                    v.MSI.hat = v.MSI.hat,
                    v.IPW.hat = v.IPW.hat,
                    v.PDR.hat = v.PDR.hat,
                    ROC.hat.FI = ROC.hat.FI,
                    ROC.hat.MSI = ROC.hat.MSI,
                    ROC.hat.IPW = ROC.hat.IPW,
                    ROC.hat.PDR = ROC.hat.PDR,
                    sens_of_S.hat = sens_of_S.hat,
                    spec_of_S.hat = spec_of_S.hat
        ))
      }else if(working.mode == "Boostrap"){
        return(list(alpha.0.hat = alpha.0.hat,
                    alpha.1.hat = alpha.1.hat,
                    alpha.X.hat = alpha.X.hat,
                    alpha.TX.hat = alpha.TX.hat,
                    alpha.X.multi.hat = alpha.X.multi.hat,
                    alpha.TX.multi.hat = alpha.TX.multi.hat,
                    beta.0.hat = beta.0.hat,
                    beta.1.hat = beta.1.hat,
                    beta.X.hat = beta.X.hat,
                    beta.TX.hat = beta.TX.hat,
                    beta.X.multi.hat = beta.X.multi.hat,
                    beta.TX.multi.hat = beta.TX.multi.hat,
                    v.FI.hat = v.FI.hat,
                    v.MSI.hat = v.MSI.hat,
                    v.IPW.hat = v.IPW.hat,
                    v.PDR.hat = v.PDR.hat,
                    ROC.hat.FI = ROC.hat.FI,
                    ROC.hat.MSI = ROC.hat.MSI,
                    ROC.hat.IPW = ROC.hat.IPW,
                    ROC.hat.PDR = ROC.hat.PDR,
                    sens_of_S.hat = sens_of_S.hat,
                    spec_of_S.hat = spec_of_S.hat
        ))
      }
    } 
  }
  
  
  tryCatch({
    
    ########## Generation of Random variables ##########
    N <- 1000
    dim_X <- 1
    dim.multi <- 1
    
    omega.v1.g1 <- function(x, x.m){ 0.3 + 0.1*(x^3) + 0.05*x.m }
    omega.v1.g2 <- function(x, x.m){ 0.5 + 0.1*(x^3) + 0.05*x.m }
    mu.T1.v1 <- function(d, x, x.m){ (1 - d)*(-0.5 + 0.2*sin(3.14159*x/2*3) - 0.1*x.m) + d*(0.5 + 0.2*sin(3.14159*x/2*3) + 0.1*x.m) }
    sens.2 <- function(x, x.m){ expit(2 + 0.2*x + 0.1*x.m) }
    spec.2 <- function(x, x.m){ expit(1.2 - 0.2*x  - 0.1*x.m) }
    psi <- function(d, x, x.m) {(1 - d)*0.2*exp(0.2*x + 0.1*x.m) + d*0.2*exp(0.2*x + 0.1*x.m)}
    
    
    alpha.0 <- 0.4
    alpha.1 <- 0.2
    alpha.X <- 0.2
    alpha.TX <- 0.1
    alpha.X.multi <- 0.05
    alpha.TX.multi <- 0.02
    beta.0 <- -0.8
    beta.1 <- 0.4
    beta.X <- 0.3
    beta.TX <- 0.2
    beta.X.multi <- 0.1
    beta.TX.multi <- 0.04
    
    X <- runif(N, min = -1, max = 1)
    Z <- X
    G <- rbinom(N, size = 1, prob = 0.5) + 1
    X.m <- matrix(0 ,ncol = dim.multi, nrow = N)
    X.m[, 1] <- rbinom(N, size = 1, prob = 0.2)
    
    p.D.v1 <- numeric(N)
    for (temp in 0:1) {
      p.D.v1[(G==1)&(X.m[, 1]==temp)] <- omega.v1.g1(X[(G==1)&(X.m[, 1]==temp)], temp)
      p.D.v1[(G==2)&(X.m[, 1]==temp)] <- omega.v1.g2(X[(G==2)&(X.m[, 1]==temp)], temp)
    }
    
    psi.0 <- psi(d = 0, x = X, x.m = X.m[, 1])
    psi.1 <- psi(d = 1, x = X, x.m = X.m[, 1])
    
    mu.v1 <- matrix(0, ncol = 2, nrow = N)
    mu.v1[, 1] <- mu.T1.v1(d = 0, x = X, x.m = X.m[, 1])
    mu.v1[, 2] <- mu.T1.v1(d = 1, x = X, x.m = X.m[, 1])
    
    theta.v1 <- matrix(0, ncol = 2, nrow = N)
    theta.v1[, 1] <- b.dot.inverse(mu.v1[, 1])
    theta.v1[, 2] <- b.dot.inverse(mu.v1[, 2])
    
    theta.v0 <- matrix(0, ncol = 2, nrow = N)
    theta.v0[, 1] <- theta.v1[ ,1] - (beta.1 + X%*%as.matrix(beta.TX) + X.m%*%as.matrix(beta.TX.multi))*psi.0
    theta.v0[, 2] <- theta.v1[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + X.m%*%as.matrix(beta.TX.multi) + alpha.1 + X%*%as.matrix(alpha.TX) + X.m%*%as.matrix(alpha.TX.multi))*psi.1
    
    temp <- exp(-beta.0 - (X%*%as.matrix(beta.X) + X.m%*%as.matrix(beta.X.multi)) %>% as.numeric()) * 
      ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0) + 
         exp((-alpha.0 - X%*%as.matrix(alpha.X) - X.m%*%as.matrix(alpha.X.multi)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1))
    p.V <- 1/(1 + temp)
    V <- rbinom(N, size = 1, prob = p.V)
    
    temp <- exp((-alpha.0 - X%*%as.matrix(alpha.X) - X.m%*%as.matrix(alpha.X.multi)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0))
    p.D.v0 <- temp/(1+temp)
    
    temp <- numeric(N)
    temp[V==0] <- p.D.v0[V==0]
    temp[V==1] <- p.D.v1[V==1]
    D <- rbinom(N, size = 1, prob = temp)
    
    temp <- lapply(1:N, FUN = function(i) V[i]*theta.v1[i, D[i]+1] + (1 - V[i])*theta.v0[i, D[i]+1]) %>% as.numeric() %>% b.dot()
    tempp <- lapply(1:N, FUN = function(i) D[i]*(sqrt(psi.1[i])) + (1 - D[i])*(sqrt(psi.0[i]))) %>% as.numeric()
    T.1 <- rnorm(N, mean = temp, sd = tempp)
    T.2 <- rbinom(N, size = 1, prob = D*sens.2(x = X, x.m = X.m[, 1]) + (1 - D)*(1 - spec.2(x = X, x.m = X.m[, 1])))
    
    result <- EM(lambda = lambda.cv, train.index = 1:N, test.index = 1, working.mode = "Estimation")
    
    boostrap.times <- 500
    boostrap.result <- vector(mode = "list", length = boostrap.times)
    for (boostrap.i in 1:boostrap.times) {
      train.index <- sample(1:N, N, replace = TRUE)
      temp <- "FALSE"
      tryCatch({
        temp <- EM(lambda = lambda.cv, train.index = train.index, test.index = 1, working.mode = "Boostrap")
      }, error = function(e){  }) 
      boostrap.result[[boostrap.i]] <- temp
    }
    
    return(list(result = result,
                boostrap.result = boostrap.result))
    
  }, error = function(e) {
    return("FALSE")
  })
  
  
  
}


library(parallel)


num_simulations <- 50
cl <- makeCluster(num_simulations)
clusterExport(cl, "simulation")
num_repetitions <- 40


results <- list()
for (fake_value in 1:num_repetitions) {
  print(fake_value)
  start.time <- Sys.time()
  fake_values <- rep(fake_value, num_simulations)
  simulation_results <- parLapply(cl, fake_values, function(fake){
    simulation(fake)
  })
  results[[fake_value]] <- simulation_results
  end.time <- Sys.time()
  print(end.time - start.time)
}
stopCluster(cl)

save(file = "Result.Rdata", results)

rm(list = ls())
gc()
