library("magrittr")
library("numDeriv")
library("parallel")

expit <- function(x){ 1/(1+exp(-x)) }
b <- function(x){ (x^2)/2 }
b.dot <- function(x){ x }
b.dot.inverse <- function(x){ x }
b.double.dot <- function(x){ 1 }
c.mine <- function(y, phi){ -1/2*log(2*3.141593*phi)-y^2/(2*phi) }
g <- function(x){ x }
g.dot <- function(x) { 1 }
g.inverse <- function(x){ x }
density.glm <- function(t, theta, psi){
  exp((t*theta - b(theta))/psi + c.mine(t, psi))
}
c.mine.partial.psi <- function(y, psi){ -1/(2*psi) + y^2/(2*psi^2)}

N <- 1000
dim_X <- 2
K <- 2

simulation <- function(fake){

  library("magrittr")
  library(numDeriv)
  
  expit <- function(x){ 1/(1+exp(-x)) }
  b <- function(x){ (x^2)/2 }
  b.dot <- function(x){ x }
  b.dot.inverse <- function(x){ x }
  b.double.dot <- function(x){ 1 }
  c.mine <- function(y, phi){ -1/2*log(2*3.141593*phi)-y^2/(2*phi) }
  g <- function(x){ x }
  g.dot <- function(x) { 1 }
  g.inverse <- function(x){ x }
  density.glm <- function(t, theta, psi){
    exp((t*theta - b(theta))/psi + c.mine(t, psi))
  }
  c.mine.partial.psi <- function(y, psi){ -1/(2*psi) + y^2/(2*psi^2)}
  
  ##### Generation of Random variables ######
  
  N <- 1000
  dim_X <- 2
  
  G <- rbinom(N, size = 1, prob = 0.5) + 1
  
  Z <- runif(N, min = -1, max = 1)
  X <- matrix(0, nrow = N, ncol = dim_X)
  X[, 1] <- Z
  X[, 2] <- rnorm(N, mean = 0, sd = 1)
  
  alpha.0 <- 0.6
  alpha.1 <- 0.3
  alpha.X <- numeric(length = dim_X)
  alpha.X <- c(0.2, -0.1)
  alpha.TX <- numeric(length = dim_X)
  alpha.TX <- c(0.1, -0.2)
  
  beta.0 <- -1.3
  beta.1 <- 0.8
  beta.X <- numeric(length = dim_X)
  beta.X <- c(0.5, 0.5)
  beta.TX <- numeric(length = dim_X)
  beta.TX <- c(0.3, 0.2)
  
  p.D.v1 <- numeric(N)
  p.D.v1[G==1] <- 0.3 + 0.2*(cos(Z[G==1]*3.14159/2))
  p.D.v1[G==2] <- 0.5 + 0.2*(cos(Z[G==2]*3.14159/2))
  
  delta <- matrix(0, ncol = 2, nrow = 1 + dim_X)
  delta[, 1] <- c(-0.5, 0.2, -0.3)
  delta[, 2] <- c(0.5, 0.3, -0.2)
  
  psi.0 <- 0.2
  psi.1 <- 0.2
  
  mu.v1 <- matrix(0, ncol = 2, nrow = N)
  mu.v1[, 1] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 1]) + delta[1, 1]) %>% as.numeric())
  mu.v1[, 2] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 2]) + delta[1, 2]) %>% as.numeric())
  
  theta.v1 <- matrix(0, ncol = 2, nrow = N)
  theta.v1[, 1] <- b.dot.inverse(mu.v1[, 1])
  theta.v1[, 2] <- b.dot.inverse(mu.v1[, 2])
  
  theta.v0 <- matrix(0, ncol = 2, nrow = N)
  theta.v0[, 1] <- theta.v1[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0
  theta.v0[, 2] <- theta.v1[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1
  
  temp <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
    ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0) + 
       exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1))
  p.V <- 1/(1 + temp)
  V <- rbinom(N, size = 1, prob = p.V)

  temp <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0))
  p.D.v0 <- temp/(1+temp)
  
  temp <- numeric(N)
  temp[V==0] <- p.D.v0[V==0]
  temp[V==1] <- p.D.v1[V==1]
  D <- rbinom(N, size = 1, prob = temp)
  
  temp <- lapply(1:N, FUN = function(i) V[i]*theta.v1[i, D[i]+1] + (1 - V[i])*theta.v0[i, D[i]+1]) %>% as.numeric() %>% b.dot()
  tempp <- lapply(1:N, FUN = function(i) D[i]*(sqrt(psi.1)) + (1 - D[i])*(sqrt(psi.0))) %>% as.numeric()
  T.1 <- rnorm(N, mean = temp, sd = tempp)
  
  zeta <- matrix(0, ncol = 2, nrow = 1 + dim_X)
  zeta[, 1] <- c(-1.2, 0.2, -0.2)
  zeta[, 2] <- c(2, 0.2, -0.2)
  
  temp <- lapply(1:N, FUN = function(i) (1 - D[i])*(sum(X[i, ]*zeta[-1, 1]) + zeta[1, 1]) + D[i]*(sum(X[i, ]*zeta[-1, 2]) + zeta[1, 2])) %>% as.numeric() %>% expit()
  T.2 <- rbinom(N, size = 1, prob = temp)
  
  p.T.2 <- matrix(0, ncol = 2, nrow = N)
  p.T.2[, 1] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 1]) + zeta[1, 1])) %>% as.numeric() %>% expit()
  p.T.2[, 2] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 2]) + zeta[1, 2])) %>% as.numeric() %>% expit()
  
  ##### Esitimation Functions #####
  
  parametric.estimation <- function(){
    
    library("magrittr")
    library("numDeriv")
    
    expit <- function(x){ 1/(1+exp(-x)) }
    b <- function(x){ (x^2)/2 }
    b.dot <- function(x){ x }
    b.dot.inverse <- function(x){ x }
    b.double.dot <- function(x){ 1 }
    c.mine <- function(y, phi){ -1/2*log(2*3.141593*phi) - y^2/(2*phi) }
    g <- function(x){ x }
    g.dot <- function(x) { 1 }
    g.inverse <- function(x){ x }
    density.glm <- function(t, theta, psi){ exp((t*theta - b(theta))/psi + c.mine(t, psi)) }
    c.mine.partial.psi <- function(y, psi){ -1/(2*psi) + y^2/(2*psi^2)}
    
    ##### Estimation #####
    
    f <- function(params){
      
      alpha.0 <- params[1]
      alpha.1 <- params[2]
      alpha.X <- params[3:(2+dim_X)]
      alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
      beta.0 <- params[3+2*dim_X]
      beta.1 <- params[4+2*dim_X]
      beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
      beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
      gamma <- matrix(params[(5+4*dim_X):(6+6*dim_X)], ncol = 2, nrow = 1 + dim_X)
      delta <- matrix(params[(7+6*dim_X):(8+8*dim_X)], ncol = 2, nrow = 1 + dim_X)
      psi.0 <- params[9+8*dim_X]
      psi.1 <- params[10+8*dim_X]
      zeta <- matrix(c(params[11+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)], params[12+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)]), ncol = 2, nrow = 1 + dim_X)
      
      p.D.v1 <-  lapply(1:N, FUN = function(i) sum(X[i, ]*gamma[-1, G[i]]) + gamma[1, G[i]]) %>% as.numeric() %>% expit()
      
      mu.v1 <- matrix(0, ncol = 2, nrow = N)
      mu.v1[, 1] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 1]) + delta[1, 1]) %>% as.numeric())
      mu.v1[, 2] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 2]) + delta[1, 2]) %>% as.numeric())
      
      theta.v1 <- matrix(0, ncol = 2, nrow = N)
      theta.v1[, 1] <- b.dot.inverse(mu.v1[, 1])
      theta.v1[, 2] <- b.dot.inverse(mu.v1[, 2])
      
      p.T.2 <- matrix(0, ncol = 2, nrow = N)
      p.T.2[, 1] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 1]) + zeta[1, 1])) %>% as.numeric() %>% expit()
      p.T.2[, 2] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 2]) + zeta[1, 2])) %>% as.numeric() %>% expit()
      
      theta.v0 <- matrix(0, ncol = 2, nrow = N)
      theta.v0[, 1] <- theta.v1[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0
      theta.v0[, 2] <- theta.v1[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1
      
      temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0))
      p.D.v0 <- temp1/(1+temp1)
      
      temp2 <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
        ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0) + 
           exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1))
      p.V <- 1/(1 + temp2)
      
      likelihood <- (V*((
        (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])) +
          p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
      ) %>% log())) %>% sum() + (
        (1 - V)*((
          (1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) +
            p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))
        ) %>% log()) +
          (1 - V)*((1 - p.V) %>% log()) + V*(p.V %>% log())
      ) %>% sum()
      
      return(-likelihood)
    }
    
    g <- function(params){
      
      deri <- numeric(length(params))
      
      alpha.0 <- params[1]
      alpha.1 <- params[2]
      alpha.X <- params[3:(2+dim_X)]
      alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
      beta.0 <- params[3+2*dim_X]
      beta.1 <- params[4+2*dim_X]
      beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
      beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
      gamma <- matrix(params[(5+4*dim_X):(6+6*dim_X)], ncol = 2, nrow = 1 + dim_X)
      delta <- matrix(params[(7+6*dim_X):(8+8*dim_X)], ncol = 2, nrow = 1 + dim_X)
      psi.0 <- params[9+8*dim_X]
      psi.1 <- params[10+8*dim_X]
      zeta <- matrix(c(params[11+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)], params[12+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)]), ncol = 2, nrow = 1 + dim_X)
      
      p.D.v1 <-  lapply(1:N, FUN = function(i) sum(X[i, ]*gamma[-1, G[i]]) + gamma[1, G[i]]) %>% as.numeric() %>% expit()
      
      mu.v1 <- matrix(0, ncol = 2, nrow = N)
      mu.v1[, 1] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 1]) + delta[1, 1]) %>% as.numeric())
      mu.v1[, 2] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 2]) + delta[1, 2]) %>% as.numeric())
      
      theta.v1 <- matrix(0, ncol = 2, nrow = N)
      theta.v1[, 1] <- b.dot.inverse(mu.v1[, 1])
      theta.v1[, 2] <- b.dot.inverse(mu.v1[, 2])
      
      p.T.2 <- matrix(0, ncol = 2, nrow = N)
      p.T.2[, 1] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 1]) + zeta[1, 1])) %>% as.numeric() %>% expit()
      p.T.2[, 2] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 2]) + zeta[1, 2])) %>% as.numeric() %>% expit()
      
      theta.v0 <- matrix(0, ncol = 2, nrow = N)
      theta.v0[, 1] <- theta.v1[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0
      theta.v0[, 2] <- theta.v1[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1
      
      temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0))
      p.D.v0 <- temp1/(1+temp1)
      
      temp2 <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
        ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0) + 
           exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1))
      p.V <- 1/(1 + temp2)
      
      likelihood <- (V*((
        (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])) +
          p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
      ) %>% log())) %>% sum() + (
        (1 - V)*((
          (1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) +
            p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))
        ) %>% log()) +
          (1 - V)*((1 - p.V) %>% log()) + V*(p.V %>% log())
      ) %>% sum()
      
      denom1 <- (1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) +
        p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))
      
      patial.p.D.v0 <- ((1 - V)*(
        (-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) +
          density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))
      )/denom1)
      
      partial.temp2 <- (V/p.V - (1 - V)/(1 - p.V))*(-1)*(p.V^2)
      
      deri[1] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(-1) +
                    (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                       (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(-1)))
      ) %>% sum()
      
      deri[2] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(- b.dot(theta.v0[, 2])) +
                    (1 - V)*p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(b.dot(theta.v0[, 2]) - T.1)/denom1 +
                    (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                       exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(- b.dot(theta.v0[, 2])))
      ) %>% sum()
      
      for (i in 1:dim_X) {
        deri[2+i] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(-X[, i]) +
                        (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                           (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(-1))*X[, i])
        ) %>% sum()
      }
      
      for (i in 1:dim_X) {
        deri[2+dim_X+i] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(- b.dot(theta.v0[, 2]))*(X[, i]) +
                              (1 - V)*p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(b.dot(theta.v0[, 2]) - T.1)*(X[, i])/denom1 +
                              (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                                 exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(- b.dot(theta.v0[, 2]))*(X[, i]))
        ) %>% sum()
      }
      
      deri[3+2*dim_X] <- (partial.temp2*(-1)*temp2) %>% sum()
      
      deri[4+2*dim_X] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(b.dot(theta.v0[, 1]) - b.dot(theta.v0[, 2])) +
                            (1 - V)*(1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N))*(b.dot(theta.v0[, 1]) - T.1)/denom1 +
                            (1 - V)*p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(b.dot(theta.v0[, 2]) - T.1)/denom1 +
                            (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                               (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(- b.dot(theta.v0[, 2])) +
                                  ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)*(- b.dot(theta.v0[, 1])))))
      ) %>% sum()
      
      for (i in 1:dim_X) {
        deri[4+2*dim_X+i] <- (partial.temp2*(-1)*temp2*X[, i]) %>% sum()
      }
      
      for (i in 1:dim_X) {
        deri[4+3*dim_X+i] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(b.dot(theta.v0[, 1]) - b.dot(theta.v0[, 2]))*(X[, i]) +
                                (1 - V)*(1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N))*(b.dot(theta.v0[, 1]) - T.1)*(X[, i])/denom1 +
                                (1 - V)*p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(b.dot(theta.v0[, 2]) - T.1)*(X[, i])/denom1 +
                                (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                                   (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(- b.dot(theta.v0[, 2]))*(X[, i]) +
                                      ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)*(- b.dot(theta.v0[, 1])))*(X[, i])))
        ) %>% sum()
      }
      
      denom2 <- (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])) +
        p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
      
      patial.p.D.v1 <-
        (V*(
          (-1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])) +
            density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
        )/denom2) +
        (partial.temp2*(
          exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
            (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1) +
               ((-1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)))
        )) +
        ((1 - V)*(
          ((-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) + density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N)))*
            ((1 - p.D.v0)*(1 - p.D.v0)) * (1/(1 - p.D.v1)) *
            (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)))
        )/denom1)
      
      deri[5+4*dim_X] <- (patial.p.D.v1*(G==1)*p.D.v1*(1 - p.D.v1)) %>% sum()
      
      for (i in 1:dim_X) {
        deri[5+4*dim_X+i] <- (patial.p.D.v1*(G==1)*p.D.v1*(1 - p.D.v1)*X[, i]) %>% sum()
      }
      
      deri[6+5*dim_X] <- (patial.p.D.v1*(G==2)*p.D.v1*(1 - p.D.v1)) %>% sum()
      
      for (i in 1:dim_X) {
        deri[6+5*dim_X+i] <- (patial.p.D.v1*(G==2)*p.D.v1*(1 - p.D.v1)*X[, i]) %>% sum()
      }
      
      partial.density.glm.0.eta <- (V*(
        (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*((T.1 - b.dot(theta.v1[, 1]))/psi.0)*(1/b.double.dot(theta.v1[, 1]))*(1/g.dot(mu.v1[, 1]))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1]))
      )/denom2) +
        (partial.temp2*(
          exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
            ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)*(1/psi.0)*(b.dot(theta.v0[, 1]) - b.dot(theta.v1[, 1]))*(1/b.double.dot(theta.v1[, 1]))*(1/g.dot(mu.v1[, 1])))
        )) +
        ((1 - V)*(
          (((-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) + density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N)))*
             ((1 - p.D.v0)*(1 - p.D.v0)) *
             temp1 *
             (-1)*(1/psi.0)*(b.dot(theta.v0[, 1]) - b.dot(theta.v1[, 1]))*(1/b.double.dot(theta.v1[, 1]))*(1/g.dot(mu.v1[, 1]))) +
            ((1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N))*(1/psi.0)*(T.1 - b.dot(theta.v0[, 1]))*(1/b.double.dot(theta.v1[, 1]))*(1/g.dot(mu.v1[, 1])))
        )/denom1)
      
      partial.density.glm.1.eta <- (V*(
        p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*((T.1 - b.dot(theta.v1[, 2]))/psi.0)*(1/b.double.dot(theta.v1[, 2]))*(1/g.dot(mu.v1[, 2]))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
      )/denom2) +
        (partial.temp2*(
          exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
            (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(1/psi.1)*(b.dot(theta.v0[, 2]) - b.dot(theta.v1[, 2]))*(1/b.double.dot(theta.v1[, 2]))*(1/g.dot(mu.v1[, 2])))
        )) +
        ((1 - V)*(
          (((-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) + density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N)))*
             ((1 - p.D.v0)*(1 - p.D.v0)) *
             temp1 *
             (1/psi.1)*(b.dot(theta.v0[, 2]) - b.dot(theta.v1[, 2]))*(1/b.double.dot(theta.v1[, 2]))*(1/g.dot(mu.v1[, 2]))) +
            (p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(1/psi.1)*(T.1 - b.dot(theta.v0[, 2]))*(1/b.double.dot(theta.v1[, 2]))*(1/g.dot(mu.v1[, 2])))
        )/denom1)
      
      deri[7+6*dim_X] <- partial.density.glm.0.eta %>% sum()
      
      for (i in 1:dim_X) {
        deri[7+6*dim_X+i] <- (partial.density.glm.0.eta*X[, i]) %>% sum()
      }
      
      deri[8+7*dim_X] <- partial.density.glm.1.eta %>% sum()
      for (i in 1:dim_X) {
        deri[8+7*dim_X+i] <- (partial.density.glm.1.eta*X[, i]) %>% sum()
      }
      
      deri[9+8*dim_X] <-
        ((V*(
          (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*((T.1*theta.v1[, 1] - b(theta.v1[, 1]))*(-1)*(1/(psi.0^2)) + c.mine.partial.psi(T.1, psi.0))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1]))
        )/denom2) +
          ((1 - V)*(
            (((-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) + density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N)))*
               ((1 - p.D.v0)*(1 - p.D.v0)) *
               temp1*
               (-1)*(1/psi.0^2)*((b.dot(theta.v0[, 1])*(-1)*beta.1*psi.0) - (b(theta.v0[, 1]) - b(theta.v1[, 1])))) +
              ((1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N))*(((1/psi.0^2)*(((T.1 - b.dot(theta.v0[, 1]))*(-beta.1)*(psi.0)) - (T.1*theta.v0[, 1] - b(theta.v0[, 1])))) + (c.mine.partial.psi(T.1, psi.0))))
          )/denom1) +
          (partial.temp2*(
            exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
              (1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)*(1/psi.0^2)*((b.dot(theta.v0[, 1])*(-1)*beta.1*psi.0) - (b(theta.v0[, 1]) - b(theta.v1[, 1])))
          ))) %>% sum()
      
      deri[10+8*dim_X] <-
        ((V*(
          p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*((T.1*theta.v1[, 2] - b(theta.v1[, 2]))*(-1)*(1/(psi.1^2)) + c.mine.partial.psi(T.1, psi.1))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
        )/denom2)+
          ((1 - V)*(
            (((-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) + density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N)))*
               ((1 - p.D.v0)*(1 - p.D.v0)) *
               temp1 *
               (1/psi.1^2)*((b.dot(theta.v0[, 2])*(-1)*beta.1*psi.1) - (b(theta.v0[, 2]) - b(theta.v1[, 2])))) +
              (p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(((1/psi.1^2)*(((T.1 - b.dot(theta.v0[, 2]))*(-beta.1)*(psi.1)) - (T.1*theta.v0[, 2] - b(theta.v0[, 2])))) + (c.mine.partial.psi(T.1, psi.1))))
          )/denom1) +
          (partial.temp2*(
            exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
              exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(1/psi.1^2)*((b.dot(theta.v0[, 2])*(-1)*beta.1*psi.1) - (b(theta.v0[, 2]) - b(theta.v1[, 2])))
          ))) %>% sum()
      
      patial.p.T.2.0 <- (V*(
        (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*(T.2 + (1 - T.2)*(-1))
      )/denom2)
      
      patial.p.T.2.1 <- (V*(
        p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*(T.2 + (1 - T.2)*(-1))
      )/denom2)
      
      deri[11+8*dim_X] <- (patial.p.T.2.0*p.T.2[, 1]*(1 - p.T.2[, 1])) %>% sum()
      deri[12+8*dim_X] <- (patial.p.T.2.1*p.T.2[, 2]*(1 - p.T.2[, 2])) %>% sum()
      
      for (i in 1:dim_X) {
        deri[12+8*dim_X+i] <- (patial.p.T.2.1*p.T.2[, 2]*(1 - p.T.2[, 2])*X[, i] + patial.p.T.2.0*p.T.2[, 1]*(1 - p.T.2[, 1])*X[, i]) %>% sum()
      }
      
      return(-deri)
    }
    
    alpha.0.hat <- 0
    alpha.1.hat <- 0
    alpha.X.hat <- numeric(length = dim_X)
    alpha.TX.hat <- numeric(length = dim_X)
    beta.0.hat <- 0
    beta.1.hat <- 0
    beta.X.hat <- numeric(length = dim_X)
    beta.TX.hat <- numeric(length = dim_X)
    gamma.hat <- matrix(0, ncol = 2, nrow = 1 + dim_X)
    delta.hat <- matrix(0, ncol = 2, nrow = 1 + dim_X)
    psi.0.hat <- 1
    psi.1.hat <- 1
    zeta.hat <- matrix(0, ncol = 2, nrow = 1 + dim_X)
    zeta.hat[1, 1] <- -0.1
    zeta.hat[1, 2] <- 0.2
    zeta.X.hat <- numeric(dim_X)
    
    initial.params <- c( alpha.0.hat,
                         alpha.1.hat,
                         alpha.X.hat,
                         alpha.TX.hat,
                         beta.0.hat,
                         beta.1.hat,
                         beta.X.hat,
                         beta.TX.hat,
                         as.vector(gamma.hat),
                         as.vector(delta.hat),
                         psi.0.hat,
                         psi.1.hat,
                         zeta.hat[1, 1],
                         zeta.hat[1, 2],
                         zeta.X.hat
    )
    
    result <- optim(par = initial.params, fn = f, gr = g, method = "BFGS", hessian = TRUE)
    
    temp <- result$par
    estimated.params <- result$par
    information.matrix.hat <- result$hessian
    information.matrix.inverse.hat <- solve(information.matrix.hat)

    alpha.0.hat <- temp[1]
    alpha.1.hat <- temp[2]
    alpha.X.hat <- temp[3:(2+dim_X)]
    alpha.TX.hat <- temp[(3+dim_X):(2+2*dim_X)]
    beta.0.hat <- temp[3+2*dim_X]
    beta.1.hat <- temp[4+2*dim_X]
    beta.X.hat <- temp[(5+2*dim_X):(4+3*dim_X)]
    beta.TX.hat <- temp[(5+3*dim_X):(4+4*dim_X)]
    gamma.hat <- matrix(temp[(5+4*dim_X):(6+6*dim_X)], ncol = 2, nrow = 1 + dim_X)
    delta.hat <- matrix(temp[(7+6*dim_X):(8+8*dim_X)], ncol = 2, nrow = 1 + dim_X)
    psi.0.hat <- temp[9+8*dim_X]
    psi.1.hat <- temp[10+8*dim_X]
    zeta.hat <- matrix(c(temp[11+8*dim_X], temp[(13+8*dim_X):(12+9*dim_X)], temp[12+8*dim_X], temp[(13+8*dim_X):(12+9*dim_X)]), ncol = 2, nrow = 1 + dim_X)
    
    ##### Preparation #####
    p.T.2.hat <- matrix(0, ncol = 2, nrow = N)
    p.T.2.hat[, 1] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta.hat[-1, 1]) + zeta.hat[1, 1])) %>% as.numeric() %>% expit()
    p.T.2.hat[, 2] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta.hat[-1, 2]) + zeta.hat[1, 2])) %>% as.numeric() %>% expit()
    
    p.D.v1.hat <-  lapply(1:N, FUN = function(i) sum(X[i, ]*gamma.hat[-1, G[i]]) + gamma.hat[1, G[i]]) %>% as.numeric() %>% expit()
    
    mu.v1.hat <- matrix(0, ncol = 2, nrow = N)
    mu.v1.hat[, 1] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta.hat[-1, 1]) + delta.hat[1, 1]) %>% as.numeric())
    mu.v1.hat[, 2] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta.hat[-1, 2]) + delta.hat[1, 2]) %>% as.numeric())
    
    theta.v1.hat <- matrix(0, ncol = 2, nrow = N)
    theta.v1.hat[, 1] <- b.dot.inverse(mu.v1.hat[, 1])
    theta.v1.hat[, 2] <- b.dot.inverse(mu.v1.hat[, 2])
    
    theta.v0.hat <- matrix(0, ncol = 2, nrow = N)
    theta.v0.hat[, 1] <- theta.v1.hat[ ,1] - (beta.1.hat + X%*%as.matrix(beta.TX.hat))*psi.0.hat
    theta.v0.hat[, 2] <- theta.v1.hat[ ,2] - (beta.1.hat + X%*%as.matrix(beta.TX.hat) + alpha.1.hat + X%*%as.matrix(alpha.TX.hat))*psi.1.hat
    
    temp1 <- exp((-alpha.0.hat - X%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0.hat[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat)/((1 - p.D.v1.hat)*exp((b(theta.v0.hat[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat))
    p.D.v0.hat <- temp1/(1+temp1)
    
    temp2 <- exp(-beta.0.hat - X%*%as.matrix(beta.X.hat) %>% as.numeric()) * 
      ((1 - p.D.v1.hat)*exp((b(theta.v0.hat[, 1]) - b(theta.v1.hat[, 1]))/psi.0.hat) + 
         exp((-alpha.0.hat - X%*%as.matrix(alpha.X.hat)) %>% as.numeric())*p.D.v1.hat*exp((b(theta.v0.hat[, 2]) - b(theta.v1.hat[, 2]))/psi.1.hat))
    p.V.hat <- 1/(1 + temp2)
    
    p.D.hat <- (p.V.hat*p.D.v1.hat + (1 - p.V.hat)*p.D.v0.hat) %>% mean()
    
    individual.partial <- function(params){
      
      deri <- matrix(0, nrow = N, ncol = length(params))
      
      alpha.0 <- params[1]
      alpha.1 <- params[2]
      alpha.X <- params[3:(2+dim_X)]
      alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
      beta.0 <- params[3+2*dim_X]
      beta.1 <- params[4+2*dim_X]
      beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
      beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
      gamma <- matrix(params[(5+4*dim_X):(6+6*dim_X)], ncol = 2, nrow = 1 + dim_X)
      delta <- matrix(params[(7+6*dim_X):(8+8*dim_X)], ncol = 2, nrow = 1 + dim_X)
      psi.0 <- params[9+8*dim_X]
      psi.1 <- params[10+8*dim_X]
      zeta <- matrix(c(params[11+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)], params[12+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)]), ncol = 2, nrow = 1 + dim_X)
      
      p.D.v1 <-  lapply(1:N, FUN = function(i) sum(X[i, ]*gamma[-1, G[i]]) + gamma[1, G[i]]) %>% as.numeric() %>% expit()
      
      mu.v1 <- matrix(0, ncol = 2, nrow = N)
      mu.v1[, 1] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 1]) + delta[1, 1]) %>% as.numeric())
      mu.v1[, 2] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 2]) + delta[1, 2]) %>% as.numeric())
      
      theta.v1 <- matrix(0, ncol = 2, nrow = N)
      theta.v1[, 1] <- b.dot.inverse(mu.v1[, 1])
      theta.v1[, 2] <- b.dot.inverse(mu.v1[, 2])
      
      p.T.2 <- matrix(0, ncol = 2, nrow = N)
      p.T.2[, 1] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 1]) + zeta[1, 1])) %>% as.numeric() %>% expit()
      p.T.2[, 2] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 2]) + zeta[1, 2])) %>% as.numeric() %>% expit()

      theta.v0 <- matrix(0, ncol = 2, nrow = N)
      theta.v0[, 1] <- theta.v1[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0
      theta.v0[, 2] <- theta.v1[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1

      temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0))
      p.D.v0 <- temp1/(1+temp1)
      
      temp2 <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
        ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0) + 
           exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1))
      p.V <- 1/(1 + temp2)
      
      likelihood <- (V*((
        (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])) +
          p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
      ) %>% log())) %>% sum() + (
        (1 - V)*((
          (1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) +
            p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))
        ) %>% log()) +
          (1 - V)*((1 - p.V) %>% log()) + V*(p.V %>% log())
      ) %>% sum()
      
      denom1 <- (1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) +
        p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))
      
      patial.p.D.v0 <- ((1 - V)*(
        (-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) +
          density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))
      )/denom1)
      
      partial.temp2 <- (V/p.V - (1 - V)/(1 - p.V))*(-1)*(p.V^2)
      
      deri[, 1] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(-1) +
                      (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                         (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(-1)))
      )
      
      deri[, 2] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(- b.dot(theta.v0[, 2])) +
                      (1 - V)*p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(b.dot(theta.v0[, 2]) - T.1)/denom1 +
                      (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                         exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(- b.dot(theta.v0[, 2])))
      )
      
      for (i in 1:dim_X) {
        deri[, 2+i] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(-X[, i]) +
                          (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                             (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(-1))*X[, i])
        )
      }
      
      for (i in 1:dim_X) {
        deri[, 2+dim_X+i] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(- b.dot(theta.v0[, 2]))*(X[, i]) +
                                (1 - V)*p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(b.dot(theta.v0[, 2]) - T.1)*(X[, i])/denom1 +
                                (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                                   exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(- b.dot(theta.v0[, 2]))*(X[, i]))
        )
      }
      
      deri[, 3+2*dim_X] <- (partial.temp2*(-1)*temp2)
      
      deri[, 4+2*dim_X] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(b.dot(theta.v0[, 1]) - b.dot(theta.v0[, 2])) +
                              (1 - V)*(1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N))*(b.dot(theta.v0[, 1]) - T.1)/denom1 +
                              (1 - V)*p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(b.dot(theta.v0[, 2]) - T.1)/denom1 +
                              (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                                 (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(- b.dot(theta.v0[, 2])) +
                                    ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)*(- b.dot(theta.v0[, 1])))))
      )
      
      for (i in 1:dim_X) {
        deri[, 4+2*dim_X+i] <- (partial.temp2*(-1)*temp2*X[, i])
      }
      
      for (i in 1:dim_X) {
        deri[, 4+3*dim_X+i] <- (patial.p.D.v0*(1 - p.D.v0)*(1 - p.D.v0)*temp1*(b.dot(theta.v0[, 1]) - b.dot(theta.v0[, 2]))*(X[, i]) +
                                  (1 - V)*(1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N))*(b.dot(theta.v0[, 1]) - T.1)*(X[, i])/denom1 +
                                  (1 - V)*p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(b.dot(theta.v0[, 2]) - T.1)*(X[, i])/denom1 +
                                  (partial.temp2*exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
                                     (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(- b.dot(theta.v0[, 2]))*(X[, i]) +
                                        ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)*(- b.dot(theta.v0[, 1])))*(X[, i])))
        )
      }
      
      denom2 <- (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])) +
        p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
      
      patial.p.D.v1 <-
        (V*(
          (-1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])) +
            density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
        )/denom2) +
        (partial.temp2*(
          exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
            (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1) +
               ((-1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)))
        )) +
        ((1 - V)*(
          ((-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) + density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N)))*
            ((1 - p.D.v0)*(1 - p.D.v0)) * (1/(1 - p.D.v1)) *
            (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)))
        )/denom1)
      
      deri[, 5+4*dim_X] <- (patial.p.D.v1*(G==1)*p.D.v1*(1 - p.D.v1))
      
      for (i in 1:dim_X) {
        deri[, 5+4*dim_X+i] <- (patial.p.D.v1*(G==1)*p.D.v1*(1 - p.D.v1)*X[, i])
      }
      
      deri[, 6+5*dim_X] <- (patial.p.D.v1*(G==2)*p.D.v1*(1 - p.D.v1))
      
      for (i in 1:dim_X) {
        deri[, 6+5*dim_X+i] <- (patial.p.D.v1*(G==2)*p.D.v1*(1 - p.D.v1)*X[, i])
      }
      
      partial.density.glm.0.eta <- (V*(
        (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*((T.1 - b.dot(theta.v1[, 1]))/psi.0)*(1/b.double.dot(theta.v1[, 1]))*(1/g.dot(mu.v1[, 1]))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1]))
      )/denom2) +
        (partial.temp2*(
          exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
            ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)*(1/psi.0)*(b.dot(theta.v0[, 1]) - b.dot(theta.v1[, 1]))*(1/b.double.dot(theta.v1[, 1]))*(1/g.dot(mu.v1[, 1])))
        )) +
        ((1 - V)*(
          (((-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) + density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N)))*
             ((1 - p.D.v0)*(1 - p.D.v0)) *
             temp1 *
             (-1)*(1/psi.0)*(b.dot(theta.v0[, 1]) - b.dot(theta.v1[, 1]))*(1/b.double.dot(theta.v1[, 1]))*(1/g.dot(mu.v1[, 1]))) +
            ((1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N))*(1/psi.0)*(T.1 - b.dot(theta.v0[, 1]))*(1/b.double.dot(theta.v1[, 1]))*(1/g.dot(mu.v1[, 1])))
        )/denom1)
      
      partial.density.glm.1.eta <- (V*(
        p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*((T.1 - b.dot(theta.v1[, 2]))/psi.0)*(1/b.double.dot(theta.v1[, 2]))*(1/g.dot(mu.v1[, 2]))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
      )/denom2) +
        (partial.temp2*(
          exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
            (exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(1/psi.1)*(b.dot(theta.v0[, 2]) - b.dot(theta.v1[, 2]))*(1/b.double.dot(theta.v1[, 2]))*(1/g.dot(mu.v1[, 2])))
        )) +
        ((1 - V)*(
          (((-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) + density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N)))*
             ((1 - p.D.v0)*(1 - p.D.v0)) *
             temp1 *
             (1/psi.1)*(b.dot(theta.v0[, 2]) - b.dot(theta.v1[, 2]))*(1/b.double.dot(theta.v1[, 2]))*(1/g.dot(mu.v1[, 2]))) +
            (p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(1/psi.1)*(T.1 - b.dot(theta.v0[, 2]))*(1/b.double.dot(theta.v1[, 2]))*(1/g.dot(mu.v1[, 2])))
        )/denom1)
      
      deri[, 7+6*dim_X] <- partial.density.glm.0.eta
      
      for (i in 1:dim_X) {
        deri[, 7+6*dim_X+i] <- (partial.density.glm.0.eta*X[, i])
      }
      
      deri[, 8+7*dim_X] <- partial.density.glm.1.eta
      for (i in 1:dim_X) {
        deri[, 8+7*dim_X+i] <- (partial.density.glm.1.eta*X[, i])
      }
      
      deri[, 9+8*dim_X] <-
        ((V*(
          (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*((T.1*theta.v1[, 1] - b(theta.v1[, 1]))*(-1)*(1/(psi.0^2)) + c.mine.partial.psi(T.1, psi.0))*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1]))
        )/denom2) +
          ((1 - V)*(
            (((-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) + density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N)))*
               ((1 - p.D.v0)*(1 - p.D.v0)) *
               temp1*
               (-1)*(1/psi.0^2)*((b.dot(theta.v0[, 1])*(-1)*beta.1*psi.0) - (b(theta.v0[, 1]) - b(theta.v1[, 1])))) +
              ((1 - p.D.v0)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N))*(((1/psi.0^2)*(((T.1 - b.dot(theta.v0[, 1]))*(-beta.1)*(psi.0)) - (T.1*theta.v0[, 1] - b(theta.v0[, 1])))) + (c.mine.partial.psi(T.1, psi.0))))
          )/denom1) +
          (partial.temp2*(
            exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
              (1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0)*(1/psi.0^2)*((b.dot(theta.v0[, 1])*(-1)*beta.1*psi.0) - (b(theta.v0[, 1]) - b(theta.v1[, 1])))
          )))
      
      deri[, 10+8*dim_X] <-
        ((V*(
          p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*((T.1*theta.v1[, 2] - b(theta.v1[, 2]))*(-1)*(1/(psi.1^2)) + c.mine.partial.psi(T.1, psi.1))*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))
        )/denom2)+
          ((1 - V)*(
            (((-1)*density.glm(T.1, theta.v0[, 1], rep(psi.0, times = N)) + density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N)))*
               ((1 - p.D.v0)*(1 - p.D.v0)) *
               temp1 *
               (1/psi.1^2)*((b.dot(theta.v0[, 2])*(-1)*beta.1*psi.1) - (b(theta.v0[, 2]) - b(theta.v1[, 2])))) +
              (p.D.v0*density.glm(T.1, theta.v0[, 2], rep(psi.1, times = N))*(((1/psi.1^2)*(((T.1 - b.dot(theta.v0[, 2]))*(-beta.1)*(psi.1)) - (T.1*theta.v0[, 2] - b(theta.v0[, 2])))) + (c.mine.partial.psi(T.1, psi.1))))
          )/denom1) +
          (partial.temp2*(
            exp(- beta.0 - (lapply(1:N, FUN = function(i) (sum(X[i, ]*beta.X))) %>% as.numeric())) *
              exp(- alpha.0 - X%*%(alpha.X %>% as.matrix()) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)*(1/psi.1^2)*((b.dot(theta.v0[, 2])*(-1)*beta.1*psi.1) - (b(theta.v0[, 2]) - b(theta.v1[, 2])))
          )))
      
      patial.p.T.2.0 <- (V*(
        (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N))*(T.2 + (1 - T.2)*(-1))
      )/denom2)
      
      patial.p.T.2.1 <- (V*(
        p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N))*(T.2 + (1 - T.2)*(-1))
      )/denom2)
      
      deri[, 11+8*dim_X] <- (patial.p.T.2.0*p.T.2[, 1]*(1 - p.T.2[, 1]))
      deri[, 12+8*dim_X] <- (patial.p.T.2.1*p.T.2[, 2]*(1 - p.T.2[, 2]))
      
      for (i in 1:dim_X) {
        deri[, 12+8*dim_X+i] <- (patial.p.T.2.1*p.T.2[, 2]*(1 - p.T.2[, 2])*X[, i] + patial.p.T.2.0*p.T.2[, 1]*(1 - p.T.2[, 1])*X[, i])
      }
      
      
      return(deri)
    }
    
    individual.deriv <- individual.partial(estimated.params) %>% t()
    
    ##### I matrix #####
    temp <- matrix(0, nrow = N, ncol = N)
    temp[lower.tri(temp)] <- 1
    diag(temp) <- 1/2
    
    I <- temp[rank(T.1), rank(T.1)]
    
    ##### AUC #####
    q.hat <- alpha.0.hat + alpha.1.hat*T.1 + (X%*%(alpha.X.hat %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(alpha.TX.hat %>% as.matrix()) %>% as.numeric())
    
    rho.1.hat <- numeric(N)
    rho.0.hat <- numeric(N)
    rho.V.hat <- numeric(N)
    rho.1.hat <- (p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], rep(psi.1.hat, times = N)))/(p.D.v1.hat*density.glm(T.1, theta.v1.hat[, 2], rep(psi.1.hat, times = N)) + (1 - p.D.v1.hat)*density.glm(T.1, theta.v1.hat[, 1], rep(psi.0.hat, times = N)))
    rho.0.hat <- rho.1.hat*(exp(-q.hat))/(rho.1.hat*exp(-q.hat) + (1 - rho.1.hat))
    rho.V.hat <- V*rho.1.hat + (1 - V)*rho.0.hat
    
    
    TPR.FI.hat <- function(s){
      sum(as.numeric(T.1 >= s)*rho.V.hat)/sum(rho.V.hat)
    }
    FPR.FI.hat <- function(s){
      sum(as.numeric(T.1 >= s)*(1 - rho.V.hat))/sum(1 - rho.V.hat)
    }
    temp <- (rho.V.hat) %o% (1 - rho.V.hat)
    diag(temp) <- 0
    v.FI.hat <- sum(temp*I)/(sum(rho.V.hat)*sum(1 - rho.V.hat) - sum(rho.V.hat*(1 - rho.V.hat)))
    
    sum.U.FI.hat <- function(params){
      
      alpha.0 <- params[1]
      alpha.1 <- params[2]
      alpha.X <- params[3:(2+dim_X)]
      alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
      beta.0 <- params[3+2*dim_X]
      beta.1 <- params[4+2*dim_X]
      beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
      beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
      gamma <- matrix(params[(5+4*dim_X):(6+6*dim_X)], ncol = 2, nrow = 1 + dim_X)
      delta <- matrix(params[(7+6*dim_X):(8+8*dim_X)], ncol = 2, nrow = 1 + dim_X)
      psi.0 <- params[9+8*dim_X]
      psi.1 <- params[10+8*dim_X]
      zeta <- matrix(c(params[11+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)], params[12+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)]), ncol = 2, nrow = 1 + dim_X)
      
      p.D.v1 <-  lapply(1:N, FUN = function(i) sum(X[i, ]*gamma[-1, G[i]]) + gamma[1, G[i]]) %>% as.numeric() %>% expit()
      
      mu.v1 <- matrix(0, ncol = 2, nrow = N)
      mu.v1[, 1] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 1]) + delta[1, 1]) %>% as.numeric())
      mu.v1[, 2] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 2]) + delta[1, 2]) %>% as.numeric())
      
      theta.v1 <- matrix(0, ncol = 2, nrow = N)
      theta.v1[, 1] <- b.dot.inverse(mu.v1[, 1])
      theta.v1[, 2] <- b.dot.inverse(mu.v1[, 2])
      
      p.T.2 <- matrix(0, ncol = 2, nrow = N)
      p.T.2[, 1] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 1]) + zeta[1, 1])) %>% as.numeric() %>% expit()
      p.T.2[, 2] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 2]) + zeta[1, 2])) %>% as.numeric() %>% expit()
      
      theta.v0 <- matrix(0, ncol = 2, nrow = N)
      theta.v0[, 1] <- theta.v1[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0
      theta.v0[, 2] <- theta.v1[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1
      
      temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0))
      p.D.v0 <- temp1/(1+temp1)
      
      temp2 <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
        ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0) + 
           exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1))
      p.V <- 1/(1 + temp2)
      
      q <- alpha.0 + alpha.1*T.1 + (X%*%(alpha.X %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(alpha.TX %>% as.matrix()) %>% as.numeric())
      
      rho.1 <- numeric(N)
      rho.0 <- numeric(N)
      rho.V <- numeric(N)
      rho.1 <- (p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N)))/(p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N)) + (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N)))
      rho.0 <- rho.1*(exp(-q))/(rho.1*exp(-q) + (1 - rho.1))
      rho.V <- V*rho.1 + (1 - V)*rho.0
      tau <- numeric(N)
      D.MSI <- numeric(N)
      tau <- (rho.1*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])))/(rho.1*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - rho.1)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      D.MSI <- V*tau + (1 - V)*rho.0
      h <- numeric(N)
      xi <- numeric(N)
      phi <- numeric(N)
      pi.star <- numeric(N)
      h <- beta.0 + beta.1*T.1 + (X%*%(beta.X %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(beta.TX %>% as.matrix()) %>% as.numeric())
      xi <- rho.1*(1 + exp(- h - q))/(rho.1*(1 + exp(- h - q)) + (1 - rho.1)*(1 + exp(- h)))
      phi <- xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))/(xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      pi.star <- (xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))*((h + q) %>% expit()) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1]))*(h %>% expit())) /
        (xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      D.PDR <- numeric(N)
      D.PDR <- V*phi/pi.star + (1 - V/pi.star)*rho.0
      
      temp <- (rho.V) %o% (1 - rho.V)
      diag(temp) <- 0
      
      result <- sum(temp * (I - v.FI.hat))
      
      return(result)
    }
    temp1 <- grad(sum.U.FI.hat, estimated.params)
    Q.FI <- rowMeans(temp * (I - v.FI.hat)) + colMeans(temp * (I - v.FI.hat)) + ((t(as.matrix(temp1))%*%information.matrix.inverse.hat%*%individual.deriv) %>% as.numeric())/N
    variance.AUC.FI.hat <- mean(Q.FI^2)/((p.D.hat*(1 - p.D.hat))^2)
    
    tau.hat <- numeric(N)
    D.MSI.hat <- numeric(N)
    tau.hat <- (rho.1.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])))/(rho.1.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - rho.1.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
    D.MSI.hat <- V*tau.hat + (1 - V)*rho.0.hat
    
    TPR.MSI.hat <- function(s){
      sum(as.numeric(T.1 >= s)*D.MSI.hat)/sum(D.MSI.hat)
    }
    FPR.MSI.hat <- function(s){
      sum(as.numeric(T.1 >= s)*(1 - D.MSI.hat))/sum(1 - D.MSI.hat)
    }
    temp <- (D.MSI.hat) %o% (1 - D.MSI.hat)
    diag(temp) <- 0
    v.MSI.hat <- sum(temp*I)/(sum(D.MSI.hat)*sum(1 - D.MSI.hat) - sum(D.MSI.hat*(1 - D.MSI.hat)))
    
    sum.U.MSI.hat <- function(params){
      
      alpha.0 <- params[1]
      alpha.1 <- params[2]
      alpha.X <- params[3:(2+dim_X)]
      alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
      beta.0 <- params[3+2*dim_X]
      beta.1 <- params[4+2*dim_X]
      beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
      beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
      gamma <- matrix(params[(5+4*dim_X):(6+6*dim_X)], ncol = 2, nrow = 1 + dim_X)
      delta <- matrix(params[(7+6*dim_X):(8+8*dim_X)], ncol = 2, nrow = 1 + dim_X)
      psi.0 <- params[9+8*dim_X]
      psi.1 <- params[10+8*dim_X]
      zeta <- matrix(c(params[11+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)], params[12+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)]), ncol = 2, nrow = 1 + dim_X)
      
      p.D.v1 <-  lapply(1:N, FUN = function(i) sum(X[i, ]*gamma[-1, G[i]]) + gamma[1, G[i]]) %>% as.numeric() %>% expit()
      
      mu.v1 <- matrix(0, ncol = 2, nrow = N)
      mu.v1[, 1] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 1]) + delta[1, 1]) %>% as.numeric())
      mu.v1[, 2] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 2]) + delta[1, 2]) %>% as.numeric())
      
      theta.v1 <- matrix(0, ncol = 2, nrow = N)
      theta.v1[, 1] <- b.dot.inverse(mu.v1[, 1])
      theta.v1[, 2] <- b.dot.inverse(mu.v1[, 2])
      
      p.T.2 <- matrix(0, ncol = 2, nrow = N)
      p.T.2[, 1] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 1]) + zeta[1, 1])) %>% as.numeric() %>% expit()
      p.T.2[, 2] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 2]) + zeta[1, 2])) %>% as.numeric() %>% expit()
      
      theta.v0 <- matrix(0, ncol = 2, nrow = N)
      theta.v0[, 1] <- theta.v1[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0
      theta.v0[, 2] <- theta.v1[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1
      
      temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0))
      p.D.v0 <- temp1/(1+temp1)
      
      temp2 <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
        ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0) + 
           exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1))
      p.V <- 1/(1 + temp2)
      
      q <- alpha.0 + alpha.1*T.1 + (X%*%(alpha.X %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(alpha.TX %>% as.matrix()) %>% as.numeric())
      
      rho.1 <- numeric(N)
      rho.0 <- numeric(N)
      rho.V <- numeric(N)
      rho.1 <- (p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N)))/(p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N)) + (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N)))
      rho.0 <- rho.1*(exp(-q))/(rho.1*exp(-q) + (1 - rho.1))
      rho.V <- V*rho.1 + (1 - V)*rho.0
      tau <- numeric(N)
      D.MSI <- numeric(N)
      tau <- (rho.1*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])))/(rho.1*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - rho.1)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      D.MSI <- V*tau + (1 - V)*rho.0
      h <- numeric(N)
      xi <- numeric(N)
      phi <- numeric(N)
      pi.star <- numeric(N)
      h <- beta.0 + beta.1*T.1 + (X%*%(beta.X %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(beta.TX %>% as.matrix()) %>% as.numeric())
      xi <- rho.1*(1 + exp(- h - q))/(rho.1*(1 + exp(- h - q)) + (1 - rho.1)*(1 + exp(- h)))
      phi <- xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))/(xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      pi.star <- (xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))*((h + q) %>% expit()) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1]))*(h %>% expit())) /
        (xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      D.PDR <- numeric(N)
      D.PDR <- V*phi/pi.star + (1 - V/pi.star)*rho.0
      
      temp <- (D.MSI) %o% (1 - D.MSI)
      diag(temp) <- 0
      
      result <- sum(temp * (I - v.MSI.hat))
      
      return(result)
    }
    temp1 <- grad(sum.U.MSI.hat, estimated.params)
    Q.MSI <- rowMeans(temp * (I - v.MSI.hat)) + colMeans(temp * (I - v.MSI.hat)) + ((t(as.matrix(temp1))%*%information.matrix.inverse.hat%*%individual.deriv) %>% as.numeric())/N
    variance.AUC.MSI.hat <- mean(Q.MSI^2)/((p.D.hat*(1 - p.D.hat))^2)
    
    h.hat <- numeric(N)
    xi.hat <- numeric(N)
    phi.hat <- numeric(N)
    pi.star.hat <- numeric(N)
    h.hat <- beta.0.hat + beta.1.hat*T.1 + (X%*%(beta.X.hat %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(beta.TX.hat %>% as.matrix()) %>% as.numeric())
    xi.hat <- rho.1.hat*(1 + exp(- h.hat - q.hat))/(rho.1.hat*(1 + exp(- h.hat - q.hat)) + (1 - rho.1.hat)*(1 + exp(- h.hat)))
    phi.hat <- xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))/(xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
    pi.star.hat <- (xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2]))*((h.hat + q.hat) %>% expit()) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1]))*(h.hat %>% expit())) /
      (xi.hat*(T.2*(p.T.2.hat[, 2]) + (1 - T.2)*(1 - p.T.2.hat[, 2])) + (1 - xi.hat)*(T.2*(p.T.2.hat[, 1]) + (1 - T.2)*(1 - p.T.2.hat[, 1])))
    
    TPR.IPW.hat <- function(s){
      sum(as.numeric(T.1 >= s)*V*phi.hat/pi.star.hat)/sum(V*phi.hat/pi.star.hat)
    }
    FPR.IPW.hat <- function(s){
      sum(as.numeric(T.1 >= s)*V*(1 - phi.hat)/pi.star.hat)/sum(V*(1 - phi.hat)/pi.star.hat)
    }
    temp <- (V*phi.hat/pi.star.hat) %o% (V*(1 - phi.hat)/pi.star.hat)
    diag(temp) <- 0
    v.IPW.hat <- sum(temp*I)/(sum(V*phi.hat/pi.star.hat)*sum(V*(1 - phi.hat)/pi.star.hat) - sum(V*phi.hat/pi.star.hat*(V*(1 - phi.hat)/pi.star.hat)))
    
    sum.U.IPW.hat <- function(params){
      
      alpha.0 <- params[1]
      alpha.1 <- params[2]
      alpha.X <- params[3:(2+dim_X)]
      alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
      beta.0 <- params[3+2*dim_X]
      beta.1 <- params[4+2*dim_X]
      beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
      beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
      gamma <- matrix(params[(5+4*dim_X):(6+6*dim_X)], ncol = 2, nrow = 1 + dim_X)
      delta <- matrix(params[(7+6*dim_X):(8+8*dim_X)], ncol = 2, nrow = 1 + dim_X)
      psi.0 <- params[9+8*dim_X]
      psi.1 <- params[10+8*dim_X]
      zeta <- matrix(c(params[11+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)], params[12+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)]), ncol = 2, nrow = 1 + dim_X)
      
      p.D.v1 <-  lapply(1:N, FUN = function(i) sum(X[i, ]*gamma[-1, G[i]]) + gamma[1, G[i]]) %>% as.numeric() %>% expit()
      
      mu.v1 <- matrix(0, ncol = 2, nrow = N)
      mu.v1[, 1] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 1]) + delta[1, 1]) %>% as.numeric())
      mu.v1[, 2] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 2]) + delta[1, 2]) %>% as.numeric())
      
      theta.v1 <- matrix(0, ncol = 2, nrow = N)
      theta.v1[, 1] <- b.dot.inverse(mu.v1[, 1])
      theta.v1[, 2] <- b.dot.inverse(mu.v1[, 2])
      
      p.T.2 <- matrix(0, ncol = 2, nrow = N)
      p.T.2[, 1] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 1]) + zeta[1, 1])) %>% as.numeric() %>% expit()
      p.T.2[, 2] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 2]) + zeta[1, 2])) %>% as.numeric() %>% expit()
      
      theta.v0 <- matrix(0, ncol = 2, nrow = N)
      theta.v0[, 1] <- theta.v1[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0
      theta.v0[, 2] <- theta.v1[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1
      
      temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0))
      p.D.v0 <- temp1/(1+temp1)
      
      temp2 <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
        ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0) + 
           exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1))
      p.V <- 1/(1 + temp2)
      
      q <- alpha.0 + alpha.1*T.1 + (X%*%(alpha.X %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(alpha.TX %>% as.matrix()) %>% as.numeric())
      
      rho.1 <- numeric(N)
      rho.0 <- numeric(N)
      rho.V <- numeric(N)
      rho.1 <- (p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N)))/(p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N)) + (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N)))
      rho.0 <- rho.1*(exp(-q))/(rho.1*exp(-q) + (1 - rho.1))
      rho.V <- V*rho.1 + (1 - V)*rho.0
      tau <- numeric(N)
      D.MSI <- numeric(N)
      tau <- (rho.1*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])))/(rho.1*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - rho.1)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      D.MSI <- V*tau + (1 - V)*rho.0
      h <- numeric(N)
      xi <- numeric(N)
      phi <- numeric(N)
      pi.star <- numeric(N)
      h <- beta.0 + beta.1*T.1 + (X%*%(beta.X %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(beta.TX %>% as.matrix()) %>% as.numeric())
      xi <- rho.1*(1 + exp(- h - q))/(rho.1*(1 + exp(- h - q)) + (1 - rho.1)*(1 + exp(- h)))
      phi <- xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))/(xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      pi.star <- (xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))*((h + q) %>% expit()) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1]))*(h %>% expit())) /
        (xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      D.PDR <- numeric(N)
      D.PDR <- V*phi/pi.star + (1 - V/pi.star)*rho.0
      
      temp <- (V*phi/pi.star) %o% (V*(1 - phi)/pi.star)
      diag(temp) <- 0
      
      result <- sum(temp * (I - v.IPW.hat))
      
      return(result)
    }
    temp1 <- grad(sum.U.IPW.hat, estimated.params)
    Q.IPW <- rowMeans(temp * (I - v.IPW.hat)) + colMeans(temp * (I - v.IPW.hat)) + ((t(as.matrix(temp1))%*%information.matrix.inverse.hat%*%individual.deriv) %>% as.numeric())/N
    variance.AUC.IPW.hat <- mean(Q.IPW^2)/((p.D.hat*(1 - p.D.hat))^2)
    
    D.PDR.hat <- numeric(N)
    D.PDR.hat <- V*phi.hat/pi.star.hat + (1 - V/pi.star.hat)*rho.0.hat
    
    TPR.PDR.hat <- function(s){
      sum(as.numeric(T.1 >= s)*D.PDR.hat)/sum(D.PDR.hat)
    }
    FPR.PDR.hat <- function(s){
      sum(as.numeric(T.1 >= s)*(1 - D.PDR.hat))/sum(1 - D.PDR.hat)
    }
    temp <- (D.PDR.hat) %o% (1 - D.PDR.hat)
    diag(temp) <- 0
    v.PDR.hat <- sum(temp*I)/(sum(D.PDR.hat)*sum(1 - D.PDR.hat) - sum(D.PDR.hat*(1 - D.PDR.hat)))
    
    sum.U.PDR.hat <- function(params){
      
      alpha.0 <- params[1]
      alpha.1 <- params[2]
      alpha.X <- params[3:(2+dim_X)]
      alpha.TX <- params[(3+dim_X):(2+2*dim_X)]
      beta.0 <- params[3+2*dim_X]
      beta.1 <- params[4+2*dim_X]
      beta.X <- params[(5+2*dim_X):(4+3*dim_X)]
      beta.TX <- params[(5+3*dim_X):(4+4*dim_X)]
      gamma <- matrix(params[(5+4*dim_X):(6+6*dim_X)], ncol = 2, nrow = 1 + dim_X)
      delta <- matrix(params[(7+6*dim_X):(8+8*dim_X)], ncol = 2, nrow = 1 + dim_X)
      psi.0 <- params[9+8*dim_X]
      psi.1 <- params[10+8*dim_X]
      zeta <- matrix(c(params[11+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)], params[12+8*dim_X], params[(13+8*dim_X):(12+9*dim_X)]), ncol = 2, nrow = 1 + dim_X)
      
      p.D.v1 <-  lapply(1:N, FUN = function(i) sum(X[i, ]*gamma[-1, G[i]]) + gamma[1, G[i]]) %>% as.numeric() %>% expit()
      
      mu.v1 <- matrix(0, ncol = 2, nrow = N)
      mu.v1[, 1] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 1]) + delta[1, 1]) %>% as.numeric())
      mu.v1[, 2] <- g.inverse(lapply(1:N, FUN = function(i) sum(X[i, ]*delta[-1, 2]) + delta[1, 2]) %>% as.numeric())
      
      theta.v1 <- matrix(0, ncol = 2, nrow = N)
      theta.v1[, 1] <- b.dot.inverse(mu.v1[, 1])
      theta.v1[, 2] <- b.dot.inverse(mu.v1[, 2])
      
      p.T.2 <- matrix(0, ncol = 2, nrow = N)
      p.T.2[, 1] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 1]) + zeta[1, 1])) %>% as.numeric() %>% expit()
      p.T.2[, 2] <- lapply(1:N, FUN = function(i) (sum(X[i, ]*zeta[-1, 2]) + zeta[1, 2])) %>% as.numeric() %>% expit()
      
      theta.v0 <- matrix(0, ncol = 2, nrow = N)
      theta.v0[, 1] <- theta.v1[ ,1] - (beta.1 + X%*%as.matrix(beta.TX))*psi.0
      theta.v0[, 2] <- theta.v1[ ,2] - (beta.1 + X%*%as.matrix(beta.TX) + alpha.1 + X%*%as.matrix(alpha.TX))*psi.1

      temp1 <- exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1)/((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0))
      p.D.v0 <- temp1/(1+temp1)

      temp2 <- exp(-beta.0 - X%*%as.matrix(beta.X) %>% as.numeric()) * 
        ((1 - p.D.v1)*exp((b(theta.v0[, 1]) - b(theta.v1[, 1]))/psi.0) + 
           exp((-alpha.0 - X%*%as.matrix(alpha.X)) %>% as.numeric())*p.D.v1*exp((b(theta.v0[, 2]) - b(theta.v1[, 2]))/psi.1))
      p.V <- 1/(1 + temp2)
      
      q <- alpha.0 + alpha.1*T.1 + (X%*%(alpha.X %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(alpha.TX %>% as.matrix()) %>% as.numeric())
      
      rho.1 <- numeric(N)
      rho.0 <- numeric(N)
      rho.V <- numeric(N)
      rho.1 <- (p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N)))/(p.D.v1*density.glm(T.1, theta.v1[, 2], rep(psi.1, times = N)) + (1 - p.D.v1)*density.glm(T.1, theta.v1[, 1], rep(psi.0, times = N)))
      rho.0 <- rho.1*(exp(-q))/(rho.1*exp(-q) + (1 - rho.1))
      rho.V <- V*rho.1 + (1 - V)*rho.0
      tau <- numeric(N)
      D.MSI <- numeric(N)
      tau <- (rho.1*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])))/(rho.1*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - rho.1)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      D.MSI <- V*tau + (1 - V)*rho.0
      h <- numeric(N)
      xi <- numeric(N)
      phi <- numeric(N)
      pi.star <- numeric(N)
      h <- beta.0 + beta.1*T.1 + (X%*%(beta.X %>% as.matrix()) %>% as.numeric()) + T.1 *(X%*%(beta.TX %>% as.matrix()) %>% as.numeric())
      xi <- rho.1*(1 + exp(- h - q))/(rho.1*(1 + exp(- h - q)) + (1 - rho.1)*(1 + exp(- h)))
      phi <- xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))/(xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      pi.star <- (xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2]))*((h + q) %>% expit()) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1]))*(h %>% expit())) /
        (xi*(T.2*(p.T.2[, 2]) + (1 - T.2)*(1 - p.T.2[, 2])) + (1 - xi)*(T.2*(p.T.2[, 1]) + (1 - T.2)*(1 - p.T.2[, 1])))
      D.PDR <- numeric(N)
      D.PDR <- V*phi/pi.star + (1 - V/pi.star)*rho.0
      
      temp <- (D.PDR) %o% (1 - D.PDR)
      diag(temp) <- 0
      
      result <- sum(temp * (I - v.PDR.hat))
      
      return(result)
    }
    temp1 <- grad(sum.U.PDR.hat, estimated.params)
    Q.PDR <- rowMeans(temp * (I - v.PDR.hat)) + colMeans(temp * (I - v.PDR.hat)) + ((t(as.matrix(temp1))%*%information.matrix.inverse.hat%*%individual.deriv) %>% as.numeric())/N
    variance.AUC.PDR.hat <- mean(Q.PDR^2)/((p.D.hat*(1 - p.D.hat))^2)
    
    return(list(alpha.0.hat = alpha.0.hat,
                alpha.1.hat = alpha.1.hat,
                alpha.X.hat = alpha.X.hat,
                alpha.TX.hat = alpha.TX.hat,
                beta.0.hat = beta.0.hat,
                beta.1.hat = beta.1.hat,
                beta.X.hat = beta.X.hat,
                beta.TX.hat = beta.TX.hat,
                gamma.hat = gamma.hat,
                delta.hat = delta.hat,
                psi.0.hat = psi.0.hat,
                psi.1.hat = psi.1.hat,
                zeta.hat = zeta.hat,
                information.matrix.inverse.hat = information.matrix.inverse.hat,
                v.FI.hat = v.FI.hat,
                variance.AUC.FI.hat = variance.AUC.FI.hat,
                v.MSI.hat = v.MSI.hat,
                variance.AUC.MSI.hat = variance.AUC.MSI.hat,
                v.IPW.hat = v.IPW.hat,
                variance.AUC.IPW.hat = variance.AUC.IPW.hat,
                v.PDR.hat = v.PDR.hat,
                variance.AUC.PDR.hat = variance.AUC.PDR.hat
    ))
  }
  
  
  tryCatch({
    
    ##### Run #####
    parametric.estimation.result <- parametric.estimation()
    
    return(list(parametric.estimation = parametric.estimation.result
    ))
    
  }, error = function(e) {
    return("FALSE")
  })
}



num_simulations <- 50
cl <- makeCluster(num_simulations)
clusterExport(cl, "simulation")
num_repetitions <- 10


results <- list()
for (fake_value in 1:num_repetitions) {
  print(fake_value)
  fake_values <- rep(fake_value, num_simulations)
  simulation_results <- parLapply(cl, fake_values, function(fake){
    simulation(fake)
  })
  results[[fake_value]] <- simulation_results
}
stopCluster(cl)